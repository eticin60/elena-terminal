"""Sinyal ve olay (TP/SL) mesajlarını biçimlendirir (v4 şeması).

Sinyal sözlüğü: market, side, symbol, tf, entry, sl, sl_pct, tps[3], lev, close_ms, score, checks, ctx,
htf {tf, trend} | None, warns, fut (opsiyonel). Eksik veri olan bölüm sessizce atlanır.
"""
import core
from texts import HEAD, LINE, fmt_price, local_time, tx

FAC_NAMES = {"mavw": "MavilimW", "ema200": "EMA200", "rsi": "RSI", "macd": "MACD", "adx": "ADX",
             "stoch": "StochRSI", "vwap": "VWAP"}
PAT_KEYS = {"pat_dt": "pat_dtop", "pat_db": "pat_dbot", "pat_bf": "pat_bflag", "pat_sf": "pat_sflag"}


def arrow(x):
    return "▲" if x else "▼"


def bar(score):
    score = max(0, min(core.MAX_SCORE, int(score)))
    return "▰" * score + "▱" * (core.MAX_SCORE - score)


def fmt_big(x):
    if x is None:
        return "—"
    for div, suf in ((1e9, "B"), (1e6, "M"), (1e3, "K")):
        if abs(x) >= div:
            return f"{x / div:.2f}{suf}"
    return f"{x:.0f}"


def _level(t, key, x, entry):
    return (f"{t[key]}: <code>{fmt_price(x['price'])}</code> "
            f"({(x['price'] / entry - 1) * 100:+.2f}% · ×{x['touches']})")


def checks_line(t, s):
    parts = []
    for key in core.CHECKS:
        v = s["checks"].get(key)
        if v is None:
            continue
        if key == "vol":
            name = t["fac_vol"]
        elif key == "room":
            name = t["fac_room"]
        elif key == "htf":
            name = s["htf"]["tf"] if s.get("htf") else "HTF"
        else:
            name = FAC_NAMES[key]
        parts.append(("✅ " if v else "❌ ") + name)
    return " · ".join(parts)


def warn_lines(t, s):
    ctx, out = s.get("ctx", {}), []
    for w in s.get("warns", []):
        if w == "w_blocked":
            opp = ctx.get("res") if s["side"] in ("LONG", "BUY") else ctx.get("sup")
            out.append(t["w_sr"].format(d=f"{abs(opp['dist']):.2f}") if opp else None)
        elif w == "w_htf_against":
            out.append(t["w_htf"])
        elif w in t:
            out.append(t[w])
    f = s.get("fut")
    if f and f.get("funding") is not None:  # kalabalık işlem: funding yönle aynı ve aşırı
        long_ = s["side"] in ("LONG", "BUY")
        if (long_ and f["funding"] >= 0.05) or (not long_ and f["funding"] <= -0.05):
            out.append(t["w_fund"])
    if s.get("score", 0) < 4:
        out.append(t["w_low"])
    return [x for x in out if x]


def narrative(t, s):
    """Acemi dostu "Ne oluyor?" anlatımı (ctx verisinden)."""
    ctx = s.get("ctx", {})
    out = []
    chg = ctx.get("chg10")
    if chg is not None:
        key = "nar_flat" if abs(chg) < 0.5 else ("nar_up" if chg > 0 else "nar_down")
        out.append(t[key].format(x=f"{abs(chg):.2f}"))
    if ctx.get("trend_up") is not None:
        out.append(t["nar_state_up" if ctx["trend_up"] else "nar_state_dn"])
    vr = ctx.get("vol_ratio")
    if vr is not None:
        if vr >= 1.5:
            out.append(t["nar_vol_hi"].format(x=f"{vr:.1f}"))
        elif vr < 0.8:
            out.append(t["nar_vol_lo"].format(x=f"{vr:.1f}"))
    for key, nk in (("sup", "nar_sup"), ("res", "nar_res")):
        if ctx.get(key):
            out.append(t[nk].format(p=fmt_price(ctx[key]["price"]), d=f"{abs(ctx[key]['dist']):.2f}"))
    if not out:
        return []
    return [t["nar_head"]] + out + [t["nar_end"]]


def corr_line(t, s):
    c = s.get("corr")
    if c is None:
        return None
    return t["corr_line"].format(c=f"{c:+.2f}", l=t["corr_" + core.corr_label(c)])


def render_explain(lang, s):
    """/explain: sinyal olmasa da güncel piyasa görünümü (force analiz)."""
    t = tx(lang)
    L = [t["ex_head"].format(s=s["symbol"], tf=s["tf"]), "", f"💰 <code>{fmt_price(s['entry'])}</code>"]
    nar = narrative(t, s)
    L += nar if nar else []
    c = corr_line(t, s)
    if c:
        L += ["", c]
    L += ["", t["disc"]]
    return "\n".join(L)



def _scenario_projection(t, sl_pct, lev, lang="tr"):
    """Kaldiracli ornek kazanc/kayip projeksiyonu (1000$ kasa, 250$ marjin senaryosu).
    Yasal & bilgilendirici egitim ciktisi."""
    base_margin = 250.0
    lev_val = max(1, int(lev or 10))
    roi1 = sl_pct * lev_val
    roi2 = sl_pct * 2 * lev_val
    roi3 = sl_pct * 3 * lev_val
    pnl1 = base_margin * (roi1 / 100.0)
    pnl2 = base_margin * (roi2 / 100.0)
    pnl3 = base_margin * (roi3 / 100.0)
    pnl_sl = base_margin * (roi1 / 100.0)

    if lang in ("ru", "uk"):
        head = f"💡 <b>Пример сценария (Баланс $1,000, маржа $250, плечо {lev_val}x):</b>"
        lines = [
            head,
            f"  🎯 TP1: ROI <b>+{roi1:.1f}%</b> · Профит: <b>+${pnl1:.2f}</b> (+1R)",
            f"  🎯 TP2: ROI <b>+{roi2:.1f}%</b> · Профит: <b>+${pnl2:.2f}</b> (+2R)",
            f"  🎯 TP3: ROI <b>+{roi3:.1f}%</b> · Профит: <b>+${pnl3:.2f}</b> (+3R)",
            f"  🛑 Stop: ROI <b>-{roi1:.1f}%</b> · Риск: <b>-${pnl_sl:.2f}</b> (-1R)",
            "  <i>ℹ️ 1R = базовая сумма риска стопа. Не является инвестсоветом.</i>"
        ]
    elif lang == "tr":
        head = f"💡 <b>Örnek Senaryo &amp; Projeksiyon ({lev_val}x Kaldıraç):</b>"
        sub = "  <i>(Örn: 1.000$ Kasadan 250$ Marjin ile işleme girilirse)</i>"
        lines = [
            head,
            sub,
            f"  🎯 TP1: ROI <b>+{roi1:.1f}%</b> · Net Kâr: <b>+{pnl1:.2f}$</b> (+1R)",
            f"  🎯 TP2: ROI <b>+{roi2:.1f}%</b> · Net Kâr: <b>+{pnl2:.2f}$</b> (+2R)",
            f"  🎯 TP3: ROI <b>+{roi3:.1f}%</b> · Net Kâr: <b>+{pnl3:.2f}$</b> (+3R)",
            f"  🛑 Stop: ROI <b>-{roi1:.1f}%</b> · Risk: <b>-{pnl_sl:.2f}$</b> (-1R)",
            "  <i>ℹ️ 1R = stop mesafesi risk tutarıdır. Temsili simülasyondur, YTD.</i>"
        ]
    else:
        head = f"💡 <b>Scenario Projection ({lev_val}x Leverage, $250 Margin):</b>"
        sub = "  <i>(E.g. $1,000 balance entering with $250 margin)</i>"
        lines = [
            head,
            sub,
            f"  🎯 TP1: ROI <b>+{roi1:.1f}%</b> · PnL: <b>+${pnl1:.2f}</b> (+1R)",
            f"  🎯 TP2: ROI <b>+{roi2:.1f}%</b> · PnL: <b>+${pnl2:.2f}</b> (+2R)",
            f"  🎯 TP3: ROI <b>+{roi3:.1f}%</b> · PnL: <b>+${pnl3:.2f}</b> (+3R)",
            f"  🛑 Stop: ROI <b>-{roi1:.1f}%</b> · Risk: <b>-${pnl_sl:.2f}</b> (-1R)",
            "  <i>ℹ️ 1R = initial stop risk unit. Educational model, not financial advice.</i>"
        ]
    return lines

def render_signal(lang, s, lev, tz=3, compact=False):
    t = tx(lang)
    side, entry, ctx = s["side"], s["entry"], s.get("ctx", {})
    title = {"LONG": "🟢 <b>LONG</b>", "SHORT": "🔴 <b>SHORT</b>",
             "BUY": "🟢 <b>" + t["buy"] + "</b>", "EXIT": "🟠 <b>" + t["exit"] + "</b>"}[side]
    L = [HEAD, LINE, f"{title} · <code>{s['symbol']}</code>",
         f"📊 {t[s['market']]} · ⏱ {s['tf']} · 🕒 {local_time(s['close_ms'] / 1000, tz)} (UTC{tz:+d})", "",
         f"💰 {t['sig_entry']}: <code>{fmt_price(entry)}</code>"]
    if side == "EXIT":
        if ctx.get("rsi") is not None:
            L.append(f"RSI {ctx['rsi']:.1f}")
        L += ["", t["exit_note"], "", t["disc"]]
        return "\n".join(L)

    L.append(f"🛑 {t['sig_stop']}: <code>{fmt_price(s['sl'])}</code> (-{s['sl_pct']:.2f}%)")
    for i, tp in enumerate(s["tps"], 1):
        L.append(f"🎯 TP{i}: <code>{fmt_price(tp)}</code> (+{s['sl_pct'] * i:.2f}% · {i}R)")
    if s["market"] == "futures":
        L.append(f"⚙️ {t['sig_lev']}: <b>{lev}x</b>")
    L += [t["risk_hint"].format(x=f"{1 / s['sl_pct']:.2f}"), t["plan"]]

    # 💡 Spot & Futures Ayrı Kâr/Risk Simülasyonu (Mevcut Stili Asla Bozmadan)
    if s["market"] == "futures":
        roi1 = s['sl_pct'] * (lev or 10)
        roi2 = roi1 * 2
        pnl1 = 250.0 * (roi1 / 100.0)
        pnl2 = pnl1 * 2
        if lang in ("ru", "uk"):
            L += [
                "",
                f"💡 <b>Фьючерсная симуляция (Маржа $250 · Плечо {lev or 10}x):</b>",
                f"  🎯 TP1: ROI <b>+{roi1:.1f}%</b> · Профит: <b>+${pnl1:.1f}</b> (+1R)",
                f"  🎯 TP2: ROI <b>+{roi2:.1f}%</b> · Профит: <b>+${pnl2:.1f}</b> (+2R)",
                f"  🛑 Stop: ROI <b>-{roi1:.1f}%</b> · Риск: <b>-${pnl1:.1f}</b> (-1R)",
                "  <i>ℹ️ Моделирование фьючерсов, не финсовет.</i>"
            ]
        elif lang == "en":
            L += [
                "",
                f"💡 <b>Futures Simulation ($250 Margin · {lev or 10}x Leverage):</b>",
                f"  🎯 TP1: ROI <b>+{roi1:.1f}%</b> · Net Profit: <b>+${pnl1:.1f}</b> (+1R)",
                f"  🎯 TP2: ROI <b>+{roi2:.1f}%</b> · Net Profit: <b>+${pnl2:.1f}</b> (+2R)",
                f"  🛑 Stop: ROI <b>-{roi1:.1f}%</b> · Risk: <b>-${pnl1:.1f}</b> (-1R)",
                "  <i>ℹ️ Educational futures simulation, NFA.</i>"
            ]
        else:
            L += [
                "",
                f"💡 <b>Vadeli Simülasyon ($250 Marjin · {lev or 10}x Kaldıraç):</b>",
                f"  🎯 TP1: ROI <b>+{roi1:.1f}%</b> · Net Kâr: <b>+{pnl1:.1f}$</b> (+1R)",
                f"  🎯 TP2: ROI <b>+{roi2:.1f}%</b> · Net Kâr: <b>+{pnl2:.1f}$</b> (+2R)",
                f"  🛑 Stop: ROI <b>-{roi1:.1f}%</b> · Risk: <b>-{pnl1:.1f}$</b> (-1R)",
                "  <i>ℹ️ Temsili vadeli hesaplamadır, YTD.</i>"
            ]
    else:
        # SPOT & BIST & HİSSE İÇİN (1x Kaldıraçsız Net Değişim)
        spot_pct = s['sl_pct']
        spot_pnl1 = 250.0 * (spot_pct / 100.0)
        spot_pnl2 = spot_pnl1 * 2
        if lang in ("ru", "uk"):
            L += [
                "",
                f"💡 <b>Спот / Акции (Сумма $250 · 1x без плеча):</b>",
                f"  🎯 TP1: Профит <b>+%{spot_pct:.2f}</b> (+${spot_pnl1:.2f}) · 1R",
                f"  🎯 TP2: Профит <b>+%{spot_pct*2:.2f}</b> (+${spot_pnl2:.2f}) · 2R",
                f"  🛑 Stop: Риск <b>-%{spot_pct:.2f}</b> (-${spot_pnl1:.2f}) · -1R",
                "  <i>ℹ️ Без кредитного плеча, спот капитал.</i>"
            ]
        elif lang == "en":
            L += [
                "",
                f"💡 <b>Spot / Stock Simulation ($250 Allocation · 1x):</b>",
                f"  🎯 TP1: Profit <b>+%{spot_pct:.2f}</b> (+${spot_pnl1:.2f}) · 1R",
                f"  🎯 TP2: Profit <b>+%{spot_pct*2:.2f}</b> (+${spot_pnl2:.2f}) · 2R",
                f"  🛑 Stop: Risk <b>-%{spot_pct:.2f}</b> (-${spot_pnl1:.2f}) · -1R",
                "  <i>ℹ️ Spot simulation without leverage, NFA.</i>"
            ]
        else:
            L += [
                "",
                f"💡 <b>Spot / Hisse Simülasyonu ($250 Alım Büyüklüğü · 1x):</b>",
                f"  🎯 TP1: Kâr <b>+%{spot_pct:.2f}</b> (+{spot_pnl1:.2f}$) · 1R",
                f"  🎯 TP2: Kâr <b>+%{spot_pct*2:.2f}</b> (+{spot_pnl2:.2f}$) · 2R",
                f"  🛑 Stop: Risk <b>-%{spot_pct:.2f}</b> (-{spot_pnl1:.2f}$) · -1R",
                "  <i>ℹ️ Kaldıraçsız spot sermaye simülasyonudur, YTD.</i>"
            ]

    # --- puan ve teyitler
    sc = s["score"]
    L += ["", f"⭐ {t['sig_strength']}: {bar(sc)} <b>{sc}/{core.MAX_SCORE}</b> · "
              f"{t['grade_word']} <b>{core.grade_key(sc).upper()}</b>", checks_line(t, s)]

    if compact:
        w = warn_lines(t, s)
        if w:
            L += [""] + w
        L += ["", t["disc"]]
        return "\n".join(L)

    # --- seviyeler
    lv = []
    if ctx.get("res"):
        lv.append(_level(t, "res", ctx["res"], entry))
    if ctx.get("sup"):
        lv.append(_level(t, "sup", ctx["sup"], entry))
    if ctx.get("fib"):
        lv.append(f"📏 Fib {ctx['fib']['ratio']:g}: <code>{fmt_price(ctx['fib']['price'])}</code> "
                  f"({ctx['fib']['dist']:+.2f}%)")
    if ctx.get("vwap") is not None:
        lv.append(f"📍 VWAP: <code>{fmt_price(ctx['vwap'])}</code> ({ctx['vwap_dist']:+.2f}%)")
    if lv:
        L += ["", t["sec_levels"]] + lv

    # --- göstergeler
    L += ["", t["sec_ind"]]
    long_ = side in ("LONG", "BUY")
    trend = ["Supertrend " + arrow(long_)]
    for label, key in (("MavilimW", "mavw_up"), ("EMA9/21", "ema_bull"), ("EMA200", "above_e200")):
        if ctx.get(key) is not None:
            trend.append(f"{label} {arrow(ctx[key])}")
    L.append(" · ".join(trend))
    if ctx.get("rsi") is not None:
        r = ctx["rsi"]
        zone = t["rsi_ob"] if r >= 70 else t["rsi_os"] if r <= 30 else t["rsi_n"]
        line = f"RSI {r:.1f} ({zone})"
        if ctx.get("stoch_k") is not None and ctx.get("stoch_d") is not None:
            line += f" · StochRSI {ctx['stoch_k']:.0f}/{ctx['stoch_d']:.0f}"
        L.append(line)
    bits = []
    if ctx.get("macd_hist") is not None:
        bits.append(f"MACD {arrow(ctx['macd_hist'] > 0)} ({ctx['macd_hist']:+.3g})")
    if ctx.get("adx") is not None:
        di = ""
        if ctx.get("pdi") is not None and ctx.get("mdi") is not None:
            di = f" · +DI {ctx['pdi']:.0f}/−DI {ctx['mdi']:.0f}"
        bits.append(f"ADX {ctx['adx']:.1f} ({t['adx_strong'] if ctx['adx'] >= 25 else t['adx_weak']}){di}")
    if bits:
        L.append(" · ".join(bits))
    if ctx.get("bb_pb") is not None:
        L.append(f"Bollinger %B {ctx['bb_pb']:.2f}")
    if ctx.get("vol_ratio") is not None:
        buy = f"{ctx['flow_buy']:.0f}" if ctx.get("flow_buy") is not None else "—"
        L.append(t["ind_vol"].format(x=f"{ctx['vol_ratio']:.1f}", b=buy))
    if ctx.get("atr_pct") is not None:
        L.append(t["ind_atr"].format(x=f"{ctx['atr_pct']:.2f}"))

    # --- üst zaman dilimi
    if s.get("htf"):
        h = s["htf"]
        L += ["", t["sec_mtf"], f"{h['tf']} {arrow(h['trend'] == 1)}"]

    # --- futures verisi
    fut = s.get("fut")
    if fut and s["market"] == "futures":
        f_ = f"{fut['funding']:+.4f}" if fut.get("funding") is not None else "—"
        ls = f"{fut['ls']:.2f}" if fut.get("ls") is not None else "—"
        L += ["", t["sec_fut"], t["fut_line"].format(f=f_, oi=fmt_big(fut.get("oi")), ls=ls)]

    # --- formasyon
    pats = [t[PAT_KEYS[p["key"]]] for p in ctx.get("patterns", []) if p["key"] in PAT_KEYS]
    if pats:
        L += ["", t["sec_pat"], " · ".join(pats)]

    cl = corr_line(t, s)
    if cl:
        L += ["", cl]
    nar = narrative(t, s)
    if nar:
        L += [""] + nar

    # --- uyarılar ve alt bilgi
    w = warn_lines(t, s)
    if w:
        L += [""] + w
    L += ["", t["track_note"], "", t["disc"]]
    return "\n".join(L)


def render_signal_caption(lang, s, lev, tz=3, compact=False):
    """Grafikle birleşik gönderilen tek mesaj (photo caption) için optimize edilmiş sinyal metni (<= 1024 karakter)."""
    if compact:
        return render_signal(lang, s, lev, tz, compact=True)
    t = tx(lang)
    side, entry, ctx = s["side"], s["entry"], s.get("ctx", {})
    title = {"LONG": "🟢 <b>LONG</b>", "SHORT": "🔴 <b>SHORT</b>",
             "BUY": "🟢 <b>" + t["buy"] + "</b>", "EXIT": "🟠 <b>" + t["exit"] + "</b>"}[side]
    sym = s["symbol"]
    mkt = t[s["market"]]
    tf = s["tf"]
    tm = local_time(s["close_ms"] / 1000, tz)
    L = [HEAD, LINE, f"{title} · <code>{sym}</code>",
         f"📊 {mkt} · ⏱ {tf} · 🕒 {tm} (UTC{tz:+d})", "",
         f"💰 {t['sig_entry']}: <code>{fmt_price(entry)}</code>"]
    if side == "EXIT":
        if ctx.get("rsi") is not None:
            L.append(f"RSI {ctx['rsi']:.1f}")
        L += ["", t["exit_note"], "", t["disc"]]
        return "\n".join(L)

    L.append(f"🛑 {t['sig_stop']}: <code>{fmt_price(s['sl'])}</code> (-{s['sl_pct']:.2f}%)")
    for i, tp in enumerate(s["tps"], 1):
        L.append(f"🎯 TP{i}: <code>{fmt_price(tp)}</code> (+{s['sl_pct'] * i:.2f}% · {i}R)")
    if s["market"] == "futures":
        L.append(f"⚙️ {t['sig_lev']}: <b>{lev}x</b>")
    L.append(t["plan"])

    # 💡 Spot & Futures Ayrı Kâr/Risk Simülasyonu (Mevcut Stili Asla Bozmadan)
    if s["market"] == "futures":
        roi1 = s['sl_pct'] * (lev or 10)
        roi2 = roi1 * 2
        pnl1 = 250.0 * (roi1 / 100.0)
        pnl2 = pnl1 * 2
        if lang in ("ru", "uk"):
            L += [
                "",
                f"💡 <b>Фьючерсная симуляция (Маржа $250 · Плечо {lev or 10}x):</b>",
                f"  🎯 TP1: ROI <b>+{roi1:.1f}%</b> · Профит: <b>+${pnl1:.1f}</b> (+1R)",
                f"  🎯 TP2: ROI <b>+{roi2:.1f}%</b> · Профит: <b>+${pnl2:.1f}</b> (+2R)",
                f"  🛑 Stop: ROI <b>-{roi1:.1f}%</b> · Риск: <b>-${pnl1:.1f}</b> (-1R)",
                "  <i>ℹ️ Моделирование фьючерсов, не финсовет.</i>"
            ]
        elif lang == "en":
            L += [
                "",
                f"💡 <b>Futures Simulation ($250 Margin · {lev or 10}x Leverage):</b>",
                f"  🎯 TP1: ROI <b>+{roi1:.1f}%</b> · Net Profit: <b>+${pnl1:.1f}</b> (+1R)",
                f"  🎯 TP2: ROI <b>+{roi2:.1f}%</b> · Net Profit: <b>+${pnl2:.1f}</b> (+2R)",
                f"  🛑 Stop: ROI <b>-{roi1:.1f}%</b> · Risk: <b>-${pnl1:.1f}</b> (-1R)",
                "  <i>ℹ️ Educational futures simulation, NFA.</i>"
            ]
        else:
            L += [
                "",
                f"💡 <b>Vadeli Simülasyon ($250 Marjin · {lev or 10}x Kaldıraç):</b>",
                f"  🎯 TP1: ROI <b>+{roi1:.1f}%</b> · Net Kâr: <b>+{pnl1:.1f}$</b> (+1R)",
                f"  🎯 TP2: ROI <b>+{roi2:.1f}%</b> · Net Kâr: <b>+{pnl2:.1f}$</b> (+2R)",
                f"  🛑 Stop: ROI <b>-{roi1:.1f}%</b> · Risk: <b>-{pnl1:.1f}$</b> (-1R)",
                "  <i>ℹ️ Temsili vadeli hesaplamadır, YTD.</i>"
            ]
    else:
        # SPOT & BIST & HİSSE İÇİN (1x Kaldıraçsız Net Değişim)
        spot_pct = s['sl_pct']
        spot_pnl1 = 250.0 * (spot_pct / 100.0)
        spot_pnl2 = spot_pnl1 * 2
        if lang in ("ru", "uk"):
            L += [
                "",
                f"💡 <b>Спот / Акции (Сумма $250 · 1x без плеча):</b>",
                f"  🎯 TP1: Профит <b>+%{spot_pct:.2f}</b> (+${spot_pnl1:.2f}) · 1R",
                f"  🎯 TP2: Профит <b>+%{spot_pct*2:.2f}</b> (+${spot_pnl2:.2f}) · 2R",
                f"  🛑 Stop: Риск <b>-%{spot_pct:.2f}</b> (-${spot_pnl1:.2f}) · -1R",
                "  <i>ℹ️ Без кредитного плеча, спот капитал.</i>"
            ]
        elif lang == "en":
            L += [
                "",
                f"💡 <b>Spot / Stock Simulation ($250 Allocation · 1x):</b>",
                f"  🎯 TP1: Profit <b>+%{spot_pct:.2f}</b> (+${spot_pnl1:.2f}) · 1R",
                f"  🎯 TP2: Profit <b>+%{spot_pct*2:.2f}</b> (+${spot_pnl2:.2f}) · 2R",
                f"  🛑 Stop: Risk <b>-%{spot_pct:.2f}</b> (-${spot_pnl1:.2f}) · -1R",
                "  <i>ℹ️ Spot simulation without leverage, NFA.</i>"
            ]
        else:
            L += [
                "",
                f"💡 <b>Spot / Hisse Simülasyonu ($250 Alım Büyüklüğü · 1x):</b>",
                f"  🎯 TP1: Kâr <b>+%{spot_pct:.2f}</b> (+{spot_pnl1:.2f}$) · 1R",
                f"  🎯 TP2: Kâr <b>+%{spot_pct*2:.2f}</b> (+{spot_pnl2:.2f}$) · 2R",
                f"  🛑 Stop: Risk <b>-%{spot_pct:.2f}</b> (-{spot_pnl1:.2f}$) · -1R",
                "  <i>ℹ️ Kaldıraçsız spot sermaye simülasyonudur, YTD.</i>"
            ]

    sc = s["score"]
    L += ["", f"⭐ {t['sig_strength']}: {bar(sc)} <b>{sc}/{core.MAX_SCORE}</b> · "
              f"{t['grade_word']} <b>{core.grade_key(sc).upper()}</b>", checks_line(t, s)]

    # Seviyeler & Destek / Direnç
    lv = []
    if ctx.get("sup"):
        d = abs(ctx['sup'].get('dist', 0))
        lv.append(f"🛟 Destek: {fmt_price(ctx['sup']['price'])} (-{d:.1f}%)")
    if ctx.get("res"):
        d = abs(ctx['res'].get('dist', 0))
        lv.append(f"🧱 Direnç: {fmt_price(ctx['res']['price'])} (+{d:.1f}%)")
    if ctx.get("vwap") is not None:
        lv.append(f"📍 VWAP {fmt_price(ctx['vwap'])}")
    if lv:
        L += ["", " · ".join(lv)]

    # Göstergeler (özet)
    trend = ["Supertrend " + arrow(side in ("LONG", "BUY"))]
    if ctx.get("mavw_up") is not None:
        trend.append("MavilimW " + arrow(ctx["mavw_up"]))
    if ctx.get("rsi") is not None:
        trend.append(f"RSI {ctx['rsi']:.1f}")
    if ctx.get("adx") is not None:
        trend.append(f"ADX {ctx['adx']:.1f}")
    L.append(" · ".join(trend))

    # Futures
    fut = s.get("fut")
    if fut and s["market"] == "futures":
        f_ = f"{fut['funding']:+.4f}" if fut.get("funding") is not None else "—"
        L.append(f"Fonlama {f_} · OI {fmt_big(fut.get('oi'))}")

    w = warn_lines(t, s)
    if w:
        L += [""] + w
    L += ["", t["disc"]]
    res = "\n".join(L)
    if len(res) > 1024:
        return render_signal(lang, s, lev, tz, compact=True)
    return res


def render_event(lang, kind, row, price, r):
    """TP/SL/kapanış olayı. kind: tp1|tp2|tp3|sl|be|flip|expired. row: symbol, tf, side, entry, tp_hit."""
    t = tx(lang)
    if kind == "flip":
        return t["ev_flip"].format(s=row["symbol"], tf=row["tf"], side=row["side"],
                                   p=fmt_price(price), r=f"{r:+.2f}") + "\n\n" + t["disc"]
    head = {"tp1": t["tr_tp"].format(n=1), "tp2": t["tr_tp"].format(n=2), "tp3": t["tr_tp3"],
            "sl": t["tr_sl"], "be": t["tr_be"], "expired": t["tr_exp"]}[kind]
    L = [head, f"<code>{row['symbol']}</code> · {row['tf']} · {row['side']}",
         f"💲 <code>{fmt_price(price)}</code>"]
    if kind == "tp1":
        L.append(t["tr_move"].format(p=fmt_price(row["entry"])))
    if kind == "expired":
        hit = int(row["tp_hit"] or 0)
        L.append(t["tr_reached"].format(t=f"TP{hit}" if hit else t["tr_none"]))
    L += [t["tr_result"].format(r=f"{r:+.2f}"), "", t["disc"]]
    return "\n".join(L)
