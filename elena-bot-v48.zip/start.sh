#!/data/data/com.termux/files/usr/bin/bash
# =====================================================================
# Елена Хьюз · Crypto Signals — Başlatma Scripti (Termux & Linux)
# Botu ve Cloudflared HTTPS Mini App Tünelini otomatik başlatır.
# =====================================================================
cd "$(dirname "$0")" || exit 1
termux-wake-lock 2>/dev/null

echo "=========================================="
echo "  Елена Хьюз · Crypto Signals Başlatılıyor"
echo "=========================================="

# 1. Cloudflared Tünelini Arka Planda Başlat (HTTPS Mini App URL'i için)
if command -v cloudflared >/dev/null 2>&1; then
  echo ">> Cloudflared tüneli başlatılıyor (127.0.0.1:8080)..."
  pkill -f "cloudflared tunnel" 2>/dev/null || true
  nohup cloudflared tunnel --url http://127.0.0.1:8080 > .tunnel.log 2>&1 &
  
  # URL'in log dosyasına düşmesini bekle (maks 15 sn)
  echo ">> HTTPS Canlı Tünel adresi alınıyor..."
  for i in $(seq 1 15); do
    URL=$(grep -oE "https://[a-zA-Z0-9-]+\.trycloudflare\.com" .tunnel.log 2>/dev/null | head -n1)
    if [ -n "$URL" ]; then
      echo ">> Başarılı! Canlı Tünel URL: $URL"
      echo "$URL" > .miniapp_url
      # .env dosyasını güncelle
      if [ -f .env ]; then
        if grep -q "^MINIAPP_URL=" .env; then
          sed -i "s|^MINIAPP_URL=.*|MINIAPP_URL=$URL|" .env
        else
          echo "MINIAPP_URL=$URL" >> .env
        fi
      fi
      break
    fi
    sleep 1
  done
else
  echo ">> cloudflared bulunamadı, tünel başlatılamadı. Mini app yerel çalışacak."
fi

# 2. Eski bot süreçlerini ve çakışmaları temizle
echo ">> Eski bot ve tünel süreçleri temizleniyor..."
pkill -9 -f "python.*bot.py" 2>/dev/null || true
sleep 1

# 3. Bot Döngüsü (Çökerse otomatik yeniden başlar)
echo ">> Bot motoru başlatılıyor... (Durdurmak için CTRL+C)"
while true; do
  python bot.py
  echo ">> Bot durdu. 5 saniye sonra yeniden başlayacak..."
  sleep 5
done
