# 🇷🇺 Елена Хьюз · Crypto Signals (Telegram botu) v6

Binance verisiyle çok göstergeli sinyal botu + **otomatik TP/SL takibi ve istatistik**.
8 dil: RU, EN, TR, UK, DE, ES, FR, AR · Futures (Long/Short, kaldıraç önerisi) ve Spot · 1m–1M zaman dilimleri.

## Her sinyalde neler var
- Giriş, stop (Supertrend çizgisi), TP1/TP2/TP3 (1R/2R/3R), önerilen kaldıraç, %1 risk için pozisyon büyüklüğü
- **Güç puanı 0–10 ve derece (A/B/C/D)**; 10 teyit tek satırda: MavilimW, EMA200, hacim, MACD, ADX, RSI, StochRSI, VWAP, üst zaman dilimi, TP1'e mesafe
- **Destek/direnç** (pivot kümeleri, temas sayısıyla), Fibonacci, VWAP
- Göstergeler: Supertrend, MavilimW, EMA9/21/200, RSI, StochRSI, MACD, ADX (+DI/−DI), Bollinger %B, ATR
- **Hacim**: ortalamaya oranı ve alıcı yüzdesi
- Üst zaman dilimi trendi · Futures: funding, açık pozisyon, long/short oranı · formasyon (çift tepe/dip, bayrak)
- Otomatik uyarılar: karşı seviye yakın, zayıf trend, RSI aşırı bölge, düşük hacim, üst TF'ye ters, aşırı funding

## Yeni (v5)
- **📖 "Ne oluyor?"**: acemi dostu anlatım (son 10 mum hareketi, trend, hacim, en yakın destek/direnç)
- **📈 Grafik resmi**: her sinyalle mum grafiği (giriş, stop, TP1-3, destek/direnç bölgeleri). Ek paket gerekmez.
- **📄 Kısa mod**: yalnızca giriş, stop, hedefler, güç ve uyarılar · **🖥 Görünüm** menüsünden grafik/kısa mod açılıp kapanır
- **🔗 Korelasyon**: sinyalde BTC ile korelasyon · `/corr SOL 4h` BTC ve ETH ile
- **🔎 `/explain BTC 4h`**: sinyal olmasa da sade dille güncel piyasa görünümü + grafik
- **📊 `/markets`** (ve menüden): 24s hacim liderleri · **`/backup`** (yalnızca yönetici): veritabanı yedeği

## Yeni (v6): Mini app — Oto-Bot paneli + Yönetim paneli
Menüde **🤖 Oto-Bot Paneli** butonu (sadece `MINIAPP_URL` doldurulunca görünür) Telegram içinde şık, sekmeli bir
sayfa açar:
- **💼 Cüzdan**: Trust Wallet / MetaMask / Bitget Wallet gibi cüzdanlarla **WalletConnect v2** üzerinden bağlanılır.
  Bağlanan kullanıcının private key'i veya gizli kelimeleri (mnemonic) **hiçbir zaman istenmez, alınmaz, saklanmaz** —
  yalnızca genel (herkese açık) cüzdan adresi okunur, bakiye ve token listesi/logoları buradan gösterilir. Bu bilinçli
  bir güvenlik kararıdır ve değiştirilmeyecektir: seed phrase toplayan hiçbir alan projeye eklenmez.
- **🤖 Oto-Bot**: Otomatik al-sat ayarları (işlem modu, kaldıraç, marj/pozisyon modu, risk limitleri, TP dağılımı,
  gece modu, kademeli giriş, coin listesi). Cüzdan bağlı olmadan "otomatik al-sat" açılamaz. **Bu aşamada ayarlar
  sadece kaydedilir — gerçek emir açan/kapatan işlem motoru henüz devrede değil**, ayrı bir aşamada eklenecek.
- **⚙️ Yönetim** (`admin.html`, sadece `.env`'deki `ADMIN_ID` için): kullanıcı/sinyal/alarm istatistikleri. Erişim,
  tarayıcıdan gelen hiçbir bilgiye güvenmeden, Telegram'ın imzaladığı `initData` sunucu tarafında doğrulanarak
  kontrol edilir — admin olmayan biri linki bulsa bile hiçbir veri alamaz (`dev/test_webauth.py` bunu 11 testle doğrular).

Kurulum: `.env` içindeki `MINIAPP_URL`, `WC_PROJECT_ID`, `MORALIS_API_KEY` adımları için `env.example`'daki açıklamaları
oku. Özetle: Termux'ta ayrı pencerede `cloudflared tunnel --url http://localhost:8080` çalıştır, verdiği https adresi
`MINIAPP_URL`'e yaz, botu yeniden başlat.

## Mini app'i açığa çıkarma (cloudflared, Termux)
Mini app telefonunda `127.0.0.1:8080`'de çalışır; Telegram bunu açabilmek için **https** bir adres ister, bu yüzden
`cloudflared` ile tünel açıyoruz (ücretsiz, hesap gerekmez).
```
uname -m                      # aarch64 çıkarsa (çoğu telefon) arm64 indir
wget https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-arm64 -O ~/cloudflared
chmod +x ~/cloudflared
```
Bot çalışırken (başka bir `tmux` penceresinde, `CTRL`+`B` sonra `C` ile yeni pencere açılır):
```
~/cloudflared tunnel --url http://localhost:8080
```
Çıktıda `https://xxxx-xxx-xxx.trycloudflare.com` gibi bir satır çıkar. Bu adresi `.env`'deki `MINIAPP_URL`'e yaz
(sonunda `/` olmadan), botu yeniden başlat (`CTRL`+`C`, `bash start.sh`). `cloudflared` penceresini kapatma — kapanırsa
mini app adresi de düşer, yeniden açtığında yeni bir adres verir ve `.env`'i tekrar güncellemen gerekir.
`CTRL`+`B` sonra rakam tuşlarıyla `tmux` pencereleri arasında geçersin; `CTRL`+`B` sonra `D` hepsini arka plana alır.

## Otomatik takip ve istatistik
- Her açık sinyal **1 dakikalık kapanmış mumlarla** takip edilir. TP1, TP2, TP3, stop, breakeven, trend dönüşü ve süre dolumu için
  sinyalin altına **yanıt olarak** bildirim gelir.
- Model: pozisyon üçe bölünür (TP1/TP2/TP3'te ⅓); TP1'den sonra stop girişe çekilir. Aynı mumda hem stop hem hedef görülürse
  **stop önce** sayılır (kötümser). Komisyon ve kayma yok → sonuçlar simülasyondur.
- `/stats`: 7g / 30g / tümü, tüm sinyaller veya sadece sana gelenler; TP1/TP2/TP3/SL oranları, net R, yöne/zaman dilimine/güce göre.
- `/open`: açık sinyaller ve anlık R · `/history`: son sinyaller ve sonuçları · `/backtest BTC 1h`: geçmiş simülasyonu.

## Her seferinde çalıştırma (Termux)
```
cd ~/elena-bot
bash start.sh
```
Çökerse 5 sn sonra kendini yeniden başlatır. Termux kapansa da açık kalsın: önce `tmux new -s bot`, sonra yukarıdaki iki komut.
Çıkmak: `CTRL`+`B`, `D` · Geri dönmek: `tmux attach -t bot` · Durdurmak: içine girip `CTRL`+`C`.

## Güncelleme (v5 → v6)
Yeni dosyalar: `miniapp.py`, `webauth.py`, `webapp/` klasörü (index.html, admin.html, app.js, admin.js, style.css).
`pip install -r requirements.txt` ile `aiohttp` de kurulmalı. `aiohttp` kurulu değilse bot yine çalışır, sadece mini
app devre dışı kalır (log'da uyarı görürsün). Mini app'i kullanmak istemiyorsan `.env`'deki `MINIAPP_URL`'i boş bırak,
hiçbir şey değişmez.

## Güncelleme (v4 → v5)
Botu durdur (`CTRL`+`C`). Yeni dosyaları `Dahili depolama/elena-bot` klasörüne kaydet (eskilerin üstüne yaz), sonra:
```
cp ~/storage/shared/elena-bot/*.py ~/storage/shared/elena-bot/start.sh ~/elena-bot/
cd ~/elena-bot && bash start.sh
```
`.env` ve `bot.db` korunur. Eski veritabanı kendiliğinden yeni şemaya geçer. **Yeni dosyalar:** `core.py`, `ta.py`, `render.py`,
`texts2.py`, `texts3.py`, `charts.py`, `texts4.py` (hepsi gerekli). v6 için ayrıca `miniapp.py`, `webauth.py` ve `webapp/` klasörünün tamamı.

## İlk kurulum
1. Termux'u F-Droid'den kur · @BotFather → `/newbot` → token al.
2. `termux-setup-storage`, dosyaları `~/elena-bot` içine kopyala, `pip install -r requirements.txt`.
3. `.env`: `BOT_TOKEN=...`, `ADMIN_ID=...` (@userinfobot'tan), `DONATE_URL=...`. **Token'ı kimseyle paylaşma;** sızdıysa BotFather'da `/revoke`.

## Komutlar
`/start /menu /coins /add /remove /tfs /price /top /calc /history /stats /open /alert /alerts /backtest /corr /explain /markets /test /lang /donate /terms /help /delete`
Yönetici: `/admin`, `/backup`, `/broadcast mesaj` · `/calc bakiye risk% giriş stop` · `/alert BTC 70000`

## Sorun giderme
- `451`/`403`: Binance bu ağdan engelli olabilir → VPN veya sunucu.
- `Conflict`: aynı token ile iki bot çalışıyor → birini kapat.
- Hatalar `bot.log` dosyasına yazılır. Sinyal gelmiyor: trend dönüşü beklenir (1h/4h'de saatlerce normal) → `/test`.

## Geliştirici notu
`STATUS.md` yapılanları ve sıradaki işleri tutar. Çevrimdışı testler: `dev/` klasörü
(`DB_PATH=/tmp/t.db PYTHONPATH=dev/stubs:. python3 dev/test_offline.py` ve `dev/test_ui.py`).

> Bilgilendirme amaçlıdır; yatırım tavsiyesi değildir. Kaldıraçlı işlemler tüm sermayenin kaybına yol açabilir.
