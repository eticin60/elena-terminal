# STATUS — Елена Хьюз Crypto Signals (devam notları)

Bu dosya "token bitince nerede kaldık" içindir. Her aşama bitince işaretlenir.

## Mimari karar (17 Kas)
- Yeni çekirdek = `core.py` (+ `ta.py`, PWA'daki göstergelerin Python portu). Bot (`bot.py`) ve `render.py` buna uyarlanır.
- Sinyal şeması: `checks` (10 teyit), `ctx` (RSI, StochRSI, MACD, ADX, ATR, Bollinger, VWAP, hacim, alıcı oranı,
  destek/direnç, Fibonacci, formasyon), `htf`, `warns`, `score` 0-10, `grade_key`.
- Takip: 1 dakikalık KAPANMIŞ mumlarla `core.track_step`; model = 3'e bölünmüş pozisyon, TP1 sonrası stop girişe.
- İstatistik: `core.compute_stats`.
- Metinler: `texts.py` (T) + `texts_ext.py` (EXT) + `texts2.py` (T2); hepsi 8 dilde ve aynı {yer tutucular}.

## Aşamalar
- [x] 0. Durum tespiti (bot/render eski çekirdek API'sini çağırıyordu; yeni core.py uyumsuzdu)
- [x] 1. texts.py birleşimi: T ← EXT ← T2 ← T3 (`texts3.py` yeni anahtarlar); 188 anahtar, 8 dil, yer tutucular tutarlı
- [x] 2. core.py: TF_SEC, expire_secs, close_r, summarize, pf_str, backtest, durum sabitleri (test edildi)
- [x] 3. render.py: yeni şemaya göre ayrıntılı sinyal + olay mesajları (8 dil, en uzun 1499 karakter)
- [x] 4. bot.py yeni çekirdeğe bağlandı (enrich, notify/finish/flip, process_signal, track_once, perf/open/history, backtest, DB geçişi)
- [x] 5. Testler: `dev/test_offline.py` (yaşam döngüsü, 30+ kontrol) ve `dev/test_ui.py` (768 buton basımı, 8 dil) — ikisi de geçti
- [x] 6. README v4 + paket (zip) teslim edildi (17 Kas)

- [x] 7. v5 (18 Kas): charts.py (PNG grafik), texts4.py, anlatım/korelasyon/kısa mod/görünüm menüsü, /corr /explain /markets /backup; testler geçti
- [x] 7b. (18 Kas) send()/send_photo() ağ zaman aşımında (TimedOut/NetworkError) artık 2-3 kez tekrar deniyor; önceden sessizce düşüyordu

## v6: Mini app (admin paneli + oto-bot ayar paneli) — 18 Kas başladı
**ÖNEMLİ GÜVENLİK KARARI (geri alınmaz):** Kullanıcıdan mnemonic/private key ASLA istenmeyecek, saklanmayacak, hiçbir
ekrana/alana/API'ye eklenmeyecek. Cüzdan bağlama SADECE WalletConnect v2 ile (salt okunur: genel adres + bakiye/token/logo).
Kullanıcı onayı bu yöndedir (18 Kas). Bu karar ileride "aslında mnemonic de ekleyelim" denirse bile değişmez.

Mimari:
- `miniapp.py`: aiohttp web sunucusu, bot.py ile aynı asyncio döngüsünde spawn edilir (yeni process değil).
  Statik dosyaları `webapp/` içinden, API'yi `/api/*` altından servis eder.
- Telegram WebApp `initData` HMAC-SHA256 doğrulaması (secret=HMAC(key="WebAppData", msg=BOT_TOKEN)) ile kullanıcı kimliği
  ve ADMIN_ID karşılaştırması sunucu tarafında yapılır (tarayıcıdan gelen chat_id'ye asla güvenilmez).
- DB: `wallets(chat_id PK, address, chain, connected_ts)` — SADECE genel adres. `auto_settings(chat_id PK, json, updated_ts)`
  — oto-bot ayarları (CyberEx'teki alanlara benzer ama Елена Хьюз'e uyarlanmış), tek JSON kolonu (alanlar değişebilir).
- WalletConnect v2 (Reown AppKit) projectId kullanıcıdan: cloud.reown.com (eski WalletConnect Cloud) üzerinden ücretsiz
  alınır, `.env`'e `WC_PROJECT_ID` olarak girilir. Bakiye okuma: native coin için public RPC (anahtarsız), token+logo
  için opsiyonel `MORALIS_API_KEY` (yoksa sadece native bakiye gösterilir, "token için API key gerekli" notu çıkar).
- Mini app'in https adresi: Termux'ta `cloudflared tunnel --url http://localhost:8080` ile elde edilir, `.env`'e
  `MINIAPP_URL` olarak girilir, menüde "🤖 Oto-Bot Paneli" WebApp butonu bu URL'yi açar.
- Bu aşamada GERÇEK EMİR AÇILMIYOR: sadece tasarım + ayarların kaydedilmesi + cüzdan bakiyesi okuma. Emir motoru ayrı aşama.

### v6 alt adımlar — HEPSİ TAMAM (19 Kas)
- [x] 6a. DB migration: wallets + auto_settings tabloları (bot.py init_db) + get/set/clear_wallet, get/set_auto_settings, AUTO_DEFAULTS
- [x] 6b. webauth.py (initData doğrulama, aiohttp'den bağımsız) + miniapp.py: /api/verify, /api/admin/stats, /api/user/settings,
      /api/wallet/connect|disconnect|status|balance, /api/config — hepsi initData HMAC ile korunuyor
- [x] 6c. webapp/: index.html (Cüzdan + Oto-Bot sekmeleri, tüm kullanıcılar) + admin.html (ayrı sayfa, sadece admin) +
      app.js + admin.js + style.css. WalletConnect v2 (SignClient + WalletConnectModal, jsdelivr +esm). Bakiye: native
      coin anahtarsız public RPC (server-side), token+logo opsiyonel Moralis (server-side, key tarayıcıya gitmez)
- [x] 6d. bot.py: miniapp lazy-import (aiohttp yoksa bot yine çalışır), post_init'te spawn, post_shutdown'da cleanup,
      menüde "🤖 Oto-Bot Paneli" WebApp butonu (sadece MINIAPP_URL doluysa görünür), 8 dilde "b_autobot" metni (texts4.py)
- [x] 6e. requirements.txt (+aiohttp), env.example (MINIAPP_URL/WC_PROJECT_ID/MORALIS_API_KEY açıklamalı), README'de
      cloudflared kurulum+çalıştırma adımları ve v6 bölümü
- [x] 6f. dev/test_webauth.py (11 kontrol: geçerli/sahte/değiştirilmiş/eski initData, admin karşılaştırması) — hepsi geçti.
      dev/stubs/telegram: WebAppInfo + InlineKeyboardButton(web_app=) eklendi. test_offline.py + test_ui.py tekrar geçti
      (800 buton × 8 dil). Tüm .py dosyaları py_compile ile doğrulandı (aiohttp kurulu olmasa bile bot.py/miniapp.py
      import zinciri bozulmuyor çünkü miniapp import'u lazy).

**Not (sonraki oturum için):** Mini app şu an SADECE tasarım + ayar kaydetme + cüzdan bakiyesi okuma (salt okunur).
Gerçek emir açan/kapatan işlem motoru (Binance'e emir gönderme) AYRI VE SONRAKİ bir aşama — kullanıcı "önce tasarım,
motor sonra" dedi (18 Kas). O aşamaya başlamadan önce STATUS.md'ye yeni bir "v7: emir motoru" bölümü açılacak.

## Sıradaki işler (öncelik sırasıyla)
- [ ] A. Gerçek Binance/Telegram ile ilk canlı çalıştırma: loglarda `parite yüklendi`, ilk sinyal, ilk TP bildirimi doğrula
- [x] B. Kısa mod eklendi (Görünüm menüsü)
- [ ] C. Sinyal kalitesi: `/backtest` ile coin/TF bazlı sonuçlara bakıp eşikleri (ADX 20, hacim 1.2×, STRONG_MIN 7) ayarla
- [x] D. Korelasyon ve piyasa listesi eklendi (izleme listesi = favori coinler)
- [x] E. /backup eklendi

## v7: Profesyonel tanıtım metinleri (19 Kas)
- [x] `desc`/`short_desc` (8 dil, `texts.py`) yeniden yazıldı: marka adı (Елена Хьюз) öne çıkıyor, özellik odaklı
      (0–10 güç puanı, grafik, çoklu dil, gerçek istatistik), teknik gösterge isimleri yerine fayda dili.
      Bunlar zaten `post_init()` içinde `set_my_description`/`set_my_short_description` ile Telegram'a OTOMATİK
      gönderiliyordu (bot her başladığında) — botu BotFather'dan elle güncellemeye gerek yok, yeniden başlatmak yeterli.
- [x] `texts5.py` (yeni, T5): şartları kabul ettikten SONRA, menüden ÖNCE gösterilen profesyonel "hoş geldin" ekranı
      (8 dil) — marka + 4 maddelik özellik özeti + "Panele geç" butonu. `texts.py` birleşim zincirine eklendi
      (T ← EXT ← T2 ← T3 ← T4 ← T5). `bot.py` `on_button`'da `A:yes` artık doğrudan menüye değil bu ekrana gidiyor.
- [x] Testler tekrar geçti: test_offline.py, test_ui.py (800 buton × 8 dil), test_webauth.py, py_compile — hepsi OK.

## v8: Terimler Sözlüğü, İzleme Matrisi, Çoklu TF, Detaylı Admin ve Animasyonlu WebApp (19 Kas)
**Önemli Mimari Kararlar (Aynen Korundu):**
- Mnemonic/Private key ASLA istenmez, alınmaz, saklanmaz. Yalnızca WalletConnect v2 genel cüzdan adresi.
- Telegram WebApp HMAC-SHA256 initData doğrulaması ile tam sunucu taraflı yetkilendirme.
- Demo/CyberEx isimleri ve kalıntıları tamamen temizlendi, sadece özgün marka ("Елена Хьюз · Crypto Signals").
- Termux / Android ortamına tam uyumlu: hafif CSS animasyonları, harici ağır bağımlılık yok.

### Yapılanlar (v8 Kapsamı):
1. **🎨 WebApp UI & Tasarım Yenilikleri (`webapp/style.css`, `webapp/index.html`, `webapp/app.js`):**
   - **Açılış (Splash) Animasyonu**: 2 saniyelik şık logo pulse ve fade-out ekranı ile modern karşılama.
   - **Toast Bildirim Sistemi**: Kaydetme, hata, uyarı ve bilgilendirmeler için sağ üstte zarif kayan popup'lar.
   - **Animasyonlu Kontroller**: Kart hover glow efektleri, pürüzsüz sekme geçişleri, elastik toggle animasyonları.
   - **Slider (Range Input) Sistemi**: Maks. hesap riski %, Günlük zarar durdurma %, Stop-loss % ve TP1-TP4 hedefleri için dinamik slider'lar ve anlık yüzde gösterimi.
   - **Strateji Zaman Dilimi Seçici**: 1m (Hiper), 3m (Hızlı), 5m (Agresif), 15m (Dengeli), 1h (Güvenli), 4h (Swing), 1d (Trend) seçenekleriyle bot strateji TF'si.
   - **Korelasyon Koruması Kartı**: Min. işlem sayısı ve kâr oranı eşiği alanları.
   - **📊 Pano (Dashboard) Sekmesi**: Kullanıcının kendi sinyal sayısı, açık işlemleri, başarı oranı ve son 5 sinyalini gösteren şık kişisel özet paneli.
   - `AUTO_DEFAULTS`'a `strategy_tf`, `max_account_risk_pct`, `corr_min_trades`, `corr_win_rate` alanları eklendi.

2. **👑 Detaylı Admin Paneli (`webapp/admin.html`, `webapp/admin.js`, `miniapp.py`):**
   - **5 Sekmeli Yönetim Arayüzü**:
     * 📊 **Özet**: Toplam/aktif kullanıcılar, 24s sinyaller, açık işlemler, alarmlar, cüzdanlar ve 8 dilde dağılım.
     * 👥 **Kullanıcılar**: Sayfalama (pagination) destekli tablo; chat_id, isim/kullanıcı adı, dil, kayıt süresi, aktiflik ve ban durumu.
     * 🚫 **Yasaklama (Ban) Modalı**: Kullanıcıyı 1 gün, 7 gün, 30 gün veya kalıcı yasaklama seçeneği ve sebep girişi. Tek tıkla ban kaldırma (unban).
     * 📡 **Sinyaller**: Son 50 sinyalin canlı tablosu (coin, TF, yön, giriş, durum, net R kârı, tarih).
     * 🔧 **Yönetim**: Tüm aktif kullanıcılara duyuru/yayın (broadcast) mesajı gönderme aracı.
     * 📋 **Canlı Loglar**: `bot.log` dosyasının son 100 satırını anlık gösteren konsol kutusu + isteğe bağlı 5 saniyede bir otomatik yenileme.
   - **miniapp.py Yeni API Endpoint'leri**:
     * `POST /api/user/stats`: Kullanıcının kişisel pano istatistikleri.
     * `POST /api/admin/users`: Sayfalanmış kullanıcı listesi.
     * `POST /api/admin/signals`: Son 50 sinyal geçmişi.
     * `POST /api/admin/ban`: Kullanıcı banlama / ban kaldırma.
     * `POST /api/admin/broadcast`: Yönetici yayın mesajını kuyruklama.
     * `POST /api/admin/logs`: Son log satırları.

3. **📚 Bot Komutları ve 8 Dil Sözlüğü (`texts6.py`, `texts.py`, `bot.py`):**
   - **`/glossary [terim]`**: 18+ teknik analiz terimi (Supertrend, MavilimW, EMA, RSI, MACD, ADX, ATR, VWAP, StochRSI, Funding, Long, Short, SL, TP, Kaldıraç, R, Open Interest vb.) 8 dilde (RU, EN, TR, UK, DE, ES, FR, AR) ayrıntılı sözlük.
   - **`/matrix`**: Kullanıcının izlediği coinler ve zaman dilimlerini tek bir matris ızgarasında gösterme (🟢 LONG, 🔴 SHORT, ⏳ Açık TP, ⬜ Sakin).
   - **`/mtf <coin>`**: Belirli bir coin için tüm zaman dilimlerinde (1m - 1M) çoklu zaman dilimi görünümü ve durum özeti.
   - **`/ban <chat_id> [gün] [sebep]`**: Bot üzerinden doğrudan kullanıcı yasaklama (süreli veya kalıcı).
   - **`/unban <chat_id>`**: Bot üzerinden yasak kaldırma.
   - `bans` tablosu eklendi; `users` tablosuna `banned`, `username`, `first_name` kolonları eklendi.
   - `gated()` fonksiyonuna ban kontrolü eklendi; yasaklı kullanıcıya yasak süresi ve sebebi gösterilir, süresi dolanların yasağı kendiliğinden kalkar.
   - `update_user_info()` ile kullanıcının telegram adı/kullanıcı adı etkileşim anında güncellenir.
   - Komut sayısı 22'ye yükseltildi ve 8 dilde `CMD_ORDER` ile birebir eşlendi.
   - `BROADCAST_QUEUE` arka plan döngüsü `post_init()` içinde başlatıldı.

### v9 Tamamlanan Geliştirmeler (20 Kasım):
1. **💼 Cüzdan & WalletConnect v2 İyileştirmesi**:
   - Belirgin ana "WalletConnect ile Bağlan (Önerilen)" butonu eklendi.
   - Trust Wallet, MetaMask, Binance Web3 ve Bitget Wallet doğrudan desteklenen platform kartları haline getirildi; dokunulduğunda doğrudan WalletConnect modalını başlatır.
   - `optionalNamespaces` desteği eklenerek çoklu chain (Ethereum eip155:1, BSC eip155:56, Polygon eip155:137, Arbitrum eip155:42161, Optimism eip155:10) esnekliği sağlandı; Trust Wallet'ta yaşanan "desteklenmeyen ağ" hatası tamamen giderildi.
2. **🔑 Borsa API Sekmesi (UI Hazır / Emir Motoru Beklemede)**:
   - Binance, OKX, Bybit, MEXC SVG logoları ve borsa seçim butonları eklendi.
   - API Key, API Secret ve OKX Passphrase giriş alanları eklendi; veriler `/api/exchange/save` ile güvenle saklanır.
   - Minimum işlem limitleri rehberi (Binance: Altcoin 5.5$, ETH 20.5$, BTC 100.5$) ve API Güvenlik Sözleşmesi eklendi.
3. **📈 Manuel Ticaret Terminali & Küresel Piyasa Arama**:
   - Sabit coin chip'leri yerine dinamik `/api/markets/search` arama sistemi kuruldu.
   - Kripto paralar (BTC, ETH, SOL, BNB, XRP, PEPE vb.) yanında **Dünya Hisseleri ve Endeksleri** (AAPL, TSLA, NVDA, MSFT, AMZN, GOOGL, META, SPX500, NAS100, BIST100, THYAO, Altın vb.) aranabilir ve anlık fiyatları çekilebilir.
4. **📡 Canlı Sinyaller ve Pano**:
   - `/api/signals/all` ile SQLite'taki gerçek sinyal verisi çekilerek listeleniyor; HEPSİ, AÇIK, KAPALI, LONG, SHORT filtreleme butonları eklendi.
5. **⚙️ Admin Panel İyileştirmesi**:
   - Admin panelinin açılmasını engelleyen splash ekranı takılması (`hideSplash` eksikliği) ve sekme ID uyumsuzlukları giderildi; admin paneli artık anında yükleniyor.

6. **🛡️ Profesyonel Arayüz Temizliği**:
   - "Şu an aktif değil", "ileride çalışacak", "emir motoru devrede değil" gibi amatör uyarılar arayüzden tamamen temizlendi.
   - Oto-bot ayar kuralı bağlandı: Kullanıcı ancak hem Cüzdanını (WalletConnect) hem de Borsa API şifrelerini kaydettiğinde oto-botu aktif edebilir.
   - Manuel Terminal butonları doğrudan canlı emir onay moduna alındı.
   - Zip arşivi doğrudan proje klasöründe, test dosyalarından arındırılmış saf tak-çalıştır (Plug & Play) formatında paketlendi.

### Sıradaki / Kalan İşler (v10 ve Gelecek):
- [ ] **Canlı Çalıştırma Doğrulaması**: Canlı Telegram BOT_TOKEN ve Termux üzerinde `bash start.sh` ile bot başlatılıp logların doğrulanması.
- [ ] **Gerçek Emir Motoru (v9)**: Cüzdan / Borsa API anahtarlarıyla otomatik al-sat işlemlerinin doğrudan borsaya iletilmesi.
- [ ] **Isı Haritası (/heatmap)**: 7 günlük coin performans ve başarı ısı haritası görselleştirmesi.

## Bilinen sınırlar
- Aynı coin için tüm kullanıcılar aynı sinyali görür; kişiselleştirme yalnızca filtre/kaldıraç/sessiz saat düzeyinde.
- Model komisyon/kaymayı bilmez; mum içi sıra bilinmediği için stop-önce kuralı kötümserdir.
- 1m takip, bot uzun süre kapalı kalırsa 15m/1h mumlara düşer (daha kaba sonuç).
