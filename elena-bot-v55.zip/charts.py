"""Bağımlılıksız PNG mum grafiği (yalnızca zlib + struct; Termux'ta ek paket gerekmez).

render_chart(rows, sig) -> PNG baytları. rows: Binance kline satırları (kapanmış mumlar).
Çizilenler: mumlar, stop (SL), giriş (E), TP1-TP3, destek (S) / direnç (R), stop-giriş-hedef bölgeleri.
"""
import struct
import zlib

W, H = 900, 520
PL, PR, PT, PB = 12, 150, 16, 16
BG, GRID = (15, 23, 42), (30, 41, 59)
UP, DN, WICK = (38, 166, 154), (239, 83, 80), (148, 163, 184)
C_SL, C_EN, C_TP, C_SR = (239, 83, 80), (66, 165, 245), (52, 211, 153), (251, 191, 36)

GLYPH = {
    "0": "01110 10001 10011 10101 11001 10001 01110", "1": "00100 01100 00100 00100 00100 00100 01110",
    "2": "01110 10001 00001 00010 00100 01000 11111", "3": "11110 00001 00001 01110 00001 00001 11110",
    "4": "00010 00110 01010 10010 11111 00010 00010", "5": "11111 10000 11110 00001 00001 10001 01110",
    "6": "00110 01000 10000 11110 10001 10001 01110", "7": "11111 00001 00010 00100 01000 01000 01000",
    "8": "01110 10001 10001 01110 10001 10001 01110", "9": "01110 10001 10001 01111 00001 00010 01100",
    ".": "00000 00000 00000 00000 00000 01100 01100",
    "T": "11111 00100 00100 00100 00100 00100 00100", "P": "11110 10001 10001 11110 10000 10000 10000",
    "S": "01111 10000 10000 01110 00001 00001 11110", "L": "10000 10000 10000 10000 10000 10000 11111",
    "E": "11111 10000 10000 11110 10000 10000 11111", "R": "11110 10001 10001 11110 10100 10010 10001",
}
GLYPH = {k: v.split() for k, v in GLYPH.items()}


class Canvas:
    def __init__(self, w, h, bg):
        self.w, self.h = w, h
        self.rows = [bytearray(bytes(bg) * w) for _ in range(h)]

    def rect(self, x0, y0, x1, y1, col, alpha=1.0):
        x0, x1 = max(0, int(x0)), min(self.w - 1, int(x1))
        y0, y1 = max(0, int(y0)), min(self.h - 1, int(y1))
        if x1 < x0 or y1 < y0:
            return
        if alpha >= 1.0:
            seg = bytes(col) * (x1 - x0 + 1)
            for y in range(y0, y1 + 1):
                self.rows[y][x0 * 3:(x1 + 1) * 3] = seg
            return
        for y in range(y0, y1 + 1):
            row = self.rows[y]
            for x in range(x0, x1 + 1):
                i = x * 3
                row[i] = int(row[i] * (1 - alpha) + col[0] * alpha)
                row[i + 1] = int(row[i + 1] * (1 - alpha) + col[1] * alpha)
                row[i + 2] = int(row[i + 2] * (1 - alpha) + col[2] * alpha)

    def hline(self, y, x0, x1, col, dash=0, thick=1):
        y = int(y)
        if not dash:
            self.rect(x0, y, x1, y + thick - 1, col)
            return
        x = int(x0)
        while x < x1:
            self.rect(x, y, min(x + dash, x1), y + thick - 1, col)
            x += dash * 2

    def text(self, x, y, s, col, scale=2):
        for ch in s:
            g = GLYPH.get(ch)
            if g:
                for ry, line in enumerate(g):
                    for rx, bit in enumerate(line):
                        if bit == "1":
                            self.rect(x + rx * scale, y + ry * scale, x + rx * scale + scale - 1,
                                      y + ry * scale + scale - 1, col)
            x += 6 * scale if ch != "." else 4 * scale

    def png(self):
        raw = b"".join(b"\x00" + bytes(r) for r in self.rows)

        def chunk(tag, data):
            body = tag + data
            return struct.pack(">I", len(data)) + body + struct.pack(">I", zlib.crc32(body) & 0xFFFFFFFF)

        return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", self.w, self.h, 8, 2, 0, 0, 0))
                + chunk(b"IDAT", zlib.compress(raw, 6)) + chunk(b"IEND", b""))


def _price_text(p):
    if p >= 1000:
        return f"{p:.1f}"
    if p >= 1:
        return f"{p:.3f}"
    return f"{p:.5f}"


def render_chart(rows, sig, n=70):
    rows = rows[-n:]
    if len(rows) < 10:
        raise ValueError("yetersiz mum")
    o = [float(r[1]) for r in rows]
    h = [float(r[2]) for r in rows]
    lo = [float(r[3]) for r in rows]
    c = [float(r[4]) for r in rows]
    ctx = sig.get("ctx") or {}
    lines = [(sig["sl"], C_SL, "SL", False), (sig["entry"], C_EN, "E", False)]
    lines += [(tp, C_TP, f"TP{i}", False) for i, tp in enumerate(sig["tps"], 1)]
    for key, tag in (("res", "R"), ("sup", "S")):
        if ctx.get(key):
            lines.append((ctx[key]["price"], C_SR, tag, True))

    lows = [min(lo)] + [x[0] for x in lines if not x[3]]
    highs = [max(h)] + [x[0] for x in lines if not x[3]]
    pmin, pmax = min(lows), max(highs)
    span = (pmax - pmin) or pmax * 0.01
    pmin, pmax = pmin - span * 0.04, pmax + span * 0.04

    cv = Canvas(W, H, BG)
    plot_w, plot_h = W - PL - PR, H - PT - PB

    def y_of(p):
        return PT + (pmax - p) / (pmax - pmin) * plot_h

    for i in range(1, 5):  # ızgara
        cv.hline(PT + plot_h * i / 5, PL, PL + plot_w, GRID)
    # bölgeler: giriş↔stop kırmızı, giriş↔TP3 yeşil
    cv.rect(PL, min(y_of(sig["entry"]), y_of(sig["sl"])), PL + plot_w,
            max(y_of(sig["entry"]), y_of(sig["sl"])), C_SL, 0.10)
    cv.rect(PL, min(y_of(sig["entry"]), y_of(sig["tps"][2])), PL + plot_w,
            max(y_of(sig["entry"]), y_of(sig["tps"][2])), C_TP, 0.08)

    cw = plot_w / len(rows)
    bw = max(2, int(cw * 0.62))
    for i in range(len(rows)):
        cx = PL + cw * (i + 0.5)
        col = UP if c[i] >= o[i] else DN
        cv.rect(cx - 1, y_of(h[i]), cx, y_of(lo[i]), WICK)
        top, bot = y_of(max(o[i], c[i])), y_of(min(o[i], c[i]))
        cv.rect(cx - bw // 2, top, cx + bw // 2, max(bot, top + 1), col)

    # çizgiler ve etiketler (etiketler üst üste binmesin)
    placed = []
    for price, col, tag, dash in sorted(lines, key=lambda x: -x[0]):
        y = y_of(price)
        cv.hline(y, PL, PL + plot_w, col, dash=6 if dash else 0, thick=1 if dash else 2)
        ly = y - 7
        for py in placed:
            if abs(ly - py) < 16:
                ly = py + 16
        placed.append(ly)
        cv.text(PL + plot_w + 6, ly, f"{tag} {_price_text(price)}", col, 2)
    return cv.png()
