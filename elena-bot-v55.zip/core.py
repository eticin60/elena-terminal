"""Saf mantık (3. parti paket gerekmez): sinyal analizi, TP/SL takibi, istatistik, risk hesabı."""
import math
import time
from datetime import datetime, timedelta, timezone

import indicators as ind
import ta

# Sessiz saat seçenekleri: {seçenek: (başlangıç_saati, bitiş_saati)}
QUIET = {1: (23, 7), 2: (0, 8), 3: (22, 6)}
MIN_CANDLES = 80          # Supertrend + MavilimW için yeterli geçmiş
MAX_SCORE = 10
STRONG_MIN = 7            # "sadece güçlü" filtresi için asgari puan
CHECKS = ["mavw", "ema200", "vol", "macd", "adx", "rsi", "stoch", "vwap", "htf", "room"]
HTF_MAP = {"1m": "15m", "3m": "15m", "5m": "1h", "15m": "1h", "30m": "4h", "1h": "4h",
           "4h": "1d", "1d": "1w", "1w": "1M", "1M": None}
EXPIRY_H = {"1m": 6, "3m": 12, "5m": 24, "15m": 48, "30m": 72, "1h": 96, "4h": 240,
            "1d": 720, "1w": 1440, "1M": 2160}
TF_SEC = {"1m": 60, "3m": 180, "5m": 300, "15m": 900, "30m": 1800, "1h": 3600,
          "4h": 14400, "1d": 86400, "1w": 604800, "1M": 2592000}
OPEN_STATUS = "open"          # takip ediliyor (hit 0..2)
CLOSED_STATUS = ("closed", "expired")  # closed: reason sl|be|tp3|flip
INFO_STATUS = "info"          # EXIT uyarısı vb.: takip edilmez


def expire_secs(tf):
    return EXPIRY_H.get(tf, 48) * 3600


# ---------------------------------------------------------------- yardımcılar
def _nearest(cands, price):
    """Fiyata en yakın seviye; en az 2 temaslı (anlamlı) seviyeler öncelikli."""
    if not cands:
        return None
    pool = [x for x in cands if x["touches"] >= 2] or cands
    best = min(pool, key=lambda x: abs(x["price"] - price))
    return {"price": best["price"], "touches": best["touches"],
            "dist": (best["price"] - price) / price * 100}


def grade_key(score):
    return "a" if score >= 8 else "b" if score >= 6 else "c" if score >= 4 else "d"


# ---------------------------------------------------------------- analiz
def analyze(rows, market, force=False):
    """Kapanmış mumlardan sinyal üretir. Supertrend yön değiştirmediyse None döner."""
    if len(rows) < MIN_CANDLES:
        return None
    ot = [int(r[0]) for r in rows]
    h = [float(r[2]) for r in rows]
    l = [float(r[3]) for r in rows]
    c = [float(r[4]) for r in rows]
    v = [float(r[5]) for r in rows]
    up, dn, trend, _ = ind.supertrend(h, l, c, 10, 3.0)
    k = len(c) - 1
    if up[k - 1] is None or dn[k - 1] is None or (trend[k] == trend[k - 1] and not force):
        return None  # ucuz çıkış: yön değişmediyse ağır hesaplara girme
    long = trend[k] == 1
    entry = c[k]
    sl = up[k] if long else dn[k]
    if sl is None or entry <= 0 or (long and sl >= entry) or (not long and sl <= entry):
        return None
    risk = abs(entry - sl)
    sl_pct = risk / entry * 100

    mav = ind.mavilim(c)
    e9, e21, e200 = ta.ema(c, 9), ta.ema(c, 21), ta.ema(c, 200)
    rs = ta.rsi(c, 14)
    bu, _bm, bl = ta.bollinger(c, 20, 2)
    _ml, _ms, mh = ta.macd(c)
    sk, sd = ta.stoch_rsi(c)
    at = ta.atr(h, l, c, 14)
    ax, pdi, mdi = ta.adx(h, l, c, 14)

    avg_v = sum(v[k - 20:k]) / 20 if k >= 20 else 0.0
    vol_ratio = v[k] / avg_v if avg_v > 0 else None
    flow_buy = None
    if len(rows[k]) > 9 and v[k] > 0:
        try:
            flow_buy = max(0.0, min(100.0, float(rows[k][9]) / v[k] * 100))
        except (TypeError, ValueError):
            flow_buy = None

    atr_pct = at[k] / entry * 100 if at[k] else None
    tol = min(1.5, max(0.15, (atr_pct or 0.5) * 0.4))
    hh3, ll3 = ta.find_pivots(h[-300:], l[-300:], 4, 4)
    res = _nearest([x for x in ta.cluster_levels(hh3, tol) if x["price"] > entry], entry)
    sup = _nearest([x for x in ta.cluster_levels(ll3, tol) if x["price"] < entry], entry)

    h1, l1, c1, v1 = h[-150:], l[-150:], c[-150:], v[-150:]
    vw = ta.vwap(h1, l1, c1, v1)[-1]
    fibs = ta.fib_levels(h1, l1)
    fib = None
    if fibs[0][1] > fibs[-1][1]:
        r_, p_ = min(fibs, key=lambda x: abs(x[1] - entry))
        fib = {"ratio": r_, "price": p_, "dist": (p_ - entry) / entry * 100}
    hh1, ll1 = ta.find_pivots(h1, l1, 4, 4)
    pats = ta.detect_patterns(h1, l1, c1, hh1, ll1)

    pb = None
    if bu[k] is not None and bu[k] > bl[k]:
        pb = (c[k] - bl[k]) / (bu[k] - bl[k])
    bb_pos = None if pb is None else "upper" if pb >= 0.8 else "lower" if pb <= 0.2 else "mid"

    def side_ok(cond_long, cond_short, *vals):
        if any(x is None for x in vals):
            return None
        return bool(cond_long if long else cond_short)

    tp1 = entry + (risk if long else -risk)
    opp = res if long else sup
    room_ok = True if opp is None else bool(opp["price"] > tp1 if long else opp["price"] < tp1)
    mh_k, mh_p = mh[k], mh[k - 1]
    checks = {
        "mavw": side_ok(mav[k] is not None and mav[k - 1] is not None and mav[k] > mav[k - 1],
                        mav[k] is not None and mav[k - 1] is not None and mav[k] < mav[k - 1],
                        mav[k], mav[k - 1]),
        "ema200": side_ok(e200[k] is not None and c[k] > e200[k],
                          e200[k] is not None and c[k] < e200[k], e200[k]),
        "vol": None if vol_ratio is None else vol_ratio >= 1.2,
        "macd": side_ok(mh_k is not None and mh_p is not None and mh_k > mh_p,
                        mh_k is not None and mh_p is not None and mh_k < mh_p, mh_k, mh_p),
        "adx": side_ok(ax[k] is not None and pdi[k] is not None and ax[k] >= 20 and pdi[k] > mdi[k],
                       ax[k] is not None and mdi[k] is not None and ax[k] >= 20 and mdi[k] > pdi[k],
                       ax[k], pdi[k]),
        "rsi": side_ok(rs[k] is not None and 40 < rs[k] < 70, rs[k] is not None and 30 < rs[k] < 60, rs[k]),
        "stoch": side_ok(sk[k] is not None and sk[k] < 80, sk[k] is not None and sk[k] > 20, sk[k]),
        "vwap": side_ok(vw is not None and c[k] > vw, vw is not None and c[k] < vw, vw),
        "htf": None,
        "room": room_ok,
    }
    ctx = {
        "rsi": rs[k], "stoch_k": sk[k], "stoch_d": sd[k], "macd_hist": mh_k,
        "macd_rising": None if mh_k is None or mh_p is None else mh_k > mh_p,
        "adx": ax[k], "pdi": pdi[k], "mdi": mdi[k], "atr_pct": atr_pct, "bb_pb": pb, "bb_pos": bb_pos,
        "vwap": vw, "vwap_dist": None if vw is None else (c[k] - vw) / vw * 100,
        "vol_ratio": vol_ratio, "flow_buy": flow_buy,
        "ema_bull": None if e9[k] is None or e21[k] is None else e9[k] > e21[k],
        "mavw_up": None if mav[k] is None or mav[k - 1] is None else mav[k] > mav[k - 1],
        "e200": e200[k], "above_e200": None if e200[k] is None else c[k] > e200[k],
        "res": res, "sup": sup, "fib": fib, "patterns": pats, "trend_up": long,
        "chg10": ((c[k] / float(rows[k - 9][1]) - 1) * 100) if k >= 9 and float(rows[k - 9][1]) > 0 else None,
    }
    sign = 1 if long else -1
    side = ("LONG" if long else "SHORT") if market == "futures" else ("BUY" if long else "EXIT")
    sig = {
        "market": market, "side": side, "entry": entry, "sl": sl, "sl_pct": sl_pct,
        "tps": [entry + sign * risk * m for m in (1, 2, 3)],
        "lev": max(1, min(125, int(30 / sl_pct))),  # stop'ta marjın ~%30'u risk
        "time": ot[k], "close_ms": int(rows[k][6]),
        "checks": checks, "ctx": ctx, "htf": None, "score": 0, "warns": [],
    }
    return finalize(sig, None)


def finalize(sig, htf=None):
    """Üst zaman dilimi teyidini ekler; puan ve uyarıları yeniden hesaplar."""
    long = sig["side"] in ("LONG", "BUY")
    ck, ctx = sig["checks"], sig["ctx"]
    if htf and htf.get("trend") in (1, -1):
        sig["htf"] = htf
        ck["htf"] = (htf["trend"] == 1) == long
    else:
        sig["htf"] = None
        ck["htf"] = None
    sig["score"] = sum(1 for key in CHECKS if ck.get(key) is True)
    warns = []
    if ck.get("room") is False:
        warns.append("w_blocked")
    if ctx.get("adx") is not None and ctx["adx"] < 20:
        warns.append("w_adx_weak")
    if ck.get("htf") is False:
        warns.append("w_htf_against")
    rs = ctx.get("rsi")
    if rs is not None and long and rs >= 70:
        warns.append("w_rsi_long")
    if rs is not None and not long and rs <= 30:
        warns.append("w_rsi_short")
    if ctx.get("vol_ratio") is not None and ctx["vol_ratio"] < 0.8:
        warns.append("w_vol_low")
    sig["warns"] = warns
    return sig


def htf_trend(rows):
    """Üst zaman diliminde son kapanmış mumdaki Supertrend yönü (1 yukarı, -1 aşağı)."""
    if len(rows) < 30:
        return None
    h = [float(r[2]) for r in rows]
    l = [float(r[3]) for r in rows]
    c = [float(r[4]) for r in rows]
    return ind.supertrend(h, l, c, 10, 3.0)[2][-1]


def sample_signal():
    """/test için eksiksiz örnek sinyal."""
    entry, sl = 65000.5, 64000.2
    risk = entry - sl
    return {
        "market": "futures", "side": "LONG", "symbol": "BTCUSDT", "tf": "15m", "entry": entry, "sl": sl,
        "sl_pct": risk / entry * 100, "tps": [entry + risk * m for m in (1, 2, 3)], "lev": 19,
        "time": 0, "close_ms": int(time.time() * 1000), "score": 8, "htf": {"tf": "1h", "trend": 1},
        "checks": {"mavw": True, "ema200": True, "vol": True, "macd": True, "adx": True, "rsi": True,
                   "stoch": False, "vwap": True, "htf": True, "room": False},
        "warns": ["w_blocked"],
        "ctx": {"rsi": 58.2, "stoch_k": 83.0, "stoch_d": 78.4, "macd_hist": 12.4, "macd_rising": True,
                "adx": 27.1, "pdi": 29.5, "mdi": 14.2, "atr_pct": 0.9, "bb_pb": 0.72, "bb_pos": "mid",
                "vwap": 64820.0, "vwap_dist": 0.28, "vol_ratio": 1.8, "flow_buy": 62.0, "ema_bull": True,
                "mavw_up": True, "e200": 63100.0, "above_e200": True,
                "res": {"price": 66380.0, "touches": 4, "dist": 2.12},
                "sup": {"price": 64110.0, "touches": 3, "dist": -1.37},
                "fib": {"ratio": 0.618, "price": 64790.0, "dist": -0.32},
                "patterns": [{"key": "pat_db", "bias": "bull"}], "trend_up": True, "chg10": 2.4},
    }


# ---------------------------------------------------------------- TP/SL takibi
def r_model(hit, reason):
    """Model: pozisyon üçe bölünür, TP1/TP2/TP3'te kapanır; TP1 sonrası stop girişe çekilir."""
    if hit <= 0:
        return -1.0 if reason == "sl" else 0.0
    return {1: 1 / 3, 2: 1.0, 3: 2.0}[min(hit, 3)]


def track_step(state, candles):
    """1 dakikalık KAPANMIŞ mumlarla sinyali ilerletir.

    state: side, entry, tps[3], hit, stop, cursor(ms). candles: [(open_ms, high, low)] artan sırada.
    Aynı mumda hem stop hem hedef görülürse stop önce sayılır (kötümser). TP1 sonrası stop,
    bir SONRAKİ mumdan itibaren girişe çekilir. Döner: (yeni_state, olaylar, kapanış_nedeni|None).
    """
    long = state["side"] in ("LONG", "BUY")
    hit, stop, cursor = state["hit"], state["stop"], state["cursor"]
    events, closed = [], None
    for open_ms, hi, lo in candles:
        if open_ms < cursor:
            continue
        if (lo <= stop) if long else (hi >= stop):
            closed = "sl" if hit == 0 else "be"
            events.append(("stop", closed))
            cursor = open_ms + 60000
            break
        while hit < 3:
            lvl = state["tps"][hit]
            if not ((hi >= lvl) if long else (lo <= lvl)):
                break
            hit += 1
            events.append(("tp", hit))
        if hit >= 1:
            stop = state["entry"]
        cursor = open_ms + 60000
        if hit >= 3:
            closed = "tp3"
            break
    return dict(state, hit=hit, stop=stop, cursor=cursor), events, closed


def compute_stats(rows):
    """rows: dict benzeri (side, tf, score, status, hit, r). Özet istatistik sözlüğü döner."""
    out = {"total": len(rows), "open": 0, "noresult": 0, "resolved": 0, "wins": 0,
           "tp": [0, 0, 0], "sl": 0, "net": 0.0, "by_side": {}, "by_tf": {}, "by_grade": {}}

    def bump(group, key, win):
        n, w = out[group].get(key, (0, 0))
        out[group][key] = (n + 1, w + (1 if win else 0))

    for r in rows:
        st, hit = r["status"], int(r["hit"] or 0)
        if st == "open":
            out["open"] += 1
            continue
        if st == "expired" and hit == 0:
            out["noresult"] += 1
            continue
        if r.get("reason") == "flip" and hit == 0:  # trend döndü, ne hedef ne stop: sonuçsuz say
            out["noresult"] += 1
            out["net"] += float(r["r"] or 0.0)
            continue
        if st not in ("closed", "expired"):
            continue
        win = hit >= 1
        out["resolved"] += 1
        out["wins"] += 1 if win else 0
        for n in range(3):
            if hit >= n + 1:
                out["tp"][n] += 1
        if not win:
            out["sl"] += 1
        out["net"] += float(r["r"] or 0.0)
        sc = int(r["score"] or 0)
        bump("by_side", r["side"], win)
        bump("by_tf", r["tf"], win)
        bump("by_grade", "A" if sc >= 8 else "B" if sc >= 6 else "C", win)
    return out


def close_r(side, entry, risk, hit, price):
    """Trend dönüşü / süre dolumunda toplam R: realize edilen paylar + kalan pay güncel fiyattan."""
    if risk <= 0 or entry <= 0 or price is None:
        return r_model(hit, "be")
    long = side in ("LONG", "BUY")
    r_px = ((price - entry) if long else (entry - price)) / risk
    r_px = max(0.0, min(3.0, r_px)) if hit >= 1 else max(-1.0, min(3.0, r_px))
    remaining = 1.0 - min(max(hit, 0), 3) / 3.0
    return r_model(hit, "be") + remaining * r_px


def summarize(rs):
    """R listesi → n, w, l, win%, avg, tot, pf (kar faktörü, None = sonsuz)."""
    n = len(rs)
    wins = [x for x in rs if x > 0]
    loss = [x for x in rs if x <= 0]
    gl = abs(sum(loss))
    return {"n": n, "w": len(wins), "l": len(loss), "win": (len(wins) / n * 100) if n else 0.0,
            "avg": (sum(rs) / n) if n else 0.0, "tot": sum(rs),
            "pf": (sum(wins) / gl) if gl > 0 else None}


def pf_str(s):
    if s["pf"] is None:
        return "∞" if s["w"] else "—"
    return f"{s['pf']:.2f}"


def backtest(rows, market, max_signals=400):
    """Aynı kurallarla geçmiş mumlarda simülasyon (mum içi sıra bilinmez → stop önce, kötümser).

    rows: Binance kline satırları (kapanmış mumlar). Döner: {"rs": [R...], "dd": max_düşüş_R}.
    """
    rs, i, n = [], MIN_CANDLES, len(rows)
    while i < n and len(rs) < max_signals:
        sig = analyze(rows[:i + 1], market)
        if not sig or sig["side"] == "EXIT":
            i += 1
            continue
        state = {"side": sig["side"], "entry": sig["entry"], "tps": sig["tps"], "hit": 0,
                 "stop": sig["sl"], "cursor": int(rows[i][0]) + 1}
        cs = [(int(r[0]), float(r[2]), float(r[3])) for r in rows[i + 1:]]
        state, _ev, closed = track_step(state, cs)
        risk = abs(sig["entry"] - sig["sl"])
        if closed:
            r = r_model(state["hit"], "sl" if closed == "sl" else "be")
        elif cs:  # veri bitti → son kapanıştan değerle
            r = close_r(sig["side"], sig["entry"], risk, state["hit"], float(rows[-1][4]))
            i = n
        else:
            break
        rs.append(r)
        # aynı sinyalin kapandığı muma kadar ilerle (üst üste binmesin)
        end = state["cursor"]
        while i < n and int(rows[i][0]) < end:
            i += 1
    peak = cum = dd = 0.0
    for r in rs:
        cum += r
        peak = max(peak, cum)
        dd = max(dd, peak - cum)
    return {"rs": rs, "dd": dd}


# ---------------------------------------------------------------- korelasyon
def returns(closes):
    return [closes[i] / closes[i - 1] - 1 for i in range(1, len(closes)) if closes[i - 1] > 0]


def pearson(a, b):
    n = min(len(a), len(b))
    if n < 10:
        return None
    a, b = a[-n:], b[-n:]
    ma, mb = sum(a) / n, sum(b) / n
    va = sum((x - ma) ** 2 for x in a)
    vb = sum((y - mb) ** 2 for y in b)
    if va <= 0 or vb <= 0:
        return None
    return sum((x - ma) * (y - mb) for x, y in zip(a, b)) / math.sqrt(va * vb)


def corr_rows(rows_a, rows_b, n=50):
    """İki kline listesinin ortak mumları üzerinden son n getirinin Pearson korelasyonu (yoksa None)."""
    ca = {int(r[0]): float(r[4]) for r in rows_a}
    cb = {int(r[0]): float(r[4]) for r in rows_b}
    common = sorted(set(ca) & set(cb))[-(n + 1):]
    if len(common) < 11:
        return None
    return pearson(returns([ca[t] for t in common]), returns([cb[t] for t in common]))


def corr_label(c):
    return "hi" if abs(c) >= 0.7 else "mid" if abs(c) >= 0.4 else "low"


# ---------------------------------------------------------------- risk ve zaman
def calc_position(balance, risk_pct, entry, stop):
    """Risk bazlı pozisyon büyüklüğü. Geçersiz girdide None."""
    vals = (balance, risk_pct, entry, stop)
    if any(not math.isfinite(x) or x <= 0 for x in vals) or risk_pct > 100 or entry == stop:
        return None
    risk = balance * risk_pct / 100
    dist = abs(entry - stop) / entry * 100
    size = risk / (dist / 100)
    return {"risk": risk, "dist": dist, "size": size, "qty": size / entry,
            "lev": max(1.0, math.ceil(size / balance * 10) / 10)}


def in_quiet(opt, tz, now=None):
    """Kullanıcının yerel saati sessiz saat aralığında mı?"""
    if opt not in QUIET:
        return False
    now = now or datetime.now(timezone.utc)
    hour = (now + timedelta(hours=tz)).hour
    s, e = QUIET[opt]
    return (hour >= s or hour < e) if s > e else (s <= hour < e)


def fmt_big(x):
    x = float(x)
    for div, suf in ((1e9, "B"), (1e6, "M"), (1e3, "K")):
        if abs(x) >= div:
            return f"{x / div:.2f}{suf}"
    return f"{x:.0f}"
