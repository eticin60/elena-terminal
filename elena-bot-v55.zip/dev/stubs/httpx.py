class AsyncClient:
    def __init__(self, *a, **k): pass
    async def aclose(self): pass
