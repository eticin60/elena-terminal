class BotCommand:
    def __init__(s, c, d): s.c, s.d = c, d
class InlineKeyboardButton:
    def __init__(s, text, callback_data=None, url=None, web_app=None):
        s.text, s.callback_data, s.url, s.web_app = text, callback_data, url, web_app
class WebAppInfo:
    def __init__(s, url): s.url = url
class MenuButtonWebApp:
    def __init__(s, text, web_app): s.text, s.web_app = text, web_app
class MenuButtonDefault:
    def __init__(s): pass
class InlineKeyboardMarkup:
    def __init__(s, rows): s.rows = rows
class LinkPreviewOptions:
    def __init__(s, **k): pass
class ReplyParameters:
    def __init__(s, message_id=None, **k): s.message_id = message_id
class Update: ALL_TYPES = None
