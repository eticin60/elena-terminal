class ParseMode: HTML = "HTML"
