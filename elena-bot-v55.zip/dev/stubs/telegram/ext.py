class Application: pass
class CallbackQueryHandler: pass
class CommandHandler: pass
class ContextTypes: DEFAULT_TYPE = None
