"""Çevrimdışı uçtan uca test. Çalıştırma (proje klasöründe):
   DB_PATH=/tmp/t.db PYTHONPATH=dev/stubs:. python3 dev/test_offline.py
Sahte Telegram/Binance ile tarama → sinyal → TP/SL takibi → istatistik zincirini dener."""
import asyncio, math, os, random, re, sqlite3, sys, tempfile, time

_default_db = os.path.join(tempfile.gettempdir(), "elena_test.db")
os.environ.setdefault("DB_PATH", _default_db)
if os.path.exists(os.environ["DB_PATH"]):
    try: os.remove(os.environ["DB_PATH"])
    except OSError: pass
import bot, core, render
from texts import LANGS, T, TF_LIST

FAILS = []
def check(cond, msg):
    print(("  OK  " if cond else "  HATA ") + msg)
    if not cond: FAILS.append(msg)

# ---------- sahte Telegram
class FakeBot:
    def __init__(s): s.sent = []; s.n = 1000; s.photos = []
    async def send_photo(s, cid, photo, **kw):
        s.n += 1
        s.photos.append({"cid": cid, "file": isinstance(photo, str) and "id" or "upload"})
        class P: file_id = "FID%d" % len(s.photos)
        class M: message_id = s.n; photo = [P()]
        return M()
    async def send_message(s, cid, text, **kw):
        s.n += 1
        rp = kw.get("reply_parameters")
        s.sent.append({"cid": cid, "text": text, "id": s.n, "reply": rp.message_id if rp else None, "silent": kw.get("disable_notification")})
        class M: message_id = s.n
        return M()
class FakeApp:
    def __init__(s): s.bot = FakeBot()
app = FakeApp()

# ---------- sahte Binance
class Resp:
    def __init__(s, j): s._j = j; s.status_code = 200
    def json(s): return s._j
    def raise_for_status(s): pass
class FakeClient:
    def __init__(s): s.klines = {}; s.one_min = []
    async def get(s, url, params=None):
        params = params or {}
        if "klines" in url:
            if params.get("interval") == "1m" and "startTime" in params:
                return Resp([c for c in s.one_min if c[0] >= params["startTime"]])
            return Resp(s.klines.get(params.get("interval"), s.klines["*"]))
        if "premiumIndex" in url: return Resp({"lastFundingRate": "0.0001"})
        if "openInterest" in url: return Resp({"openInterest": "123456"})
        if "globalLongShort" in url: return Resp([{"longShortRatio": "1.1"}])
        return Resp([])
client = FakeClient()

def series(n, seed, step=900_000, end_ms=None):
    random.seed(seed); p = 100.0; rows = []
    for i in range(n):
        o = p; p *= 1 + random.gauss(0.0004 * math.sin(i / 40), 0.012)
        h = max(o, p) * 1.003; l = min(o, p) * 0.997; v = random.random() * 900 + 100
        rows.append([0, str(o), str(h), str(l), str(p), str(v), 0, "0", 0, str(v * random.uniform(.3, .7))])
    end_ms = end_ms or int(time.time() * 1000) - 60_000
    for i, r in enumerate(rows):
        r[6] = end_ms - (n - 1 - i) * step; r[0] = r[6] - step + 1
    return rows

def find_flip(market, want=None):
    for seed in range(1, 400):
        rows = series(300, seed)
        for end in range(150, 300):
            s = core.analyze(rows[:end], market)
            if s and (want is None or s["side"] == want) and end == 299:  # son mumda dönüş
                return rows
        # son mum değilse sondan kırp
        for end in range(299, 150, -1):
            s = core.analyze(rows[:end], market)
            if s and (want is None or s["side"] == want):
                cut = rows[:end]; shift = int(time.time() * 1000) - 60_000 - int(cut[-1][6])
                for r in cut: r[0] += shift; r[6] += shift
                return cut
    raise SystemExit("flip bulunamadı")

async def main():
    bot.init_db()
    print("== 1. DB: v3 taslak durumlarının taşınması")
    db = bot.db
    db.execute("INSERT INTO signals(ts,ctime,market,symbol,tf,side,entry,sl,tp1,status) VALUES(1,1,'futures','OLDUSDT','1h','LONG',1,.9,1.1,'tp2')")
    db.execute("INSERT INTO signals(ts,ctime,market,symbol,tf,side,entry,sl,tp1,status) VALUES(1,2,'futures','OLD2USDT','1h','LONG',1,.9,1.1,'sl')")
    db.commit(); bot.init_db()
    r1 = db.execute("SELECT status,reason FROM signals WHERE symbol='OLDUSDT'").fetchone(); r2 = db.execute("SELECT status,reason FROM signals WHERE symbol='OLD2USDT'").fetchone()
    check(tuple(r1) == ("open", None) and tuple(r2) == ("closed", "sl"), f"tp2→open, sl→closed/sl {tuple(r1)} {tuple(r2)}")
    db.execute("DELETE FROM signals"); db.commit()

    # kullanıcılar: 8 dilin hepsinden biri, hepsi kabul etmiş
    for i, lg in enumerate(LANGS):
        bot.ensure_user(100 + i, lg); bot.set_field(100 + i, "accepted", 1); bot.set_field(100 + i, "lang", lg)
        bot.set_field(100 + i, "market", "futures")
    bot.set_field(103, "strong_only", 1)   # uk: sadece güçlü
    bot.set_field(104, "notify_track", 0)  # de: TP/SL bildirimi kapalı
    bot.set_field(105, "quiet", 1); bot.set_field(105, "tz", 0)
    bot.set_field(106, "chart", 0)     # es: grafik kapalı
    bot.set_field(107, "compact", 1)   # fr: kısa mod

    print("== 2. Tarama → sinyal (futures)")
    rows = find_flip("futures"); client.klines = {"*": rows, "1h": rows}
    for i in range(8):
        for s in ("BTCUSDT",): bot.db.execute("INSERT OR IGNORE INTO coins VALUES(?,?)", (100 + i, s))
        bot.db.execute("INSERT OR IGNORE INTO tfs VALUES(?,?)", (100 + i, "15m"))
    bot.db.commit()
    await bot.scan_tf(app, client, "15m")
    sig = db.execute("SELECT * FROM signals").fetchall()
    check(len(sig) == 2 and all(x["status"] == "open" for x in sig), f"BTC+ETH (varsayılan coinler) için 2 açık sinyal ({len(sig)})")
    s = [x for x in sig if x["symbol"] == "BTCUSDT"][0]; print("   yön", s["side"], "puan", s["score"], "derece", s["grade"])
    got = [m for m in app.bot.sent if m["reply"] is None]
    strong_ok = s["score"] >= core.STRONG_MIN
    check(len(got) == 2 * (8 if strong_ok else 7), f"{len(got)} mesaj = 2 coin × kullanıcı (güçlü filtre {'geçti' if strong_ok else 'engelledi'})")
    check(all("{" not in m["text"] and len(m["text"]) < 4096 for m in got), "mesajlar yer tutucusuz ve < 4096")
    check(db.execute("SELECT COUNT(*) FROM deliveries").fetchone()[0] == len(got), "deliveries kaydı = gönderim")
    n_before = len(app.bot.sent); await bot.scan_tf(app, client, "15m")
    check(db.execute("SELECT COUNT(*) FROM signals").fetchone()[0] == 2 and len(app.bot.sent) == n_before, "aynı mum için ikinci sinyal/mesaj yok (tekrar engeli)")
    ph = app.bot.photos
    check(len(ph) > 0 and all(p["cid"] != 106 for p in ph), f"grafik gönderildi ({len(ph)}), grafik kapalı kullanıcıya gitmedi")
    check(sum(1 for p in ph if p["file"] == "upload") == 2, "her sinyal için PNG yalnızca 1 kez yüklendi, diğerleri file_id ile")
    fr = [m for m in got if m["cid"] == 107][0]["text"]; ru = [m for m in got if m["cid"] == 100][0]["text"]
    check(len(fr) < len(ru) * 0.6 and "TP1" in fr, f"kısa mod daha kısa ({len(fr)} < {len(ru)}) ve TP içeriyor")
    check("📖" in ru and "📖" not in fr, "tam modda 'Ne oluyor?' anlatımı var, kısa modda yok")
    quiet = [m for m in got if m["cid"] == 105]
    print("   sessiz saat kullanıcısı silent =", quiet[0]["silent"] if quiet else None)

    print("== 3. Takip: TP1→TP2→TP3")
    sid = s["id"]; long_ = s["side"] in ("LONG", "BUY"); sign = 1 if long_ else -1
    base = int(time.time() * 1000) - 900_000
    db.execute("UPDATE signals SET last_check=? WHERE market='futures'", (base,)); db.commit()
    tps = [s["tp1"], s["tp2"], s["tp3"]]
    def c1(i, hi, lo, cl=None): return [base + i * 60000, "0", str(hi), str(lo), str(cl or (hi + lo) / 2), "1", base + i * 60000 + 59999]
    ent = s["entry"]; mid = lambda a: ent + sign * abs(a - ent) * 0.0
    pts = [(tps[0], ent + 0.2 * (tps[0] - ent)), (tps[1], tps[0]), (tps[2], tps[1])]
    def cand(i, pair): return c1(i, max(pair), min(pair))
    client.one_min = [cand(0, pts[0]), cand(1, pts[1]), cand(2, pts[2])]
    app.bot.sent.clear()
    await bot.track_once(app, client)
    row = db.execute("SELECT * FROM signals WHERE id=?", (sid,)).fetchone()
    check(row["status"] == "closed" and row["reason"] == "tp3" and row["tp_hit"] == 3 and abs(row["r_result"] - 2.0) < 1e-9, f"TP3 kapanış: {row['status']}/{row['reason']} hit={row['tp_hit']} r={row['r_result']}")
    check(db.execute("SELECT COUNT(*) FROM signals WHERE reason='tp3'").fetchone()[0] == 2, "BTC ve ETH sinyalleri ikisi de TP3 ile kapandı")
    ev = [m for m in app.bot.sent]
    check(all(m["reply"] for m in ev), "olay mesajları orijinal sinyale yanıt")
    check(not any(m["cid"] == 104 for m in ev), "notify_track=0 kullanıcısına olay gitmedi")
    kinds = len({m["cid"] for m in ev})
    print("   olay mesajı:", len(ev), "kullanıcı:", kinds)
    check(len(ev) == 6 * kinds and kinds == 7, "7 kullanıcı × 2 sinyal × (TP1, TP2, TP3) = 42 olay mesajı")
    check(any("TP1" in m["text"] for m in ev) and any("TP3" in m["text"] for m in ev), "TP1 ve TP3 mesajları içerikte")

    print("== 4. Yeni sinyal: stop (SL) ve breakeven")
    def new_signal(sym, ctime, side="LONG", tf="15m", market="futures"):
        cur = db.execute("INSERT INTO signals(ts,ctime,market,symbol,tf,side,entry,sl,tp1,tp2,tp3,score,grade,lev,sl_pct,status,tp_hit,sl_cur,last_check) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (int(time.time()), ctime, market, sym, tf, side, 100, 99, 101, 102, 103, 8, "A", 10, 1.0, "open", 0, 99, ctime + 1))
        db.commit(); sd = cur.lastrowid
        db.execute("INSERT INTO deliveries VALUES(?,?,?)", (sd, 100, 5000 + sd)); db.commit(); return sd
    t0 = int(time.time() * 1000) - 600_000
    sl_id = new_signal("SLUSDT", t0); be_id = new_signal("BEUSDT", t0 + 1)
    def k(sym_candles): return sym_candles
    class C2(FakeClient):
        async def get(s, url, params=None):
            params = params or {}
            if params.get("interval") == "1m" and "startTime" in params:
                sym = params["symbol"]; mk = lambda i, hi, lo: [t0 + i * 60000, "0", str(hi), str(lo), str((hi + lo) / 2), "1", t0 + i * 60000 + 59999]
                data = {"SLUSDT": [mk(1, 100.5, 98.5)],
                        "BEUSDT": [mk(1, 101.2, 100.1), mk(2, 100.9, 99.9)]}.get(sym, [])
                return Resp([c for c in data if c[0] >= params["startTime"]])
            return await FakeClient.get(s, url, params)
    app.bot.sent.clear(); await bot.track_once(app, C2())
    a = db.execute("SELECT * FROM signals WHERE id=?", (sl_id,)).fetchone(); b = db.execute("SELECT * FROM signals WHERE id=?", (be_id,)).fetchone()
    check((a["status"], a["reason"], a["r_result"]) == ("closed", "sl", -1.0), f"SL: {a['status']}/{a['reason']}/{a['r_result']}")
    check((b["status"], b["reason"], b["tp_hit"]) == ("closed", "be", 1) and abs(b["r_result"] - 1 / 3) < 1e-9, f"BE: {b['status']}/{b['reason']}/hit={b['tp_hit']}/r={b['r_result']}")

    print("== 5. Flip ve süre dolumu")
    fl_id = new_signal("FLIPUSDT", t0 + 2); ex_id = new_signal("EXPUSDT", t0 + 3)
    db.execute("UPDATE signals SET ts=? WHERE id=?", (int(time.time()) - core.expire_secs("15m") - 100, ex_id)); db.commit()
    await bot.close_flipped(app, "futures", "FLIPUSDT", "15m", 100.4)
    f = db.execute("SELECT * FROM signals WHERE id=?", (fl_id,)).fetchone()
    check((f["status"], f["reason"]) == ("closed", "flip") and abs(f["r_result"] - 0.4) < 1e-9, f"flip: r={f['r_result']}")
    bot.PRICES[("futures", "EXPUSDT")] = 100.2
    await bot.track_once(app, C2())
    e = db.execute("SELECT * FROM signals WHERE id=?", (ex_id,)).fetchone()
    check(e["status"] == "expired" and e["reason"] == "expired", f"süre dolumu: {e['status']} r={e['r_result']:.2f}")

    print("== 6. İstatistik / açık sinyaller / geçmiş, 8 dil")
    new_signal("OPENUSDT", t0 + 4)
    for i, lg in enumerate(LANGS):
        u = bot.get_user(100 + i)
        for days in (7, 30, 0):
            for scope in ("all", "mine"):
                txt = bot.perf_text(u, days, scope); kb = bot.perf_kb(u, days, scope)
                assert "{" not in txt and len(txt) < 4096, (lg, days, scope, txt)
                assert all(len(b.callback_data.encode()) <= 64 for row in kb.rows for b in row)
        assert "{" not in bot.open_text(u) and "{" not in bot.history_text(u)
        assert "{" not in bot.help_text(T[lg]) and len(bot.help_text(T[lg])) < 4096
        assert len(T[lg]["terms"]) < 4096
    check(True, "perf/open/history/help/terms 8 dil × 3 dönem × 2 kapsam sorunsuz")
    print(bot.perf_text(bot.get_user(102), 30, "all"))
    print("--- açık sinyaller (tr) ---"); print(bot.open_text(bot.get_user(102)))
    print("--- geçmiş (tr) ---"); print(bot.history_text(bot.get_user(102)))
    st = core.compute_stats([dict(r) | {"hit": r["tp_hit"], "r": r["r_result"]} for r in db.execute("SELECT * FROM signals WHERE status IN ('closed','expired','open')")])
    check(st["resolved"] >= 4 and st["open"] >= 1, f"compute_stats özet: {st['resolved']} sonuçlu, {st['open']} açık, net {st['net']:.2f}R")

    print("== 7. Spot sinyali (BUY/EXIT) ve komutlar")
    srows = find_flip("spot"); client.klines = {"*": srows, "1h": srows}
    for i in range(8): bot.set_field(100 + i, "market", "spot")
    app.bot.sent.clear(); await bot.scan_tf(app, client, "15m")
    sp = db.execute("SELECT * FROM signals WHERE market='spot'").fetchall()
    check(len(sp) == 2 and sp[0]["side"] in ("BUY", "EXIT"), f"spot sinyali (BTC+ETH) {sp[0]['side'] if sp else None}")
    check(sp[0]["status"] == ("open" if sp[0]["side"] == "BUY" else "info"), "EXIT takip edilmez (info), BUY takip edilir")
    class FU:
        def __init__(s, cid): s.effective_chat = type("C", (), {"id": cid, "type": "private"})(); s.callback_query = None; s.effective_user = type("U", (), {"id": cid})(); s.out = []; s.effective_message = s
        async def reply_text(s, text, **kw): s.out.append(text)
    class FC:
        def __init__(s, args=()): s.args = list(args); s.user_data = {}; s.application = type("A", (), {"bot_data": {"client": client}})()
    u = FU(102); await bot.cmd_stats(u, FC()); await bot.cmd_open(u, FC()); await bot.cmd_history(u, FC()); await bot.cmd_test(u, FC())
    check(len(u.out) == 5 and all(u.out), "cmd_stats/open/history/test cevap verdi")
    client.klines = {"*": series(600, 7)}
    u2 = FU(102); await bot.cmd_backtest(u2, FC(["BTCUSDT", "15m"])); print(u2.out[0][:400])
    check("{" not in u2.out[0], "backtest cevabı biçimli")
    # v5: /corr /explain /markets /backup
    class FU2(FU):
        async def reply_photo(s, photo, **kw): s.out.append("PHOTO:%d" % len(photo.getvalue()))
        async def reply_document(s, f, **kw): s.out.append("DOC:%d" % len(f.read()))
    client.klines = {"*": series(600, 7)}
    u3 = FU2(102)
    await bot.cmd_corr(u3, FC(["SOLUSDT", "1h"])); check("{" not in u3.out[-1] and "BTC" in u3.out[-1] and "ETH" in u3.out[-1], "/corr cevabı BTC+ETH içeriyor")
    await bot.cmd_corr(u3, FC()); check("/corr" in u3.out[-1], "/corr kullanım mesajı")
    await bot.cmd_explain(u3, FC(["SOLUSDT", "1h"])); check(any("📖" in x for x in u3.out) and any(x.startswith("PHOTO:") for x in u3.out), "/explain anlatım + grafik verdi")
    await bot.cmd_explain(u3, FC()); check("/explain" in u3.out[-1], "/explain kullanım mesajı")
    mk = await bot.markets_text(client, T["tr"]); check(isinstance(mk, str) and mk, "markets_text üretildi")
    bot.ADMIN_ID = 102; u4 = FU2(102); await bot.cmd_backup(u4, FC()); check(u4.out and u4.out[0].startswith("DOC:") and int(u4.out[0][4:]) > 1000, "/backup SQLite dosyası gönderdi")
    bot.ADMIN_ID = 1; u5 = FU2(102); await bot.cmd_backup(u5, FC()); check(not u5.out, "/backup admin olmayana sessiz")
    c = core.corr_rows(client.klines["*"], client.klines["*"]); check(c is not None and abs(c - 1) < 1e-6, "aynı seri korelasyonu = 1")
    # 19 komut açıklaması
    for lg in LANGS: assert len(T[lg]["cmds"].split("|")) == len(bot.CMD_ORDER), (lg, len(T[lg]["cmds"].split("|")), len(bot.CMD_ORDER))
    check(True, f"komut açıklamaları {len(bot.CMD_ORDER)} × 8 dil eşleşiyor")

asyncio.run(main())
print("\nSONUÇ:", "TÜM TESTLER GEÇTİ" if not FAILS else f"{len(FAILS)} HATA: {FAILS}")
sys.exit(1 if FAILS else 0)
