"""Menüdeki her butona (3 seviye derinlik) 8 dilde basar; hata, kırık {yer tutucu}, 4096 ve 64-bayt sınırlarını denetler.
   DB_PATH=/tmp/ui.db PYTHONPATH=dev/stubs:. python3 dev/test_ui.py"""
import asyncio, os, re, sys, tempfile, time
_default_db = os.path.join(tempfile.gettempdir(), "elena_ui.db")
os.environ.setdefault("DB_PATH", _default_db)
if os.path.exists(os.environ["DB_PATH"]):
    try: os.remove(os.environ["DB_PATH"])
    except OSError: pass
import bot, core
from texts import LANGS, T
FAILS = []
class Q:
    def __init__(s, data, cid): s.data = data; s.message = type("M", (), {"chat": type("C", (), {"id": cid})()})(); s.captured = None
    async def answer(s, *a, **k): pass
    async def edit_message_text(s, text, **kw): s.captured = (text, kw.get("reply_markup"))
class U:
    def __init__(s, q): s.callback_query = q; s.effective_chat = type("C", (), {"id": q.message.chat.id, "type": "private"})(); s.effective_message = None
class Ctx:
    def __init__(s): s.user_data = {}; s.application = type("A", (), {"bot_data": {"client": FC()}})()
class Resp:
    def __init__(s, j): s._j = j; s.status_code = 200
    def json(s): return s._j
    def raise_for_status(s): pass
class FC:
    async def get(s, url, params=None):
        if "24hr" in url and not params:
            return Resp([{"symbol": f"C{i}USDT", "priceChangePercent": str(i - 6), "lastPrice": "1.5", "quoteVolume": "9e7", "highPrice": "2", "lowPrice": "1"} for i in range(12)])
        return Resp({"lastPrice": "65000.1", "priceChangePercent": "-1.5", "highPrice": "66000", "lowPrice": "64000", "quoteVolume": "1.2e9"})
def btns(kb): return [b for row in kb.rows for b in row] if kb else []
def lint(tag, text, kb):
    if "{" in text or "}" in text or len(text) > 4096: FAILS.append((tag, "metin", len(text), re.findall(r"\{\w*\}", text)[:3]))
    for b in btns(kb):
        if b.callback_data and len(b.callback_data.encode()) > 64: FAILS.append((tag, "callback>64", b.callback_data))
        if not b.text or len(b.text) > 64: FAILS.append((tag, "buton metni", b.text))
async def main():
    bot.init_db()
    bot.db.execute("PRAGMA synchronous = OFF")
    n = 0
    bot.TOP["futures"] = [f"C{i}USDT" for i in range(40)]
    for i, lg in enumerate(LANGS):
        cid = 500 + i; bot.ensure_user(cid, lg); bot.set_field(cid, "lang", lg); bot.set_field(cid, "accepted", 1)
        seen, frontier = set(), ["M:menu"]
        for depth in range(4):
            nxt = []
            for data in frontier:
                if data in seen or data.startswith("D:"): continue
                seen.add(data); q = Q(data, cid)
                try: await bot.on_button(U(q), Ctx())
                except Exception as e: FAILS.append((lg, data, repr(e))); continue
                n += 1
                if q.captured:
                    lint((lg, data), *q.captured); nxt += [b.callback_data for b in btns(q.captured[1]) if b.callback_data]
            frontier = nxt
        # Telegram komut/açıklama sınırları
        t = T[lg]; descs = t["cmds"].split("|")
        assert all(3 <= len(d) <= 256 for d in descs) and len(t["desc"]) <= 512 and len(t["short_desc"]) <= 115, lg
        assert all(re.fullmatch(r"[a-z0-9_]{1,32}", c) for c in bot.CMD_ORDER)
        assert {"M:disp", "G:c", "G:k", "M:mkts"} <= seen, (lg, "yeni butonlar taranmadı")
        print(f"  {lg}: {len(seen)} farklı buton/sayfa", flush=True)
    # silme akışı en sonda
    q = Q("D:yes", 500); await bot.on_button(U(q), Ctx()); assert bot.get_user(500) is None
    print("  silme akışı OK; toplam buton basımı:", n, flush=True)
asyncio.run(main())
print("UI SONUÇ:", "TÜM TESTLER GEÇTİ" if not FAILS else FAILS[:8])
sys.exit(1 if FAILS else 0)
