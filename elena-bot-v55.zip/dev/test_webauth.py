"""webauth.verify_init_data() birim testi — mini app'in TEK kimlik doğrulama kapısı.
Bağımsız çalışır (aiohttp gerekmez): python3 dev/test_webauth.py
"""
import hashlib
import hmac
import json
import sys
import time
from urllib.parse import quote

sys.path.insert(0, ".")
from webauth import verify_init_data  # noqa: E402

FAILS = []


def check(cond, msg):
    print(("  OK  " if cond else "  FAIL") + " " + msg)
    if not cond:
        FAILS.append(msg)


def make_init_data(token, user=None, auth_date=None, extra=None):
    """Telegram'ın gerçekte ürettiği initData'yı taklit eder: alanları imzalar, query string döner."""
    fields = {"query_id": "AAEtest", "auth_date": str(auth_date or int(time.time())),
              "user": json.dumps(user or {"id": 12345, "first_name": "Test"}, separators=(",", ":"))}
    if extra:
        fields.update(extra)
    check_str = "\n".join(f"{k}={v}" for k, v in sorted(fields.items()))
    secret = hmac.new(b"WebAppData", token.encode(), hashlib.sha256).digest()
    h = hmac.new(secret, check_str.encode(), hashlib.sha256).hexdigest()
    parts = [f"{k}={quote(v, safe='')}" for k, v in fields.items()] + [f"hash={h}"]
    return "&".join(parts)


TOKEN = "123456:FAKE-TOKEN-FOR-TEST"

# 1) geçerli imza kabul edilir
init = make_init_data(TOKEN, user={"id": 6527896022, "first_name": "Onurcan"})
r = verify_init_data(init, TOKEN)
check(r is not None and r["user"]["id"] == 6527896022, "geçerli initData kabul edilir, chat_id doğru okunur")

# 2) yanlış bot token'la doğrulanamaz (biri başka bir bottan çaldığı initData'yı kullanamaz)
check(verify_init_data(init, "999999:OTHER-TOKEN") is None, "yanlış bot token ile reddedilir")

# 3) tek karakter bile değiştirilmiş veri (sahtecilik) reddedilir
tampered = init.replace("Onurcan", "Hacker") if "Onurcan" in init else init[:-2] + "00"
check(verify_init_data(tampered, TOKEN) is None, "değiştirilmiş initData (imza uyuşmuyor) reddedilir")

# 4) hash alanı eksikse reddedilir
check(verify_init_data(init.split("&hash=")[0], TOKEN) is None, "hash alanı olmadan reddedilir")

# 5) çok eski initData (örn. çalınıp sonra tekrar kullanılmaya çalışılan link) reddedilir
old = make_init_data(TOKEN, auth_date=int(time.time()) - 200000)
check(verify_init_data(old, TOKEN, max_age=86400) is None, "24 saatten eski initData reddedilir")
check(verify_init_data(old, TOKEN, max_age=0) is not None, "max_age=0 ile yaş kontrolü atlanabilir (gerekirse)")

# 6) user alanı yoksa / id yoksa reddedilir
no_id = make_init_data(TOKEN, user={"first_name": "x"})
check(verify_init_data(no_id, TOKEN) is None, "user.id eksikse reddedilir")

# 7) boş/None girişler güvenli şekilde None döner (exception fırlatmaz)
check(verify_init_data("", TOKEN) is None, "boş initData → None (hata fırlatmaz)")
check(verify_init_data("garbage===not&valid", TOKEN) is None, "bozuk initData → None (hata fırlatmaz)")
check(verify_init_data(init, "") is None, "boş bot token → None")

# 8) admin_id karşılaştırması tam bu fonksiyonun üstüne kurulu: chat_id taklit edilemiyor
admin_init = make_init_data(TOKEN, user={"id": 6527896022})
not_admin_init = make_init_data(TOKEN, user={"id": 1})
ADMIN_ID = 6527896022
r1 = verify_init_data(admin_init, TOKEN); r2 = verify_init_data(not_admin_init, TOKEN)
check(r1["user"]["id"] == ADMIN_ID and r2["user"]["id"] != ADMIN_ID,
      "admin karşılaştırması güvenilir imzalı user.id üzerinden yapılabiliyor")

print("\nSONUÇ:", "TÜM TESTLER GEÇTİ" if not FAILS else f"{len(FAILS)} HATA: {FAILS}")
sys.exit(1 if FAILS else 0)
