with open(r'webapp\admin.html', encoding='utf-8') as f:
    html = f.read()

ids = ['content', 's-total', 's-active', 's-wallets', 's-sig24', 's-open', 's-alerts', 'lang-list', 'denied', 'denied-text', 'tunnel-connect-box', 'manual-tunnel-input', 'btn-save-tunnel']
for i in ids:
    target = f'id="{i}"'
    print(f'{i:22}: {target in html}')
