"""Göstergeler: Pine Script v4 kodunun saf Python karşılığı (pandas/numpy gerekmez).

Supertrend (ATR 10, çarpan 3.0), MavilimW (WMA zinciri) ve EMA.
"""


def rma(vals, n):
    """Pine'ın ta.rma (Wilder) hesabı; ilk değer SMA ile başlar."""
    out = [None] * len(vals)
    s = None
    for i, v in enumerate(vals):
        if s is None:
            if i < n - 1:
                continue
            s = sum(vals[i - n + 1:i + 1]) / n
        else:
            s = (v + (n - 1) * s) / n
        out[i] = s
    return out


def ema(vals, n):
    out = [None] * len(vals)
    a = 2.0 / (n + 1)
    s = None
    for i, v in enumerate(vals):
        if s is None:
            if i < n - 1:
                continue
            s = sum(vals[i - n + 1:i + 1]) / n
        else:
            s = a * v + (1 - a) * s
        out[i] = s
    return out


def wma(vals, n):
    out = [None] * len(vals)
    w = n * (n + 1) / 2.0
    for i in range(n - 1, len(vals)):
        win = vals[i - n + 1:i + 1]
        if any(x is None for x in win):
            continue
        out[i] = sum(x * (k + 1) for k, x in enumerate(win)) / w
    return out


def mavilim(close, f=3, s=5):
    """MavilimW: 3, 5, 8, 13, 21, 34 uzunluklu WMA zinciri."""
    t = f + s
    big_f = s + t
    ft = t + big_f
    big_s = big_f + ft
    m = list(close)
    for n in (f, s, t, big_f, ft, big_s):
        m = wma(m, n)
    return m


def supertrend(high, low, close, period=10, mult=3.0):
    """Pine kodundaki mantığın birebir portu. (up, dn, trend, atr) döner."""
    n = len(close)
    tr = [high[0] - low[0]] + [
        max(high[i] - low[i], abs(high[i] - close[i - 1]), abs(low[i] - close[i - 1]))
        for i in range(1, n)
    ]
    atr = rma(tr, period)
    up = [None] * n
    dn = [None] * n
    trend = [1] * n
    for i in range(n):
        if atr[i] is None:
            continue
        src = (high[i] + low[i]) / 2.0
        u = src - mult * atr[i]
        d = src + mult * atr[i]
        pu = up[i - 1] if i > 0 and up[i - 1] is not None else u
        pd = dn[i - 1] if i > 0 and dn[i - 1] is not None else d
        pc = close[i - 1] if i > 0 else close[i]
        if pc > pu:
            u = max(u, pu)
        if pc < pd:
            d = min(d, pd)
        t = trend[i - 1] if i > 0 else 1
        if t == -1 and close[i] > pd:
            t = 1
        elif t == 1 and close[i] < pu:
            t = -1
        up[i], dn[i], trend[i] = u, d, t
    return up, dn, trend, atr


# ====================================================================== v3 eklemeleri
# Sinyal Defteri PWA'daki göstergelerin Python portu (RSI, MACD, StochRSI, ADX, Bollinger, VWAP,
# pivot/destek-direnç, Fibonacci, formasyonlar).

def sma(vals, n):
    out = [None] * len(vals)
    s = 0.0
    for i, v in enumerate(vals):
        s += v
        if i >= n:
            s -= vals[i - n]
        if i >= n - 1:
            out[i] = s / n
    return out


def sma_skip(vals, n):
    out = [None] * len(vals)
    for i in range(n - 1, len(vals)):
        w = vals[i - n + 1:i + 1]
        if any(x is None for x in w):
            continue
        out[i] = sum(w) / n
    return out


def true_range(h, l, c):
    return [h[0] - l[0]] + [max(h[i] - l[i], abs(h[i] - c[i - 1]), abs(l[i] - c[i - 1]))
                            for i in range(1, len(c))]


def rsi(vals, n=14):
    out = [None] * len(vals)
    if len(vals) <= n:
        return out
    g = ls = 0.0
    for i in range(1, n + 1):
        d = vals[i] - vals[i - 1]
        if d >= 0:
            g += d
        else:
            ls -= d
    ag, al = g / n, ls / n
    out[n] = 100.0 if al == 0 else 100 - 100 / (1 + ag / al)
    for i in range(n + 1, len(vals)):
        d = vals[i] - vals[i - 1]
        ag = (ag * (n - 1) + max(d, 0.0)) / n
        al = (al * (n - 1) + max(-d, 0.0)) / n
        out[i] = 100.0 if al == 0 else 100 - 100 / (1 + ag / al)
    return out


def bollinger(vals, n=20, mult=2.0):
    mid = sma(vals, n)
    up = [None] * len(vals)
    lo = [None] * len(vals)
    for i in range(n - 1, len(vals)):
        w = vals[i - n + 1:i + 1]
        m = mid[i]
        sd = (sum((x - m) ** 2 for x in w) / n) ** 0.5
        up[i], lo[i] = m + mult * sd, m - mult * sd
    return up, mid, lo


def macd(vals, fast=12, slow=26, sig=9):
    ef, es = ema(vals, fast), ema(vals, slow)
    line = [(a - b) if a is not None and b is not None else None for a, b in zip(ef, es)]
    first = next((i for i, x in enumerate(line) if x is not None), None)
    signal = [None] * len(vals)
    hist = [None] * len(vals)
    if first is not None:
        for j, x in enumerate(ema(line[first:], sig)):
            if x is not None:
                signal[first + j] = x
                hist[first + j] = line[first + j] - x
    return line, signal, hist


def stoch_rsi(vals, rp=14, sp=14, ks=3, ds=3):
    r = rsi(vals, rp)
    st = [None] * len(vals)
    for i in range(sp - 1, len(vals)):
        w = r[i - sp + 1:i + 1]
        if any(x is None for x in w):
            continue
        lo, hi = min(w), max(w)
        st[i] = 0.0 if hi - lo == 0 else (r[i] - lo) / (hi - lo) * 100
    k = sma_skip(st, ks)
    return k, sma_skip(k, ds)


def adx(h, l, c, n=14):
    """(+DI, -DI, ADX) dizileri; Wilder yumuşatması."""
    L = len(c)
    pdi, mdi, out = [None] * L, [None] * L, [None] * L
    if L < 2 * n + 1:
        return pdi, mdi, out
    pdm, mdm, tr = [0.0], [0.0], [h[0] - l[0]]
    for i in range(1, L):
        up, dn = h[i] - h[i - 1], l[i - 1] - l[i]
        pdm.append(up if (up > dn and up > 0) else 0.0)
        mdm.append(dn if (dn > up and dn > 0) else 0.0)
        tr.append(max(h[i] - l[i], abs(h[i] - c[i - 1]), abs(l[i] - c[i - 1])))

    def wild(a):
        o = [None] * L
        s = sum(a[:n])
        o[n - 1] = s
        for i in range(n, L):
            s = s - s / n + a[i]
            o[i] = s
        return o

    trs, pds, mds = wild(tr), wild(pdm), wild(mdm)
    dx = [None] * L
    for i in range(n - 1, L):
        if trs[i]:
            pdi[i] = 100 * pds[i] / trs[i]
            mdi[i] = 100 * mds[i] / trs[i]
            s = pdi[i] + mdi[i]
            dx[i] = 0.0 if s == 0 else 100 * abs(pdi[i] - mdi[i]) / s
    seed_end = (n - 1) + n
    prev = sum((x or 0.0) for x in dx[n - 1:seed_end]) / n
    out[seed_end - 1] = prev
    for i in range(seed_end, L):
        prev = (prev * (n - 1) + (dx[i] or 0.0)) / n
        out[i] = prev
    return pdi, mdi, out


def vwap_last(h, l, c, v, n=48):
    """Son n mumun hacim ağırlıklı ortalama fiyatı."""
    s = max(0, len(c) - n)
    pv = vol = 0.0
    for i in range(s, len(c)):
        pv += (h[i] + l[i] + c[i]) / 3 * v[i]
        vol += v[i]
    return pv / vol if vol else None


def pivots(h, l, left=4, right=4):
    ph, pl = [], []
    for i in range(left, len(h) - right):
        wh, wl = h[i - left:i + right + 1], l[i - left:i + right + 1]
        if h[i] == max(wh) and wh.count(h[i]) == 1:
            ph.append((i, h[i]))
        if l[i] == min(wl) and wl.count(l[i]) == 1:
            pl.append((i, l[i]))
    return ph, pl


def cluster(points, tol):
    """points: [(i, fiyat)]; tol oransal (0.003 = %0.3). → [{'price','touches','last'}]"""
    if not points:
        return []
    pts = sorted(points, key=lambda p: p[1])
    groups, cur = [], [pts[0]]
    for p in pts[1:]:
        avg = sum(x[1] for x in cur) / len(cur)
        if abs(p[1] - avg) / avg <= tol:
            cur.append(p)
        else:
            groups.append(cur)
            cur = [p]
    groups.append(cur)
    return [{"price": sum(x[1] for x in g) / len(g), "touches": len(g), "last": max(x[0] for x in g)}
            for g in groups]


def sr_levels(piv_h, piv_l, price, tol=0.003, top=2):
    """Fiyatın üstündeki en yakın dirençler ve altındaki en yakın destekler."""
    lv = cluster(piv_h + piv_l, tol)
    res = sorted([x for x in lv if x["price"] > price * 1.0002], key=lambda x: x["price"])[:top]
    sup = sorted([x for x in lv if x["price"] < price * 0.9998], key=lambda x: -x["price"])[:top]
    return res, sup


def fib_nearest(h, l, price, lookback=100):
    hh, lo = max(h[-lookback:]), min(l[-lookback:])
    d = hh - lo
    if d <= 0:
        return None
    best = None
    for r in (0.236, 0.382, 0.5, 0.618, 0.786):
        p = hh - d * r
        if best is None or abs(p - price) < abs(best[1] - price):
            best = (r, p)
    return best


def detect_patterns(h, l, c, ph, pl):
    """Çift tepe/dip ve bayrak formasyonları. Anahtarlar: dtop, dbot, bflag, sflag."""
    out = []
    if len(ph) >= 2:
        (i1, p1), (i2, p2) = ph[-2], ph[-1]
        valley = min(l[i1:i2 + 1])
        lowtop = min(p1, p2)
        if abs(p1 - p2) / p1 * 100 < 1.5 and (lowtop - valley) / lowtop * 100 > 1.2 and i2 - i1 >= 3:
            out.append("dtop")
    if len(pl) >= 2:
        (i1, p1), (i2, p2) = pl[-2], pl[-1]
        peak = max(h[i1:i2 + 1])
        highbot = max(p1, p2)
        if abs(p1 - p2) / p1 * 100 < 1.5 and (peak - highbot) / highbot * 100 > 1.2 and i2 - i1 >= 3:
            out.append("dbot")
    if len(c) >= 25:
        imp = (c[-9] - c[-25]) / c[-25] * 100
        rng = max(h[-8:]) - min(l[-8:])
        cons = rng / c[-1] * 100
        if abs(imp) > 2 and cons < abs(imp) * 0.5:
            out.append("bflag" if imp > 0 else "sflag")
    return out
