#!/data/data/com.termux/files/usr/bin/bash
# =====================================================================
# Елена Хьюз · Crypto Signals — TEK KOMUTLA KURULUM / GÜNCELLEME (Termux)
#   bash install.sh        (zip'i nereye çıkardıysan oradan çalıştır; kendini ~/elena-bot'a kopyalar)
#
# Hepsi otomatik: paketler, pip bağımlılıkları, .env (token + admin ID sorar), tmux'ta bot + tünel,
# ve Termux'u her açtığında botun kendiliğinden başlaması (~/.bashrc + Termux:Boot).
# Tekrar çalıştırmak güvenlidir: .env ve bot.db korunur; bot yeniden başlatılır (güncelleme = aynı komut).
# =====================================================================
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
TARGET="$HOME/elena-bot"

if [ "$HERE" != "$TARGET" ]; then
  echo "== Dosyalar ~/elena-bot içine kopyalanıyor (.env ve bot.db korunur) =="
  mkdir -p "$TARGET"
  tar -C "$HERE" --exclude=.env --exclude=bot.db --exclude=bot.log --exclude=.tunnel.log --exclude=.miniapp_url -cf - . | tar -C "$TARGET" -xf -
  exec bash "$TARGET/install.sh"
fi
cd "$TARGET"

echo "== 1/5 Paketler (python, cloudflared, tmux, curl) =="
pkg update -y -q >/dev/null 2>&1 || true
pkg install -y python tmux curl cloudflared 2>/dev/null || pkg install -y python tmux curl
if ! command -v cloudflared >/dev/null 2>&1; then
  echo "cloudflared pkg'den kurulamadı, ikiliyi doğrudan indiriyorum..."
  case "$(uname -m)" in aarch64|arm64) A=arm64 ;; armv7l|armv8l) A=arm ;; x86_64) A=amd64 ;; *) A=arm64 ;; esac
  curl -L -o "$PREFIX/bin/cloudflared" "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-$A"
  chmod +x "$PREFIX/bin/cloudflared"
fi

echo "== 2/5 Python bağımlılıkları =="
export AIOHTTP_NO_EXTENSIONS=1 MULTIDICT_NO_EXTENSIONS=1 YARL_NO_EXTENSIONS=1 FROZENLIST_NO_EXTENSIONS=1
if ! pip install -r requirements.txt -q; then
  echo "İlk deneme başarısız, derleme araçları kurulup yeniden deneniyor..."
  pkg install -y clang make libffi openssl rust >/dev/null 2>&1 || true
  pip install -r requirements.txt
fi

echo "== 3/5 .env ayarları =="
NEED=0
[ ! -f .env ] && { cp env.example .env; NEED=1; }
grep -q "BURAYA_BOTFATHER_TOKEN" .env && NEED=1
grep -qE '^ADMIN_ID=(0|)$' .env && NEED=1
if [ "$NEED" = 1 ]; then
  echo "--- BotFather token'ı ve kendi Telegram sayısal ID'n lazım ---"
  read -rp "BOT_TOKEN (BotFather /newbot): " BOT_TOKEN
  while true; do
    read -rp "ADMIN_ID (@userinfobot'tan SAYISAL id): " ADMIN_ID
    case "$ADMIN_ID" in ''|*[!0-9]*) echo "Sadece rakam gir (örn. 123456789).";; *) break;; esac
  done
  python3 - "$BOT_TOKEN" "$ADMIN_ID" << 'PYEOF'
import sys, re
tok, admin = sys.argv[1].strip(), sys.argv[2].strip()
c = open(".env", encoding="utf-8").read()
c = re.sub(r"(?m)^BOT_TOKEN=.*$", lambda m: f"BOT_TOKEN={tok}", c, count=1)
c = re.sub(r"(?m)^ADMIN_ID=.*$", lambda m: f"ADMIN_ID={admin}", c, count=1)
open(".env", "w", encoding="utf-8").write(c)
PYEOF
  echo ".env hazır."
else
  echo ".env dolu, dokunulmadı. (ADMIN_ID=$(grep -E '^ADMIN_ID=' .env | cut -d= -f2))"
fi
if ! grep -qE '^WC_PROJECT_ID=.+' .env && [ ! -f .wc_asked ]; then
  echo
  echo "--- Cüzdan bağlama için WalletConnect Project ID (ücretsiz: cloud.reown.com > yeni proje > Project ID) ---"
  read -rp "WC_PROJECT_ID (boş bırakıp geçebilirsin): " WC
  touch .wc_asked
  if [ -n "$WC" ]; then
    WC="$WC" python3 - << 'PYEOF'
import os, re
c = open(".env", encoding="utf-8").read()
c = re.sub(r"(?m)^WC_PROJECT_ID=.*$", lambda m: "WC_PROJECT_ID=" + os.environ["WC"].strip(), c, count=1)
open(".env", "w", encoding="utf-8").write(c)
PYEOF
  fi
fi
chmod +x start.sh

echo "== 4/5 Termux her açıldığında otomatik başlasın =="
MARK="# >>> elena-bot autostart >>>"
if ! grep -q "$MARK" "$HOME/.bashrc" 2>/dev/null; then
  cat >> "$HOME/.bashrc" << 'RCEOF'
# >>> elena-bot autostart >>>
if [ -z "$TMUX" ] && command -v tmux >/dev/null 2>&1 && [ -d "$HOME/elena-bot" ] && ! tmux has-session -t elena 2>/dev/null; then
  ( cd "$HOME/elena-bot" && tmux new-session -d -s elena "bash start.sh" ) && echo "Елена botu arka planda başlatıldı (loglar: tmux attach -t elena)"
fi
# <<< elena-bot autostart <<<
RCEOF
fi
mkdir -p "$HOME/.termux/boot"   # Termux:Boot uygulaması kuruluysa telefon açılışında da başlar
cat > "$HOME/.termux/boot/elena.sh" << 'BEOF'
#!/data/data/com.termux/files/usr/bin/bash
termux-wake-lock
tmux has-session -t elena 2>/dev/null || ( cd "$HOME/elena-bot" && tmux new-session -d -s elena "bash start.sh" )
BEOF
chmod +x "$HOME/.termux/boot/elena.sh"

echo "== 5/5 Bot başlatılıyor (tmux: elena) =="
tmux kill-session -t elena 2>/dev/null || true
tmux new-session -d -s elena "bash start.sh"
echo
echo "Başladı. Tünel adresi hazır olunca (~30-60 sn) Telegram'da bota /start yaz;"
echo "yönetici hesabına otomatik 'online' mesajı + güncel panel butonları gelir."
echo "Canlı log: tmux attach -t elena   (çıkış: CTRL+B sonra D)"
