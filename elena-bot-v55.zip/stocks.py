"""BIST 100 ve Global Varlıklar (Hisse, Emtia) Mum Verisi Çekici ve Sinyal Entegrasyonu.
Yahoo Finance v8 API doğrudan çağrılır (harici paket gerektirmez, %100 hafiftir).
"""
import asyncio
import json
import logging
import time
import urllib.request
import core

log = logging.getLogger("elena-stocks")

# Popüler BIST ve Dünya Varlıkları Havuzu
STOCK_UNIVERSE = {
    # 🇹🇷 BIST 100 Lokomotif Hisseler
    "THYAO.IS": {"display": "THYAO", "market": "bist", "name": "Türk Hava Yolları"},
    "ASELS.IS": {"display": "ASELS", "market": "bist", "name": "Aselsan"},
    "GARAN.IS": {"display": "GARAN", "market": "bist", "name": "Garanti Bankası"},
    "EREGL.IS": {"display": "EREGL", "market": "bist", "name": "Ereğli Demir Çelik"},
    "TUPRS.IS": {"display": "TUPRS", "market": "bist", "name": "Tüpraş"},
    "KCHOL.IS": {"display": "KCHOL", "market": "bist", "name": "Koç Holding"},
    "BIMAS.IS": {"display": "BIMAS", "market": "bist", "name": "BİM Mağazalar"},
    "AKBNK.IS": {"display": "AKBNK", "market": "bist", "name": "Akbank"},
    "SISE.IS":  {"display": "SISE",  "market": "bist", "name": "Şişecam"},
    "SAHOL.IS": {"display": "SAHOL", "market": "bist", "name": "Sabancı Holding"},
    # 🇺🇸 Global Devler
    "NVDA":     {"display": "NVDA",  "market": "us",   "name": "NVIDIA Corp"},
    "AAPL":     {"display": "AAPL",  "market": "us",   "name": "Apple Inc"},
    "TSLA":     {"display": "TSLA",  "market": "us",   "name": "Tesla Inc"},
    "MSFT":     {"display": "MSFT",  "market": "us",   "name": "Microsoft Corp"},
    "AMZN":     {"display": "AMZN",  "market": "us",   "name": "Amazon.com Inc"},
    # 🥇 Emtialar
    "GC=F":     {"display": "GOLD",  "market": "macro", "name": "Ons Altın"},
    "BZ=F":     {"display": "BRENT", "market": "macro", "name": "Brent Petrol"},
}

INTERVAL_MAP = {
    "15m": ("5d", "15m"),
    "1h":  ("1mo", "60m"),
    "4h":  ("3mo", "60m"),   # 1h çekip 4h resample veya günlük
    "1d":  ("1y", "1d"),
}

def fetch_stock_candles_sync(ticker, interval="1h"):
    """Yahoo Finance API'den mum geçmişi çeker (OHLCV formatında core.py uyumlu)."""
    range_param, interval_param = INTERVAL_MAP.get(interval, ("1mo", "60m"))
    url = f"https://query1.finance.yahoo.com/v8/finance/chart/{ticker}?range={range_param}&interval={interval_param}"
    headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"}
    req = urllib.request.Request(url, headers=headers)
    
    try:
        with urllib.request.urlopen(req, timeout=6) as resp:
            data = json.loads(resp.read().decode())
        result = data.get("chart", {}).get("result", [])
        if not result:
            return None
        
        timestamps = result[0].get("timestamp", [])
        quote = result[0].get("indicators", {}).get("quote", [{}])[0]
        opens = quote.get("open", [])
        highs = quote.get("high", [])
        lows = quote.get("low", [])
        closes = quote.get("close", [])
        volumes = quote.get("volume", [])
        
        rows = []
        for i in range(len(timestamps)):
            ts = timestamps[i] * 1000  # ms
            o = opens[i]
            h = highs[i]
            l = lows[i]
            c = closes[i]
            v = volumes[i] or 0.0
            # None veya eksik mumları filtrele
            if None not in (o, h, l, c) and c > 0:
                rows.append([ts, float(o), float(h), float(l), float(c), float(v), ts + 3600000])
        return rows
    except Exception as e:
        log.debug(f"fetch_stock_candles error {ticker}: {e}")
        return None

async def fetch_stock_candles(ticker, interval="1h"):
    """Asenkron yürütme sarmalayıcısı."""
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(None, fetch_stock_candles_sync, ticker, interval)

async def scan_single_stock(ticker, tf="1h", force=False):
    """Tek bir hisse/varlık için Elena Supertrend + MavilimW sinyal analizi yapar."""
    rows = await fetch_stock_candles(ticker, tf)
    if not rows or len(rows) < 30:
        return None
    info = STOCK_UNIVERSE.get(ticker, {"display": ticker, "market": "stock", "name": ticker})
    # core.analyze ile kriptodaki aynı süzgeçten geçir
    sig = core.analyze(rows, market="spot", force=force)
    if sig:
        sig["symbol"] = info["display"]
        sig["ticker"] = ticker
        sig["stock_name"] = info["name"]
        sig["market_type"] = info["market"]
        sig["tf"] = tf
    return sig
