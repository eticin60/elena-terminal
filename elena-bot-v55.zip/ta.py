"""Teknik göstergeler: sinyal-defteri PWA'daki JavaScript kodunun saf Python portu.

EMA, RSI, Bollinger, MACD, StochRSI, ATR, ADX, VWAP, Fibonacci, pivot, destek/direnç kümeleme
ve formasyon tespiti. Girdiler düz listelerdir; hesaplanamayan yerler None döner.
"""


def sma(values, period):
    out = [None] * len(values)
    s = 0.0
    for i, v in enumerate(values):
        s += v
        if i >= period:
            s -= values[i - period]
        if i >= period - 1:
            out[i] = s / period
    return out


def sma_skip(arr, period):
    out = [None] * len(arr)
    for i in range(period - 1, len(arr)):
        w = arr[i - period + 1:i + 1]
        if any(x is None for x in w):
            continue
        out[i] = sum(w) / period
    return out


def ema(values, period):
    out = [None] * len(values)
    k = 2.0 / (period + 1)
    prev = None
    for i, v in enumerate(values):
        if i == period - 1:
            prev = sum(values[:period]) / period
            out[i] = prev
        elif i >= period:
            prev = v * k + prev * (1 - k)
            out[i] = prev
    return out


def rsi(values, period=14):
    n = len(values)
    out = [None] * n
    if n <= period:
        return out
    gains = losses = 0.0
    for i in range(1, period + 1):
        d = values[i] - values[i - 1]
        if d >= 0:
            gains += d
        else:
            losses -= d
    ag, al = gains / period, losses / period
    out[period] = 100.0 if al == 0 else 100 - 100 / (1 + ag / al)
    for i in range(period + 1, n):
        d = values[i] - values[i - 1]
        g = d if d > 0 else 0.0
        lo = -d if d < 0 else 0.0
        ag = (ag * (period - 1) + g) / period
        al = (al * (period - 1) + lo) / period
        out[i] = 100.0 if al == 0 else 100 - 100 / (1 + ag / al)
    return out


def bollinger(values, period=20, mult=2.0):
    mid = sma(values, period)
    up = [None] * len(values)
    lo = [None] * len(values)
    for i in range(period - 1, len(values)):
        w = values[i - period + 1:i + 1]
        m = mid[i]
        std = (sum((x - m) ** 2 for x in w) / period) ** 0.5
        up[i] = m + mult * std
        lo[i] = m - mult * std
    return up, mid, lo


def macd(closes, fast=12, slow=26, sig=9):
    ef, es = ema(closes, fast), ema(closes, slow)
    line = [(ef[i] - es[i]) if ef[i] is not None and es[i] is not None else None
            for i in range(len(closes))]
    first = next((i for i, v in enumerate(line) if v is not None), -1)
    signal = [None] * len(closes)
    if first >= 0:
        for j, v in enumerate(ema(line[first:], sig)):
            if v is not None:
                signal[first + j] = v
    hist = [(line[i] - signal[i]) if line[i] is not None and signal[i] is not None else None
            for i in range(len(closes))]
    return line, signal, hist


def stoch_rsi(closes, rsi_p=14, stoch_p=14, k_s=3, d_s=3):
    r = rsi(closes, rsi_p)
    st = [None] * len(closes)
    for i in range(stoch_p - 1, len(closes)):
        w = r[i - stoch_p + 1:i + 1]
        if any(x is None for x in w):
            continue
        lo, hi = min(w), max(w)
        st[i] = 0.0 if hi - lo == 0 else (r[i] - lo) / (hi - lo) * 100
    k = sma_skip(st, k_s)
    d = sma_skip(k, d_s)
    return k, d


def true_range(h, l, c):
    return [h[0] - l[0]] + [max(h[i] - l[i], abs(h[i] - c[i - 1]), abs(l[i] - c[i - 1]))
                            for i in range(1, len(c))]


def atr(h, l, c, period=14):
    tr = true_range(h, l, c)
    out = [None] * len(c)
    prev = None
    for i, t in enumerate(tr):
        if i == period - 1:
            prev = sum(tr[:period]) / period
            out[i] = prev
        elif i >= period:
            prev = (prev * (period - 1) + t) / period
            out[i] = prev
    return out


def adx(h, l, c, period=14):
    n = len(c)
    plus_dm, minus_dm = [0.0], [0.0]
    tr = [h[0] - l[0]]
    for i in range(1, n):
        up, down = h[i] - h[i - 1], l[i - 1] - l[i]
        plus_dm.append(up if (up > down and up > 0) else 0.0)
        minus_dm.append(down if (down > up and down > 0) else 0.0)
        tr.append(max(h[i] - l[i], abs(h[i] - c[i - 1]), abs(l[i] - c[i - 1])))

    def wilder(arr):
        out = [None] * len(arr)
        if len(arr) < period:
            return out
        s = sum(arr[:period])
        out[period - 1] = s
        for i in range(period, len(arr)):
            s = s - s / period + arr[i]
            out[i] = s
        return out

    trs, pds, mds = wilder(tr), wilder(plus_dm), wilder(minus_dm)
    pdi, mdi, dx = [None] * n, [None] * n, [None] * n
    for i in range(period - 1, n):
        if trs[i]:
            pdi[i] = 100 * pds[i] / trs[i]
            mdi[i] = 100 * mds[i] / trs[i]
            s = pdi[i] + mdi[i]
            dx[i] = 0.0 if s == 0 else 100 * abs(pdi[i] - mdi[i]) / s
    out = [None] * n
    first = next((i for i, v in enumerate(dx) if v is not None), -1)
    if first >= 0 and n > first + period:
        prev = sum((v or 0) for v in dx[first:first + period]) / period
        out[first + period - 1] = prev
        for i in range(first + period, n):
            prev = (prev * (period - 1) + (dx[i] or 0)) / period
            out[i] = prev
    return out, pdi, mdi


def vwap(h, l, c, v):
    out = [None] * len(c)
    pv = vol = 0.0
    for i in range(len(c)):
        tp = (h[i] + l[i] + c[i]) / 3
        pv += tp * v[i]
        vol += v[i]
        out[i] = pv / vol if vol else None
    return out


def fib_levels(h, l):
    hi, lo = max(h), min(l)
    diff = hi - lo
    return [(r, hi - diff * r) for r in (0, 0.236, 0.382, 0.5, 0.618, 0.786, 1)]


def find_pivots(h, l, left=4, right=4):
    highs, lows = [], []
    for i in range(left, len(h) - right):
        is_h = is_l = True
        for j in range(i - left, i + right + 1):
            if j == i:
                continue
            if h[j] >= h[i]:
                is_h = False
            if l[j] <= l[i]:
                is_l = False
        if is_h:
            highs.append((i, h[i]))
        if is_l:
            lows.append((i, l[i]))
    return highs, lows


def cluster_levels(points, tol_pct=0.3):
    if not points:
        return []
    srt = sorted(points, key=lambda p: p[1])
    clusters, cur = [], [srt[0]]
    for p in srt[1:]:
        avg = sum(x[1] for x in cur) / len(cur)
        if abs(p[1] - avg) / avg * 100 <= tol_pct:
            cur.append(p)
        else:
            clusters.append(cur)
            cur = [p]
    clusters.append(cur)
    return [{"price": sum(x[1] for x in c) / len(c), "touches": len(c)} for c in clusters]


def detect_patterns(h, l, c, highs, lows):
    """Çift tepe / çift dip / boğa-ayı bayrağı. [{'key','bias'}] döner."""
    res = []
    if len(highs) >= 2:
        (i1, p1), (i2, p2) = highs[-2], highs[-1]
        diff = abs(p1 - p2) / p1 * 100
        seg = l[i1:i2 + 1]
        if seg:
            valley = min(seg)
            depth = (min(p1, p2) - valley) / min(p1, p2) * 100
            if diff < 1.5 and depth > 1.2 and (i2 - i1) >= 3:
                res.append({"key": "pat_dt", "bias": "bear"})
    if len(lows) >= 2:
        (i1, p1), (i2, p2) = lows[-2], lows[-1]
        diff = abs(p1 - p2) / p1 * 100
        seg = h[i1:i2 + 1]
        if seg:
            peak = max(seg)
            height = (peak - max(p1, p2)) / max(p1, p2) * 100
            if diff < 1.5 and height > 1.2 and (i2 - i1) >= 3:
                res.append({"key": "pat_db", "bias": "bull"})
    if len(c) >= 25:
        imp_c = c[-25:-8]
        cons_h, cons_l = h[-8:], l[-8:]
        imp = (imp_c[-1] - imp_c[0]) / imp_c[0] * 100
        cons = (max(cons_h) - min(cons_l)) / c[-1] * 100
        if abs(imp) > 2 and cons < abs(imp) * 0.5:
            res.append({"key": "pat_bf" if imp > 0 else "pat_sf", "bias": "bull" if imp > 0 else "bear"})
    return res
