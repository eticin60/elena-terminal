"""Çok dilli metinler (ru, en, tr, uk, de, es, fr, ar) ve sinyal mesajı biçimlendirme.

Eksik bir anahtar olursa İngilizce'ye düşer (bot asla KeyError ile çökmez).
"""
from datetime import datetime, timedelta, timezone

BRAND = "Елена Хьюз"
HEAD = "🇷🇺 <b>Елена Хьюз</b> · Crypto Signals"
LINE = "━━━━━━━━━━━━━━"
TF_LIST = ["1m", "3m", "5m", "15m", "30m", "1h", "4h", "1d", "1w", "1M"]
LANGS = ["ru", "en", "tr", "uk", "de", "es", "fr", "ar"]

T = {}

# ============================================================ ENGLISH (taban dil)
T["en"] = {
    "name": "🇬🇧 English",
    "pick_lang": "🌐 Выберите язык · Choose your language",
    "terms": (
        "⚖️ <b>Terms of Use & Risk Disclosure</b>\n\n"
        "• This bot sends automated information based on technical analysis. It is <b>not</b> investment "
        "advice, a trade recommendation or a promise of returns.\n"
        "• Crypto trading, especially with leverage, can lead to the loss of your entire capital.\n"
        "• Signals may be delayed or wrong. All decisions and outcomes are your own responsibility.\n"
        "• You confirm that you are at least 18 and comply with the laws of your country.\n"
        "• Data stored: your Telegram chat id, language and settings. Nothing is shared with third parties; "
        "you can erase it with /delete.\n"
        "• Donations are voluntary, guarantee no service or return, and are non-refundable."
    ),
    "accept": "✅ I accept", "decline": "❌ Decline",
    "declined": "You declined the terms. No signals will be sent. Use /start to begin again.",
    "menu": ("📋 <b>Dashboard</b>  {status}\n\n🪙 Coins: <b>{n}</b>\n⏱ Timeframes: <b>{tfs}</b>\n"
             "📈 Market: <b>{market}</b>\n⚙️ Max leverage: <b>{lev}x</b>\n🔔 Strong only: <b>{strong}</b>\n"
             "🌙 Quiet hours: <b>{quiet}</b>"),
    "st_on": "🟢 Active", "st_off": "⏸ Paused", "on": "on", "off": "off",
    "b_coins": "🪙 Coins / favorites", "b_tfs": "⏱ Timeframes", "b_market": "📈 Market type",
    "b_lev": "⚙️ Leverage", "b_strong": "🔔 Strong only: {v}", "b_quiet": "🌙 Quiet hours",
    "b_data": "📊 Live market", "b_hist": "🕘 History", "b_calc": "🧮 Calculator",
    "b_lang": "🌐 Language", "b_help": "❓ Help", "b_terms": "⚖️ Terms", "b_donate": "💝 Donate",
    "b_delete": "🗑 Delete my data", "b_back": "⬅️ Back", "b_pause": "⏸ Pause alerts",
    "b_resume": "▶️ Resume alerts",
    "coins_head": ("🪙 <b>My coins</b> ({n}): {lst}\n\nTap a coin to add/remove it. "
                   "Not listed? Send: <code>/add SOL</code>"),
    "tfs_head": "⏱ <b>Timeframes</b>\nPick one or more. Short timeframes produce more false signals.",
    "market_head": "📈 <b>Signal type</b>",
    "mkt_futures": "Futures (Long/Short)", "mkt_spot": "Spot", "mkt_both": "Futures + Spot",
    "lev_head": "⚙️ <b>Maximum leverage</b>\nThe bot will never suggest leverage above your limit.",
    "quiet_head": ("🌙 <b>Quiet hours</b>\nDuring these hours signals arrive silently (no sound).\n"
                   "Your time zone: <b>UTC{tz}</b> — adjust with ➖ ➕"),
    "quiet_off": "Off (always with sound)",
    "added": "✅ Added: {s}", "removed": "🗑 Removed: {s}", "notfound": "❌ Pair not found: {s}",
    "usage_add": "Usage: /add SOL  or  /remove SOL", "limit": "Coin limit: {n}",
    "donate": ("💝 <b>Support the project</b>\nDonations are voluntary and do not guarantee returns or "
               "extra services. Thank you!"),
    "b_donate_open": "💝 Open donation page",
    "help": (
        "❓ <b>How it works</b>\n\n"
        "1) Pick coins and timeframes.\n"
        "2) On each candle close the bot computes Supertrend (ATR 10 × 3), MavilimW and EMA 200.\n"
        "3) When the trend flips you get a signal: entry, stop (Supertrend line), TP1–TP3 (1R/2R/3R) "
        "and an indicative leverage.\n"
        "4) ⭐ Strength = confirmations: MavilimW, EMA 200, volume.\n\n"
        "⚠️ Not investment advice. Always use a stop-loss and risk no more than 1–2% per trade."
    ),
    "delete_ask": "Delete all your data and stop notifications?",
    "delete_yes": "✅ Yes, delete", "delete_no": "↩️ Cancel",
    "deleted": "🗑 Your data was deleted. Use /start to set up again.",
    "need_terms": "Please accept the terms first: /start",
    "sig_entry": "Entry", "sig_stop": "Stop", "sig_lev": "Indicative leverage", "sig_strength": "Strength",
    "sig_why": "Confirmations", "ok_mavw": "MavilimW with trend", "ok_ema": "Price vs EMA 200 with trend",
    "ok_vol": "Above-average volume", "none": "none",
    "futures": "Futures", "spot": "Spot", "buy": "BUY (spot)", "exit": "EXIT / SELL",
    "exit_note": "Trend turned down. Do not enter long; consider reviewing open positions.",
    "disc": "⚠️ Not investment advice. High risk. DYOR.",
    "price_fmt": ("💱 <b>{s}</b>\n💰 Price: <code>{p}</code>\n📈 24h: <b>{ch}</b>\n"
                  "⬆️ High: <code>{hi}</code>\n⬇️ Low: <code>{lo}</code>\n📊 Volume: {vol} USDT"),
    "price_usage": "Usage: /price BTC",
    "top_head": "🔥 <b>Top movers · 24h · Futures</b>", "top_up": "🟢 Gainers", "top_down": "🔴 Losers",
    "top_hint": "Tip: /price SOL shows a single coin.",
    "calc_usage": ("🧮 <b>Risk calculator</b>\nUsage: <code>/calc balance risk% entry stop</code>\n"
                   "Example: <code>/calc 1000 1 65000 64000</code>"),
    "calc_result": ("🧮 <b>Position calculator</b>\n💵 Risk: <code>{risk}</code> USDT ({pct}%)\n"
                    "📏 Stop distance: <b>{dist}%</b>\n📦 Position size: <code>{size}</code> USDT\n"
                    "🔢 Quantity: <code>{qty}</code>\n⚙️ Min. leverage needed: <b>{lev}x</b>\n\n"
                    "⚠️ Educational tool, not advice."),
    "calc_bad": "❌ Invalid numbers. Example: /calc 1000 1 65000 64000",
    "test_sent": "✅ This is a TEST signal (sample data):",
    "hist_head": "🕘 <b>Latest signals for your coins</b>", "hist_empty": "No signals yet. Be patient — signals appear when a trend flips.",
    "data_head": "📊 <b>Live market</b>",
    "err": "⚠️ Something went wrong. Please try again.", "wait": "⏳ Please wait a moment.",
    "cmds": ("📋 Menu|🪙 My coins|⏱ Timeframes|💱 Live price|🔥 Top movers|🧮 Risk calculator|"
             "🕘 Signal history|🌐 Language|💝 Donate|⚖️ Terms|❓ Help|🗑 Delete my data"),
    "desc": ("Елена Хьюз turns live global market and liquidity data into clear, graded (0–10) trading signals for Futures and "
             "Spot: entry, stop and 3 take-profit levels, backed by Supertrend, EMA, RSI, MACD, ADX and volume "
             "analysis, with charts and plain-language summaries. Favorites, leverage guidance, multi-language "
             "alerts and real performance stats. Informational only — not investment advice."),
    "short_desc": "Елена Хьюз · Professional crypto signals, graded 0–10, with charts · 8 languages",
}

# ============================================================ РУССКИЙ
T["ru"] = {
    "name": "🇷🇺 Русский",
    "terms": (
        "⚖️ <b>Условия использования и уведомление о рисках</b>\n\n"
        "• Бот автоматически отправляет информацию на основе технического анализа. Это <b>не является</b> "
        "инвестиционной консультацией, рекомендацией к сделке или обещанием дохода.\n"
        "• Торговля криптовалютами, особенно с кредитным плечом, может привести к потере всего капитала.\n"
        "• Сигналы могут запаздывать или быть ошибочными. Все решения и их последствия — на вашей ответственности.\n"
        "• Вы подтверждаете, что вам исполнилось 18 лет и что вы соблюдаете законы своей страны.\n"
        "• Мы храним: ваш Telegram chat id, язык и настройки. Данные не передаются третьим лицам; "
        "удалить их можно командой /delete.\n"
        "• Пожертвования добровольны, не гарантируют никаких услуг или дохода и не возвращаются."
    ),
    "accept": "✅ Принимаю", "decline": "❌ Отказаться",
    "declined": "Вы отказались от условий. Бот не будет присылать сигналы. Чтобы начать заново — /start",
    "menu": ("📋 <b>Панель</b>  {status}\n\n🪙 Монеты: <b>{n}</b>\n⏱ Таймфреймы: <b>{tfs}</b>\n"
             "📈 Рынок: <b>{market}</b>\n⚙️ Макс. плечо: <b>{lev}x</b>\n🔔 Только сильные: <b>{strong}</b>\n"
             "🌙 Тихие часы: <b>{quiet}</b>"),
    "st_on": "🟢 Активен", "st_off": "⏸ Пауза", "on": "вкл", "off": "выкл",
    "b_coins": "🪙 Монеты / избранное", "b_tfs": "⏱ Таймфреймы", "b_market": "📈 Тип рынка",
    "b_lev": "⚙️ Плечо", "b_strong": "🔔 Только сильные: {v}", "b_quiet": "🌙 Тихие часы",
    "b_data": "📊 Рынок онлайн", "b_hist": "🕘 История", "b_calc": "🧮 Калькулятор",
    "b_lang": "🌐 Язык", "b_help": "❓ Помощь", "b_terms": "⚖️ Условия", "b_donate": "💝 Поддержать",
    "b_delete": "🗑 Удалить мои данные", "b_back": "⬅️ Назад", "b_pause": "⏸ Пауза уведомлений",
    "b_resume": "▶️ Возобновить",
    "coins_head": ("🪙 <b>Мои монеты</b> ({n}): {lst}\n\nНажмите на монету, чтобы добавить/убрать. "
                   "Нет в списке? Напишите: <code>/add SOL</code>"),
    "tfs_head": "⏱ <b>Таймфреймы</b>\nВыберите один или несколько. Короткие ТФ дают больше ложных сигналов.",
    "market_head": "📈 <b>Тип сигналов</b>",
    "mkt_futures": "Фьючерсы (Long/Short)", "mkt_spot": "Спот", "mkt_both": "Фьючерсы + Спот",
    "lev_head": "⚙️ <b>Максимальное плечо</b>\nБот никогда не предложит плечо выше вашего лимита.",
    "quiet_head": ("🌙 <b>Тихие часы</b>\nВ это время сигналы приходят без звука.\n"
                   "Ваш часовой пояс: <b>UTC{tz}</b> — меняйте кнопками ➖ ➕"),
    "quiet_off": "Выкл (всегда со звуком)",
    "added": "✅ Добавлено: {s}", "removed": "🗑 Удалено: {s}", "notfound": "❌ Пара не найдена: {s}",
    "usage_add": "Использование: /add SOL  или  /remove SOL", "limit": "Лимит монет: {n}",
    "donate": ("💝 <b>Поддержать проект</b>\nПожертвование добровольно и не даёт гарантий дохода или "
               "дополнительных услуг. Спасибо!"),
    "b_donate_open": "💝 Открыть страницу пожертвований",
    "help": (
        "❓ <b>Как это работает</b>\n\n"
        "1) Выберите монеты и таймфреймы.\n"
        "2) Бот на закрытии свечи считает Supertrend (ATR 10 × 3), MavilimW и EMA 200.\n"
        "3) При смене тренда вы получаете сигнал: вход, стоп (линия Supertrend), цели TP1–TP3 (1R/2R/3R) "
        "и ориентировочное плечо.\n"
        "4) ⭐ Сила = подтверждения: MavilimW, EMA 200, объём.\n\n"
        "⚠️ Это не инвестсовет. Используйте стоп-лосс и риск не более 1–2% депозита на сделку."
    ),
    "delete_ask": "Удалить все ваши данные и остановить уведомления?",
    "delete_yes": "✅ Да, удалить", "delete_no": "↩️ Отмена",
    "deleted": "🗑 Данные удалены. Для повторного запуска — /start",
    "need_terms": "Сначала примите условия: /start",
    "sig_entry": "Вход", "sig_stop": "Стоп", "sig_lev": "Ориентир. плечо", "sig_strength": "Сила",
    "sig_why": "Подтверждения", "ok_mavw": "MavilimW по тренду", "ok_ema": "Цена относительно EMA 200 по тренду",
    "ok_vol": "Объём выше среднего", "none": "нет",
    "futures": "Фьючерсы", "spot": "Спот", "buy": "BUY (спот)", "exit": "EXIT / ПРОДАЖА",
    "exit_note": "Тренд развернулся вниз. Не входить в лонг; открытые позиции стоит пересмотреть.",
    "disc": "⚠️ Не инвестсовет. Высокий риск. DYOR.",
    "price_fmt": ("💱 <b>{s}</b>\n💰 Цена: <code>{p}</code>\n📈 24ч: <b>{ch}</b>\n"
                  "⬆️ Макс: <code>{hi}</code>\n⬇️ Мин: <code>{lo}</code>\n📊 Объём: {vol} USDT"),
    "price_usage": "Использование: /price BTC",
    "top_head": "🔥 <b>Лидеры движения · 24ч · Фьючерсы</b>", "top_up": "🟢 Рост", "top_down": "🔴 Падение",
    "top_hint": "Совет: /price SOL покажет одну монету.",
    "calc_usage": ("🧮 <b>Калькулятор риска</b>\nИспользование: <code>/calc баланс риск% вход стоп</code>\n"
                   "Пример: <code>/calc 1000 1 65000 64000</code>"),
    "calc_result": ("🧮 <b>Калькулятор позиции</b>\n💵 Риск: <code>{risk}</code> USDT ({pct}%)\n"
                    "📏 Дистанция до стопа: <b>{dist}%</b>\n📦 Размер позиции: <code>{size}</code> USDT\n"
                    "🔢 Количество: <code>{qty}</code>\n⚙️ Мин. необходимое плечо: <b>{lev}x</b>\n\n"
                    "⚠️ Учебный инструмент, не рекомендация."),
    "calc_bad": "❌ Неверные числа. Пример: /calc 1000 1 65000 64000",
    "test_sent": "✅ Это ТЕСТОВЫЙ сигнал (пример данных):",
    "hist_head": "🕘 <b>Последние сигналы по вашим монетам</b>",
    "hist_empty": "Сигналов пока нет. Они приходят при смене тренда.",
    "data_head": "📊 <b>Рынок онлайн</b>",
    "err": "⚠️ Что-то пошло не так. Попробуйте ещё раз.", "wait": "⏳ Подождите немного.",
    "cmds": ("📋 Меню|🪙 Мои монеты|⏱ Таймфреймы|💱 Цена онлайн|🔥 Лидеры рынка|🧮 Калькулятор риска|"
             "🕘 История сигналов|🌐 Язык|💝 Поддержать|⚖️ Условия|❓ Помощь|🗑 Удалить мои данные"),
    "desc": ("Елена Хьюз — элитный криптовалютный терминал и сигнальный бот нового поколения.\n\n"
             "🚀 Живые сигналы 0–10 силы с целями TP1/TP2/TP3 и стоп-лоссом\n"
             "📊 Интерактивный терминал Mini App с графиками TradingView\n"
             "🤖 Управление авто-ботом и мультичейн кошельками\n"
             "🧠 Анализ ликвидности, объёмов и индикаторов (Supertrend, EMA, RSI, MACD)\n\n"
             "Нажмите «Открыть» для запуска терминала!"),
    "short_desc": "Елена Хьюз · Терминал крипто-сигналов и авто-трейдинга нового поколения 🚀",
}

# ============================================================ TÜRKÇE
T["tr"] = {
    "name": "🇹🇷 Türkçe",
    "terms": (
        "⚖️ <b>Kullanım Şartları ve Risk Bildirimi</b>\n\n"
        "• Bu bot teknik analize dayalı otomatik bilgilendirme gönderir. Yatırım danışmanlığı, alım-satım "
        "tavsiyesi veya getiri taahhüdü <b>değildir</b>.\n"
        "• Kripto işlemleri, özellikle kaldıraçlı olanlar, sermayenizin tamamını kaybetmenize yol açabilir.\n"
        "• Sinyaller gecikebilir veya hatalı olabilir. Tüm karar ve sonuçların sorumluluğu size aittir.\n"
        "• 18 yaşını doldurduğunuzu ve ülkenizin yasalarına uyduğunuzu beyan edersiniz.\n"
        "• Saklanan veriler: Telegram chat id'niz, dil ve tercihleriniz. Üçüncü kişilerle paylaşılmaz; "
        "/delete ile silebilirsiniz.\n"
        "• Bağış tamamen isteğe bağlıdır, hizmet veya getiri garantisi vermez ve iade edilmez."
    ),
    "accept": "✅ Kabul ediyorum", "decline": "❌ Reddet",
    "declined": "Şartları reddettiniz. Sinyal gönderilmeyecek. Yeniden başlamak için /start",
    "menu": ("📋 <b>Panel</b>  {status}\n\n🪙 Coin: <b>{n}</b>\n⏱ Zaman dilimleri: <b>{tfs}</b>\n"
             "📈 Piyasa: <b>{market}</b>\n⚙️ Maks. kaldıraç: <b>{lev}x</b>\n🔔 Sadece güçlü: <b>{strong}</b>\n"
             "🌙 Sessiz saatler: <b>{quiet}</b>"),
    "st_on": "🟢 Aktif", "st_off": "⏸ Duraklatıldı", "on": "açık", "off": "kapalı",
    "b_coins": "🪙 Coinler / favoriler", "b_tfs": "⏱ Zaman dilimleri", "b_market": "📈 Piyasa türü",
    "b_lev": "⚙️ Kaldıraç", "b_strong": "🔔 Sadece güçlü: {v}", "b_quiet": "🌙 Sessiz saatler",
    "b_data": "📊 Canlı piyasa", "b_hist": "🕘 Geçmiş", "b_calc": "🧮 Hesaplayıcı",
    "b_lang": "🌐 Dil", "b_help": "❓ Yardım", "b_terms": "⚖️ Şartlar", "b_donate": "💝 Bağış",
    "b_delete": "🗑 Verilerimi sil", "b_back": "⬅️ Geri", "b_pause": "⏸ Bildirimleri durdur",
    "b_resume": "▶️ Bildirimleri aç",
    "coins_head": ("🪙 <b>Coinlerim</b> ({n}): {lst}\n\nEklemek/çıkarmak için coine dokun. "
                   "Listede yok mu? Yaz: <code>/add SOL</code>"),
    "tfs_head": "⏱ <b>Zaman dilimleri</b>\nBir veya birkaç tane seç. Kısa periyotlar daha çok yanlış sinyal üretir.",
    "market_head": "📈 <b>Sinyal türü</b>",
    "mkt_futures": "Futures (Long/Short)", "mkt_spot": "Spot", "mkt_both": "Futures + Spot",
    "lev_head": "⚙️ <b>Maksimum kaldıraç</b>\nBot, senin limitinin üstünde kaldıraç önermez.",
    "quiet_head": ("🌙 <b>Sessiz saatler</b>\nBu saatlerde sinyaller sessiz (sesli bildirim olmadan) gelir.\n"
                   "Saat dilimin: <b>UTC{tz}</b> — ➖ ➕ ile ayarla"),
    "quiet_off": "Kapalı (hep sesli)",
    "added": "✅ Eklendi: {s}", "removed": "🗑 Çıkarıldı: {s}", "notfound": "❌ Parite bulunamadı: {s}",
    "usage_add": "Kullanım: /add SOL  veya  /remove SOL", "limit": "Coin limiti: {n}",
    "donate": ("💝 <b>Projeyi destekle</b>\nBağış isteğe bağlıdır; getiri veya ek hizmet garantisi vermez. "
               "Teşekkürler!"),
    "b_donate_open": "💝 Bağış sayfasını aç",
    "help": (
        "❓ <b>Nasıl çalışır?</b>\n\n"
        "1) Coin ve zaman dilimlerini seç.\n"
        "2) Bot her mum kapanışında Supertrend (ATR 10 × 3), MavilimW ve EMA 200 hesaplar.\n"
        "3) Trend yön değiştirince sinyal gelir: giriş, stop (Supertrend çizgisi), TP1–TP3 (1R/2R/3R) "
        "ve yaklaşık kaldıraç.\n"
        "4) ⭐ Güç = teyitler: MavilimW, EMA 200, hacim.\n\n"
        "⚠️ Yatırım tavsiyesi değildir. Daima stop kullan, işlem başına riskin %1–2'yi geçmesin."
    ),
    "delete_ask": "Tüm verilerin silinsin ve bildirimler durdurulsun mu?",
    "delete_yes": "✅ Evet, sil", "delete_no": "↩️ Vazgeç",
    "deleted": "🗑 Verilerin silindi. Yeniden kurmak için /start",
    "need_terms": "Önce şartları kabul et: /start",
    "sig_entry": "Giriş", "sig_stop": "Stop", "sig_lev": "Önerilen kaldıraç", "sig_strength": "Güç",
    "sig_why": "Teyitler", "ok_mavw": "MavilimW trendle uyumlu", "ok_ema": "Fiyat/EMA 200 trendle uyumlu",
    "ok_vol": "Hacim ortalamanın üstünde", "none": "yok",
    "futures": "Futures", "spot": "Spot", "buy": "AL (spot)", "exit": "ÇIKIŞ / SAT",
    "exit_note": "Trend aşağı döndü. Long'a girme; açık pozisyonları gözden geçir.",
    "disc": "⚠️ Yatırım tavsiyesi değildir. Yüksek risk. Kendi araştırmanı yap.",
    "price_fmt": ("💱 <b>{s}</b>\n💰 Fiyat: <code>{p}</code>\n📈 24s: <b>{ch}</b>\n"
                  "⬆️ Yüksek: <code>{hi}</code>\n⬇️ Düşük: <code>{lo}</code>\n📊 Hacim: {vol} USDT"),
    "price_usage": "Kullanım: /price BTC",
    "top_head": "🔥 <b>En çok hareket edenler · 24s · Futures</b>", "top_up": "🟢 Yükselenler",
    "top_down": "🔴 Düşenler", "top_hint": "İpucu: /price SOL tek bir coini gösterir.",
    "calc_usage": ("🧮 <b>Risk hesaplayıcı</b>\nKullanım: <code>/calc bakiye risk% giriş stop</code>\n"
                   "Örnek: <code>/calc 1000 1 65000 64000</code>"),
    "calc_result": ("🧮 <b>Pozisyon hesaplayıcı</b>\n💵 Risk: <code>{risk}</code> USDT ({pct}%)\n"
                    "📏 Stop mesafesi: <b>{dist}%</b>\n📦 Pozisyon büyüklüğü: <code>{size}</code> USDT\n"
                    "🔢 Miktar: <code>{qty}</code>\n⚙️ Gereken min. kaldıraç: <b>{lev}x</b>\n\n"
                    "⚠️ Eğitim amaçlı araçtır, tavsiye değildir."),
    "calc_bad": "❌ Geçersiz sayılar. Örnek: /calc 1000 1 65000 64000",
    "test_sent": "✅ Bu bir TEST sinyalidir (örnek veri):",
    "hist_head": "🕘 <b>Coinlerin için son sinyaller</b>",
    "hist_empty": "Henüz sinyal yok. Sinyal, trend yön değiştirince gelir.",
    "data_head": "📊 <b>Canlı piyasa</b>",
    "err": "⚠️ Bir şeyler ters gitti. Lütfen tekrar dene.", "wait": "⏳ Lütfen biraz bekle.",
    "cmds": ("📋 Menü|🪙 Coinlerim|⏱ Zaman dilimleri|💱 Canlı fiyat|🔥 En çok hareket edenler|"
             "🧮 Risk hesaplayıcı|🕘 Sinyal geçmişi|🌐 Dil|💝 Bağış|⚖️ Şartlar|❓ Yardım|🗑 Verilerimi sil"),
    "desc": ("Елена Хьюз — Yeni nesil profesyonel kripto sinyal ve Web3 terminal ekosistemi.\n\n"
             "🚀 0–10 güç puanlı canlı sinyaller, TP1/TP2/TP3 hedefleri ve stop-loss\n"
             "📊 TradingView canlı mum grafiği entegrasyonlu modern Mini App terminali\n"
             "🤖 Otomatik al-sat (Oto-Bot) ve çoklu ağ cüzdan yönetimi\n"
             "🧠 Gelişmiş indikatörler: Supertrend, MavilimW, EMA 200, RSI, MACD ve hacim analizi\n\n"
             "Terminale erişmek için aşağıdaki «Uygulamayı Aç» butonuna dokunun!"),
    "short_desc": "Елена Хьюз · Yeni nesil kripto sinyal ve Web3 otomatik ticaret terminali 🚀",
}

# ============================================================ УКРАЇНСЬКА
T["uk"] = {
    "name": "🇺🇦 Українська",
    "terms": (
        "⚖️ <b>Умови користування та повідомлення про ризики</b>\n\n"
        "• Бот автоматично надсилає інформацію на основі технічного аналізу. Це <b>не є</b> "
        "інвестиційною консультацією, рекомендацією до угоди чи обіцянкою прибутку.\n"
        "• Торгівля криптовалютами, особливо з кредитним плечем, може призвести до втрати всього капіталу.\n"
        "• Сигнали можуть запізнюватися або бути помилковими. Усі рішення та їхні наслідки — на вашій відповідальності.\n"
        "• Ви підтверджуєте, що вам виповнилося 18 років і що ви дотримуєтесь законів своєї країни.\n"
        "• Ми зберігаємо: ваш Telegram chat id, мову та налаштування. Дані не передаються третім особам; "
        "видалити їх можна командою /delete.\n"
        "• Пожертви добровільні, не гарантують жодних послуг чи прибутку і не повертаються."
    ),
    "accept": "✅ Приймаю", "decline": "❌ Відмовитися",
    "declined": "Ви відмовилися від умов. Бот не надсилатиме сигнали. Щоб почати знову — /start",
    "menu": ("📋 <b>Панель</b>  {status}\n\n🪙 Монети: <b>{n}</b>\n⏱ Таймфрейми: <b>{tfs}</b>\n"
             "📈 Ринок: <b>{market}</b>\n⚙️ Макс. плече: <b>{lev}x</b>\n🔔 Лише сильні: <b>{strong}</b>\n"
             "🌙 Тихі години: <b>{quiet}</b>"),
    "st_on": "🟢 Активний", "st_off": "⏸ Пауза", "on": "увімк", "off": "вимк",
    "b_coins": "🪙 Монети / обране", "b_tfs": "⏱ Таймфрейми", "b_market": "📈 Тип ринку",
    "b_lev": "⚙️ Плече", "b_strong": "🔔 Лише сильні: {v}", "b_quiet": "🌙 Тихі години",
    "b_data": "📊 Ринок онлайн", "b_hist": "🕘 Історія", "b_calc": "🧮 Калькулятор",
    "b_lang": "🌐 Мова", "b_help": "❓ Допомога", "b_terms": "⚖️ Умови", "b_donate": "💝 Підтримати",
    "b_delete": "🗑 Видалити мої дані", "b_back": "⬅️ Назад", "b_pause": "⏸ Пауза сповіщень",
    "b_resume": "▶️ Відновити",
    "coins_head": ("🪙 <b>Мої монети</b> ({n}): {lst}\n\nНатисніть на монету, щоб додати/прибрати. "
                   "Немає в списку? Напишіть: <code>/add SOL</code>"),
    "tfs_head": "⏱ <b>Таймфрейми</b>\nОберіть один або кілька. Короткі ТФ дають більше хибних сигналів.",
    "market_head": "📈 <b>Тип сигналів</b>",
    "mkt_futures": "Ф'ючерси (Long/Short)", "mkt_spot": "Спот", "mkt_both": "Ф'ючерси + Спот",
    "lev_head": "⚙️ <b>Максимальне плече</b>\nБот ніколи не запропонує плече вище за ваш ліміт.",
    "quiet_head": ("🌙 <b>Тихі години</b>\nУ цей час сигнали приходять без звуку.\n"
                   "Ваш часовий пояс: <b>UTC{tz}</b> — змінюйте кнопками ➖ ➕"),
    "quiet_off": "Вимк (завжди зі звуком)",
    "added": "✅ Додано: {s}", "removed": "🗑 Видалено: {s}", "notfound": "❌ Пару не знайдено: {s}",
    "usage_add": "Використання: /add SOL  або  /remove SOL", "limit": "Ліміт монет: {n}",
    "donate": ("💝 <b>Підтримати проєкт</b>\nПожертва добровільна і не дає гарантій прибутку чи "
               "додаткових послуг. Дякуємо!"),
    "b_donate_open": "💝 Відкрити сторінку пожертв",
    "help": (
        "❓ <b>Як це працює</b>\n\n"
        "1) Оберіть монети та таймфрейми.\n"
        "2) На закритті свічки бот рахує Supertrend (ATR 10 × 3), MavilimW та EMA 200.\n"
        "3) При зміні тренду ви отримуєте сигнал: вхід, стоп (лінія Supertrend), цілі TP1–TP3 (1R/2R/3R) "
        "та орієнтовне плече.\n"
        "4) ⭐ Сила = підтвердження: MavilimW, EMA 200, обсяг.\n\n"
        "⚠️ Це не інвестиційна порада. Використовуйте стоп-лосс і ризикуйте не більше 1–2% депозиту на угоду."
    ),
    "delete_ask": "Видалити всі ваші дані та зупинити сповіщення?",
    "delete_yes": "✅ Так, видалити", "delete_no": "↩️ Скасувати",
    "deleted": "🗑 Дані видалено. Для повторного запуску — /start",
    "need_terms": "Спочатку прийміть умови: /start",
    "sig_entry": "Вхід", "sig_stop": "Стоп", "sig_lev": "Орієнтовне плече", "sig_strength": "Сила",
    "sig_why": "Підтвердження", "ok_mavw": "MavilimW за трендом", "ok_ema": "Ціна відносно EMA 200 за трендом",
    "ok_vol": "Обсяг вищий за середній", "none": "немає",
    "futures": "Ф'ючерси", "spot": "Спот", "buy": "BUY (спот)", "exit": "EXIT / ПРОДАЖ",
    "exit_note": "Тренд розвернувся вниз. Не входити в лонг; відкриті позиції варто переглянути.",
    "disc": "⚠️ Не інвестиційна порада. Високий ризик. DYOR.",
    "price_fmt": ("💱 <b>{s}</b>\n💰 Ціна: <code>{p}</code>\n📈 24г: <b>{ch}</b>\n"
                  "⬆️ Макс: <code>{hi}</code>\n⬇️ Мін: <code>{lo}</code>\n📊 Обсяг: {vol} USDT"),
    "price_usage": "Використання: /price BTC",
    "top_head": "🔥 <b>Лідери руху · 24г · Ф'ючерси</b>", "top_up": "🟢 Зростання", "top_down": "🔴 Падіння",
    "top_hint": "Порада: /price SOL покаже одну монету.",
    "calc_usage": ("🧮 <b>Калькулятор ризику</b>\nВикористання: <code>/calc баланс ризик% вхід стоп</code>\n"
                   "Приклад: <code>/calc 1000 1 65000 64000</code>"),
    "calc_result": ("🧮 <b>Калькулятор позиції</b>\n💵 Ризик: <code>{risk}</code> USDT ({pct}%)\n"
                    "📏 Відстань до стопу: <b>{dist}%</b>\n📦 Розмір позиції: <code>{size}</code> USDT\n"
                    "🔢 Кількість: <code>{qty}</code>\n⚙️ Мін. потрібне плече: <b>{lev}x</b>\n\n"
                    "⚠️ Навчальний інструмент, не рекомендація."),
    "calc_bad": "❌ Невірні числа. Приклад: /calc 1000 1 65000 64000",
    "test_sent": "✅ Це ТЕСТОВИЙ сигнал (приклад даних):",
    "hist_head": "🕘 <b>Останні сигнали за вашими монетами</b>",
    "hist_empty": "Сигналів поки немає. Вони приходять при зміні тренду.",
    "data_head": "📊 <b>Ринок онлайн</b>",
    "err": "⚠️ Щось пішло не так. Спробуйте ще раз.", "wait": "⏳ Зачекайте трохи.",
    "cmds": ("📋 Меню|🪙 Мої монети|⏱ Таймфрейми|💱 Ціна онлайн|🔥 Лідери ринку|🧮 Калькулятор ризику|"
             "🕘 Історія сигналів|🌐 Мова|💝 Підтримати|⚖️ Умови|❓ Допомога|🗑 Видалити мої дані"),
    "desc": ("Елена Хьюз перетворює живі ринкові дані та ліквідність на чіткі сигнали з оцінкою сили 0–10 для ф'ючерсів і "
             "споту: вхід, стоп і 3 рівні тейк-профіту, на основі Supertrend, EMA, RSI, MACD, ADX та обсягу, "
             "з графіками та простими поясненнями. Обране, підказки щодо плеча, сповіщення 8 мовами та "
             "реальна статистика. Лише інформація — не інвестиційна порада."),
    "short_desc": "Елена Хьюз · Професійні крипто-сигнали з оцінкою 0–10 і графіками · 8 мов",
}

# ============================================================ DEUTSCH
T["de"] = {
    "name": "🇩🇪 Deutsch",
    "terms": (
        "⚖️ <b>Nutzungsbedingungen & Risikohinweis</b>\n\n"
        "• Dieser Bot sendet automatisierte Informationen auf Basis technischer Analyse. Er ist <b>keine</b> "
        "Anlageberatung, Handelsempfehlung oder Renditezusage.\n"
        "• Der Handel mit Kryptowährungen, besonders mit Hebel, kann zum Totalverlust Ihres Kapitals führen.\n"
        "• Signale können verzögert oder fehlerhaft sein. Alle Entscheidungen und Folgen liegen in Ihrer Verantwortung.\n"
        "• Sie bestätigen, dass Sie mindestens 18 Jahre alt sind und die Gesetze Ihres Landes einhalten.\n"
        "• Gespeicherte Daten: Ihre Telegram-Chat-ID, Sprache und Einstellungen. Keine Weitergabe an Dritte; "
        "Löschung mit /delete.\n"
        "• Spenden sind freiwillig, begründen keinen Anspruch auf Leistung oder Rendite und sind nicht erstattungsfähig."
    ),
    "accept": "✅ Ich stimme zu", "decline": "❌ Ablehnen",
    "declined": "Sie haben die Bedingungen abgelehnt. Es werden keine Signale gesendet. Neustart mit /start",
    "menu": ("📋 <b>Übersicht</b>  {status}\n\n🪙 Coins: <b>{n}</b>\n⏱ Zeitrahmen: <b>{tfs}</b>\n"
             "📈 Markt: <b>{market}</b>\n⚙️ Max. Hebel: <b>{lev}x</b>\n🔔 Nur starke: <b>{strong}</b>\n"
             "🌙 Ruhezeiten: <b>{quiet}</b>"),
    "st_on": "🟢 Aktiv", "st_off": "⏸ Pausiert", "on": "an", "off": "aus",
    "b_coins": "🪙 Coins / Favoriten", "b_tfs": "⏱ Zeitrahmen", "b_market": "📈 Markttyp",
    "b_lev": "⚙️ Hebel", "b_strong": "🔔 Nur starke: {v}", "b_quiet": "🌙 Ruhezeiten",
    "b_data": "📊 Live-Markt", "b_hist": "🕘 Verlauf", "b_calc": "🧮 Rechner",
    "b_lang": "🌐 Sprache", "b_help": "❓ Hilfe", "b_terms": "⚖️ Bedingungen", "b_donate": "💝 Spenden",
    "b_delete": "🗑 Meine Daten löschen", "b_back": "⬅️ Zurück", "b_pause": "⏸ Benachrichtigungen pausieren",
    "b_resume": "▶️ Fortsetzen",
    "coins_head": ("🪙 <b>Meine Coins</b> ({n}): {lst}\n\nTippen Sie auf einen Coin zum Hinzufügen/Entfernen. "
                   "Nicht in der Liste? Senden Sie: <code>/add SOL</code>"),
    "tfs_head": "⏱ <b>Zeitrahmen</b>\nWählen Sie einen oder mehrere. Kurze Zeitrahmen erzeugen mehr Fehlsignale.",
    "market_head": "📈 <b>Signaltyp</b>",
    "mkt_futures": "Futures (Long/Short)", "mkt_spot": "Spot", "mkt_both": "Futures + Spot",
    "lev_head": "⚙️ <b>Maximaler Hebel</b>\nDer Bot schlägt nie einen höheren Hebel als Ihr Limit vor.",
    "quiet_head": ("🌙 <b>Ruhezeiten</b>\nIn diesen Stunden kommen Signale lautlos an.\n"
                   "Ihre Zeitzone: <b>UTC{tz}</b> — mit ➖ ➕ anpassen"),
    "quiet_off": "Aus (immer mit Ton)",
    "added": "✅ Hinzugefügt: {s}", "removed": "🗑 Entfernt: {s}", "notfound": "❌ Paar nicht gefunden: {s}",
    "usage_add": "Nutzung: /add SOL  oder  /remove SOL", "limit": "Coin-Limit: {n}",
    "donate": ("💝 <b>Projekt unterstützen</b>\nSpenden sind freiwillig und garantieren weder Rendite noch "
               "Zusatzleistungen. Danke!"),
    "b_donate_open": "💝 Spendenseite öffnen",
    "help": (
        "❓ <b>So funktioniert es</b>\n\n"
        "1) Wählen Sie Coins und Zeitrahmen.\n"
        "2) Bei jedem Kerzenschluss berechnet der Bot Supertrend (ATR 10 × 3), MavilimW und EMA 200.\n"
        "3) Bei einem Trendwechsel erhalten Sie ein Signal: Einstieg, Stop (Supertrend-Linie), TP1–TP3 (1R/2R/3R) "
        "und einen Richtwert für den Hebel.\n"
        "4) ⭐ Stärke = Bestätigungen: MavilimW, EMA 200, Volumen.\n\n"
        "⚠️ Keine Anlageberatung. Immer Stop-Loss nutzen und höchstens 1–2 % pro Trade riskieren."
    ),
    "delete_ask": "Alle Ihre Daten löschen und Benachrichtigungen stoppen?",
    "delete_yes": "✅ Ja, löschen", "delete_no": "↩️ Abbrechen",
    "deleted": "🗑 Ihre Daten wurden gelöscht. Neustart mit /start",
    "need_terms": "Bitte akzeptieren Sie zuerst die Bedingungen: /start",
    "sig_entry": "Einstieg", "sig_stop": "Stop", "sig_lev": "Richtwert Hebel", "sig_strength": "Stärke",
    "sig_why": "Bestätigungen", "ok_mavw": "MavilimW im Trend", "ok_ema": "Preis vs. EMA 200 im Trend",
    "ok_vol": "Überdurchschnittliches Volumen", "none": "keine",
    "futures": "Futures", "spot": "Spot", "buy": "KAUF (Spot)", "exit": "AUSSTIEG / VERKAUF",
    "exit_note": "Der Trend hat nach unten gedreht. Kein Long-Einstieg; offene Positionen prüfen.",
    "disc": "⚠️ Keine Anlageberatung. Hohes Risiko. DYOR.",
    "price_fmt": ("💱 <b>{s}</b>\n💰 Preis: <code>{p}</code>\n📈 24h: <b>{ch}</b>\n"
                  "⬆️ Hoch: <code>{hi}</code>\n⬇️ Tief: <code>{lo}</code>\n📊 Volumen: {vol} USDT"),
    "price_usage": "Nutzung: /price BTC",
    "top_head": "🔥 <b>Top-Bewegungen · 24h · Futures</b>", "top_up": "🟢 Gewinner", "top_down": "🔴 Verlierer",
    "top_hint": "Tipp: /price SOL zeigt einen einzelnen Coin.",
    "calc_usage": ("🧮 <b>Risikorechner</b>\nNutzung: <code>/calc Guthaben Risiko% Einstieg Stop</code>\n"
                   "Beispiel: <code>/calc 1000 1 65000 64000</code>"),
    "calc_result": ("🧮 <b>Positionsrechner</b>\n💵 Risiko: <code>{risk}</code> USDT ({pct}%)\n"
                    "📏 Stop-Abstand: <b>{dist}%</b>\n📦 Positionsgröße: <code>{size}</code> USDT\n"
                    "🔢 Menge: <code>{qty}</code>\n⚙️ Nötiger Mindesthebel: <b>{lev}x</b>\n\n"
                    "⚠️ Lernwerkzeug, keine Empfehlung."),
    "calc_bad": "❌ Ungültige Zahlen. Beispiel: /calc 1000 1 65000 64000",
    "test_sent": "✅ Dies ist ein TEST-Signal (Beispieldaten):",
    "hist_head": "🕘 <b>Letzte Signale für Ihre Coins</b>",
    "hist_empty": "Noch keine Signale. Sie erscheinen bei einem Trendwechsel.",
    "data_head": "📊 <b>Live-Markt</b>",
    "err": "⚠️ Etwas ist schiefgelaufen. Bitte erneut versuchen.", "wait": "⏳ Bitte einen Moment warten.",
    "cmds": ("📋 Menü|🪙 Meine Coins|⏱ Zeitrahmen|💱 Live-Preis|🔥 Top-Bewegungen|🧮 Risikorechner|"
             "🕘 Signalverlauf|🌐 Sprache|💝 Spenden|⚖️ Bedingungen|❓ Hilfe|🗑 Meine Daten löschen"),
    "desc": ("Елена Хьюз verwandelt weltweite Live-Marktdaten in klare, mit 0–10 bewertete Signale für Futures und "
             "Spot: Einstieg, Stop und 3 Take-Profit-Stufen, gestützt auf Supertrend, EMA, RSI, MACD, ADX und "
             "Volumen, mit Charts und einfachen Erklärungen. Favoriten, Hebel-Hinweise, mehrsprachige Alarme "
             "und echte Performance-Statistik. Nur zur Information — keine Anlageberatung."),
    "short_desc": "Елена Хьюз · Professionelle Krypto-Signale, bewertet 0–10, mit Charts · 8 Sprachen",
}

# ============================================================ ESPAÑOL
T["es"] = {
    "name": "🇪🇸 Español",
    "terms": (
        "⚖️ <b>Términos de uso y aviso de riesgo</b>\n\n"
        "• Este bot envía información automática basada en análisis técnico. <b>No</b> es asesoramiento "
        "de inversión, recomendación de operar ni promesa de rentabilidad.\n"
        "• Operar con criptomonedas, sobre todo con apalancamiento, puede causar la pérdida total de su capital.\n"
        "• Las señales pueden retrasarse o ser erróneas. Todas las decisiones y sus resultados son de su responsabilidad.\n"
        "• Confirma que es mayor de 18 años y que cumple las leyes de su país.\n"
        "• Datos almacenados: su chat id de Telegram, idioma y ajustes. No se comparten con terceros; "
        "puede borrarlos con /delete.\n"
        "• Las donaciones son voluntarias, no garantizan servicio ni rentabilidad y no son reembolsables."
    ),
    "accept": "✅ Acepto", "decline": "❌ Rechazar",
    "declined": "Rechazó los términos. No se enviarán señales. Use /start para empezar de nuevo.",
    "menu": ("📋 <b>Panel</b>  {status}\n\n🪙 Monedas: <b>{n}</b>\n⏱ Marcos temporales: <b>{tfs}</b>\n"
             "📈 Mercado: <b>{market}</b>\n⚙️ Apalancamiento máx.: <b>{lev}x</b>\n🔔 Solo fuertes: <b>{strong}</b>\n"
             "🌙 Horas de silencio: <b>{quiet}</b>"),
    "st_on": "🟢 Activo", "st_off": "⏸ En pausa", "on": "sí", "off": "no",
    "b_coins": "🪙 Monedas / favoritas", "b_tfs": "⏱ Marcos temporales", "b_market": "📈 Tipo de mercado",
    "b_lev": "⚙️ Apalancamiento", "b_strong": "🔔 Solo fuertes: {v}", "b_quiet": "🌙 Horas de silencio",
    "b_data": "📊 Mercado en vivo", "b_hist": "🕘 Historial", "b_calc": "🧮 Calculadora",
    "b_lang": "🌐 Idioma", "b_help": "❓ Ayuda", "b_terms": "⚖️ Términos", "b_donate": "💝 Donar",
    "b_delete": "🗑 Borrar mis datos", "b_back": "⬅️ Atrás", "b_pause": "⏸ Pausar alertas",
    "b_resume": "▶️ Reanudar alertas",
    "coins_head": ("🪙 <b>Mis monedas</b> ({n}): {lst}\n\nToque una moneda para añadir/quitar. "
                   "¿No está? Envíe: <code>/add SOL</code>"),
    "tfs_head": "⏱ <b>Marcos temporales</b>\nElija uno o varios. Los marcos cortos generan más señales falsas.",
    "market_head": "📈 <b>Tipo de señal</b>",
    "mkt_futures": "Futuros (Long/Short)", "mkt_spot": "Spot", "mkt_both": "Futuros + Spot",
    "lev_head": "⚙️ <b>Apalancamiento máximo</b>\nEl bot nunca sugerirá más apalancamiento que su límite.",
    "quiet_head": ("🌙 <b>Horas de silencio</b>\nEn estas horas las señales llegan sin sonido.\n"
                   "Su zona horaria: <b>UTC{tz}</b> — ajuste con ➖ ➕"),
    "quiet_off": "Desactivado (siempre con sonido)",
    "added": "✅ Añadida: {s}", "removed": "🗑 Eliminada: {s}", "notfound": "❌ Par no encontrado: {s}",
    "usage_add": "Uso: /add SOL  o  /remove SOL", "limit": "Límite de monedas: {n}",
    "donate": ("💝 <b>Apoyar el proyecto</b>\nLas donaciones son voluntarias y no garantizan rentabilidad ni "
               "servicios adicionales. ¡Gracias!"),
    "b_donate_open": "💝 Abrir página de donaciones",
    "help": (
        "❓ <b>Cómo funciona</b>\n\n"
        "1) Elija monedas y marcos temporales.\n"
        "2) En cada cierre de vela el bot calcula Supertrend (ATR 10 × 3), MavilimW y EMA 200.\n"
        "3) Cuando la tendencia cambia recibe una señal: entrada, stop (línea Supertrend), TP1–TP3 (1R/2R/3R) "
        "y un apalancamiento orientativo.\n"
        "4) ⭐ Fuerza = confirmaciones: MavilimW, EMA 200, volumen.\n\n"
        "⚠️ No es asesoramiento de inversión. Use siempre stop-loss y arriesgue como máximo 1–2 % por operación."
    ),
    "delete_ask": "¿Borrar todos sus datos y detener las notificaciones?",
    "delete_yes": "✅ Sí, borrar", "delete_no": "↩️ Cancelar",
    "deleted": "🗑 Sus datos fueron borrados. Use /start para configurar de nuevo.",
    "need_terms": "Acepte primero los términos: /start",
    "sig_entry": "Entrada", "sig_stop": "Stop", "sig_lev": "Apalancamiento orient.", "sig_strength": "Fuerza",
    "sig_why": "Confirmaciones", "ok_mavw": "MavilimW a favor de la tendencia",
    "ok_ema": "Precio vs EMA 200 a favor de la tendencia", "ok_vol": "Volumen superior a la media",
    "none": "ninguna",
    "futures": "Futuros", "spot": "Spot", "buy": "COMPRA (spot)", "exit": "SALIDA / VENTA",
    "exit_note": "La tendencia giró a la baja. No entre en largo; revise las posiciones abiertas.",
    "disc": "⚠️ No es asesoramiento de inversión. Alto riesgo. DYOR.",
    "price_fmt": ("💱 <b>{s}</b>\n💰 Precio: <code>{p}</code>\n📈 24h: <b>{ch}</b>\n"
                  "⬆️ Máx: <code>{hi}</code>\n⬇️ Mín: <code>{lo}</code>\n📊 Volumen: {vol} USDT"),
    "price_usage": "Uso: /price BTC",
    "top_head": "🔥 <b>Mayores movimientos · 24h · Futuros</b>", "top_up": "🟢 Suben", "top_down": "🔴 Bajan",
    "top_hint": "Consejo: /price SOL muestra una sola moneda.",
    "calc_usage": ("🧮 <b>Calculadora de riesgo</b>\nUso: <code>/calc saldo riesgo% entrada stop</code>\n"
                   "Ejemplo: <code>/calc 1000 1 65000 64000</code>"),
    "calc_result": ("🧮 <b>Calculadora de posición</b>\n💵 Riesgo: <code>{risk}</code> USDT ({pct}%)\n"
                    "📏 Distancia al stop: <b>{dist}%</b>\n📦 Tamaño de posición: <code>{size}</code> USDT\n"
                    "🔢 Cantidad: <code>{qty}</code>\n⚙️ Apalancamiento mín. necesario: <b>{lev}x</b>\n\n"
                    "⚠️ Herramienta educativa, no es una recomendación."),
    "calc_bad": "❌ Números no válidos. Ejemplo: /calc 1000 1 65000 64000",
    "test_sent": "✅ Esta es una señal de PRUEBA (datos de ejemplo):",
    "hist_head": "🕘 <b>Últimas señales de sus monedas</b>",
    "hist_empty": "Aún no hay señales. Llegan cuando cambia la tendencia.",
    "data_head": "📊 <b>Mercado en vivo</b>",
    "err": "⚠️ Algo salió mal. Inténtelo de nuevo.", "wait": "⏳ Espere un momento.",
    "cmds": ("📋 Menú|🪙 Mis monedas|⏱ Marcos temporales|💱 Precio en vivo|🔥 Mayores movimientos|"
             "🧮 Calculadora de riesgo|🕘 Historial de señales|🌐 Idioma|💝 Donar|⚖️ Términos|❓ Ayuda|"
             "🗑 Borrar mis datos"),
    "desc": ("Елена Хьюз convierte datos de mercado en vivo en señales claras, con puntuación 0–10, para "
             "Futuros y Spot: entrada, stop y 3 niveles de take-profit, respaldadas por Supertrend, EMA, RSI, "
             "MACD, ADX y volumen, con gráficos y explicaciones sencillas. Favoritas, guía de apalancamiento, "
             "alertas en 8 idiomas y estadísticas reales. Solo informativo — no es asesoramiento de inversión."),
    "short_desc": "Елена Хьюз · Señales cripto profesionales, puntuadas 0–10, con gráficos · 8 idiomas",
}

# ============================================================ FRANÇAIS
T["fr"] = {
    "name": "🇫🇷 Français",
    "terms": (
        "⚖️ <b>Conditions d'utilisation et avertissement sur les risques</b>\n\n"
        "• Ce bot envoie des informations automatiques fondées sur l'analyse technique. Il ne constitue "
        "<b>pas</b> un conseil en investissement, une recommandation de trading ni une promesse de gains.\n"
        "• Le trading de cryptomonnaies, surtout avec effet de levier, peut entraîner la perte totale de votre capital.\n"
        "• Les signaux peuvent être retardés ou erronés. Toutes les décisions et leurs conséquences relèvent de votre responsabilité.\n"
        "• Vous confirmez avoir au moins 18 ans et respecter les lois de votre pays.\n"
        "• Données conservées : votre chat id Telegram, votre langue et vos réglages. Aucun partage avec des tiers ; "
        "suppression via /delete.\n"
        "• Les dons sont volontaires, ne garantissent ni service ni gain et ne sont pas remboursables."
    ),
    "accept": "✅ J'accepte", "decline": "❌ Refuser",
    "declined": "Vous avez refusé les conditions. Aucun signal ne sera envoyé. Relancez avec /start",
    "menu": ("📋 <b>Tableau de bord</b>  {status}\n\n🪙 Coins : <b>{n}</b>\n⏱ Unités de temps : <b>{tfs}</b>\n"
             "📈 Marché : <b>{market}</b>\n⚙️ Levier max : <b>{lev}x</b>\n🔔 Signaux forts seulement : <b>{strong}</b>\n"
             "🌙 Heures calmes : <b>{quiet}</b>"),
    "st_on": "🟢 Actif", "st_off": "⏸ En pause", "on": "oui", "off": "non",
    "b_coins": "🪙 Coins / favoris", "b_tfs": "⏱ Unités de temps", "b_market": "📈 Type de marché",
    "b_lev": "⚙️ Levier", "b_strong": "🔔 Forts seulement : {v}", "b_quiet": "🌙 Heures calmes",
    "b_data": "📊 Marché en direct", "b_hist": "🕘 Historique", "b_calc": "🧮 Calculateur",
    "b_lang": "🌐 Langue", "b_help": "❓ Aide", "b_terms": "⚖️ Conditions", "b_donate": "💝 Faire un don",
    "b_delete": "🗑 Supprimer mes données", "b_back": "⬅️ Retour", "b_pause": "⏸ Suspendre les alertes",
    "b_resume": "▶️ Reprendre les alertes",
    "coins_head": ("🪙 <b>Mes coins</b> ({n}) : {lst}\n\nAppuyez sur un coin pour l'ajouter/le retirer. "
                   "Absent de la liste ? Envoyez : <code>/add SOL</code>"),
    "tfs_head": "⏱ <b>Unités de temps</b>\nChoisissez-en une ou plusieurs. Les courtes génèrent plus de faux signaux.",
    "market_head": "📈 <b>Type de signal</b>",
    "mkt_futures": "Futures (Long/Short)", "mkt_spot": "Spot", "mkt_both": "Futures + Spot",
    "lev_head": "⚙️ <b>Levier maximum</b>\nLe bot ne suggérera jamais un levier supérieur à votre limite.",
    "quiet_head": ("🌙 <b>Heures calmes</b>\nPendant ces heures, les signaux arrivent sans son.\n"
                   "Votre fuseau horaire : <b>UTC{tz}</b> — réglez avec ➖ ➕"),
    "quiet_off": "Désactivé (toujours avec son)",
    "added": "✅ Ajouté : {s}", "removed": "🗑 Retiré : {s}", "notfound": "❌ Paire introuvable : {s}",
    "usage_add": "Usage : /add SOL  ou  /remove SOL", "limit": "Limite de coins : {n}",
    "donate": ("💝 <b>Soutenir le projet</b>\nLes dons sont volontaires et ne garantissent ni gains ni "
               "services supplémentaires. Merci !"),
    "b_donate_open": "💝 Ouvrir la page de dons",
    "help": (
        "❓ <b>Comment ça marche</b>\n\n"
        "1) Choisissez vos coins et unités de temps.\n"
        "2) À chaque clôture de bougie, le bot calcule Supertrend (ATR 10 × 3), MavilimW et EMA 200.\n"
        "3) Quand la tendance s'inverse, vous recevez un signal : entrée, stop (ligne Supertrend), TP1–TP3 (1R/2R/3R) "
        "et un levier indicatif.\n"
        "4) ⭐ Force = confirmations : MavilimW, EMA 200, volume.\n\n"
        "⚠️ Ce n'est pas un conseil en investissement. Utilisez toujours un stop-loss et risquez 1–2 % maximum par trade."
    ),
    "delete_ask": "Supprimer toutes vos données et arrêter les notifications ?",
    "delete_yes": "✅ Oui, supprimer", "delete_no": "↩️ Annuler",
    "deleted": "🗑 Vos données ont été supprimées. Relancez avec /start",
    "need_terms": "Veuillez d'abord accepter les conditions : /start",
    "sig_entry": "Entrée", "sig_stop": "Stop", "sig_lev": "Levier indicatif", "sig_strength": "Force",
    "sig_why": "Confirmations", "ok_mavw": "MavilimW dans le sens de la tendance",
    "ok_ema": "Prix vs EMA 200 dans le sens de la tendance", "ok_vol": "Volume supérieur à la moyenne",
    "none": "aucune",
    "futures": "Futures", "spot": "Spot", "buy": "ACHAT (spot)", "exit": "SORTIE / VENTE",
    "exit_note": "La tendance est repartie à la baisse. N'entrez pas en long ; revoyez vos positions ouvertes.",
    "disc": "⚠️ Pas un conseil en investissement. Risque élevé. DYOR.",
    "price_fmt": ("💱 <b>{s}</b>\n💰 Prix : <code>{p}</code>\n📈 24h : <b>{ch}</b>\n"
                  "⬆️ Plus haut : <code>{hi}</code>\n⬇️ Plus bas : <code>{lo}</code>\n📊 Volume : {vol} USDT"),
    "price_usage": "Usage : /price BTC",
    "top_head": "🔥 <b>Plus gros mouvements · 24h · Futures</b>", "top_up": "🟢 Hausses", "top_down": "🔴 Baisses",
    "top_hint": "Astuce : /price SOL affiche un seul coin.",
    "calc_usage": ("🧮 <b>Calculateur de risque</b>\nUsage : <code>/calc solde risque% entrée stop</code>\n"
                   "Exemple : <code>/calc 1000 1 65000 64000</code>"),
    "calc_result": ("🧮 <b>Calculateur de position</b>\n💵 Risque : <code>{risk}</code> USDT ({pct}%)\n"
                    "📏 Distance du stop : <b>{dist}%</b>\n📦 Taille de position : <code>{size}</code> USDT\n"
                    "🔢 Quantité : <code>{qty}</code>\n⚙️ Levier minimum requis : <b>{lev}x</b>\n\n"
                    "⚠️ Outil pédagogique, pas une recommandation."),
    "calc_bad": "❌ Nombres invalides. Exemple : /calc 1000 1 65000 64000",
    "test_sent": "✅ Ceci est un signal de TEST (données d'exemple) :",
    "hist_head": "🕘 <b>Derniers signaux pour vos coins</b>",
    "hist_empty": "Aucun signal pour l'instant. Ils arrivent quand la tendance s'inverse.",
    "data_head": "📊 <b>Marché en direct</b>",
    "err": "⚠️ Une erreur est survenue. Veuillez réessayer.", "wait": "⏳ Veuillez patienter un instant.",
    "cmds": ("📋 Menu|🪙 Mes coins|⏱ Unités de temps|💱 Prix en direct|🔥 Plus gros mouvements|"
             "🧮 Calculateur de risque|🕘 Historique des signaux|🌐 Langue|💝 Faire un don|⚖️ Conditions|"
             "❓ Aide|🗑 Supprimer mes données"),
    "desc": ("Елена Хьюз transforme les données de marché en direct en signaux clairs, notés 0–10, pour "
             "Futures et Spot : entrée, stop et 3 niveaux de take-profit, appuyés par Supertrend, EMA, RSI, "
             "MACD, ADX et volume, avec graphiques et explications simples. Favoris, indications de levier, "
             "alertes en 8 langues et statistiques réelles. Information uniquement — pas un conseil en investissement."),
    "short_desc": "Елена Хьюз · Signaux crypto professionnels, notés 0–10, avec graphiques · 8 langues",
}

# ============================================================ العربية
T["ar"] = {
    "name": "🇸🇦 العربية",
    "terms": (
        "⚖️ <b>شروط الاستخدام وإشعار المخاطر</b>\n\n"
        "• يرسل هذا البوت معلومات آلية مبنية على التحليل الفني. وهو <b>ليس</b> استشارة استثمارية "
        "ولا توصية بالتداول ولا وعدًا بأي عوائد.\n"
        "• تداول العملات الرقمية، خاصة بالرافعة المالية، قد يؤدي إلى خسارة رأس مالك بالكامل.\n"
        "• قد تتأخر الإشارات أو تكون خاطئة. جميع القرارات ونتائجها مسؤوليتك وحدك.\n"
        "• تقرّ بأن عمرك 18 عامًا على الأقل وبأنك تلتزم بقوانين بلدك.\n"
        "• البيانات المخزّنة: معرّف الدردشة في تيليجرام واللغة والإعدادات. لا تتم مشاركتها مع أطراف ثالثة؛ "
        "ويمكنك حذفها بالأمر /delete.\n"
        "• التبرعات اختيارية ولا تضمن أي خدمة أو عائد ولا يمكن استردادها."
    ),
    "accept": "✅ أوافق", "decline": "❌ أرفض",
    "declined": "لقد رفضت الشروط. لن تُرسل أي إشارات. للبدء من جديد استخدم /start",
    "menu": ("📋 <b>لوحة التحكم</b>  {status}\n\n🪙 العملات: <b>{n}</b>\n⏱ الأطر الزمنية: <b>{tfs}</b>\n"
             "📈 السوق: <b>{market}</b>\n⚙️ أقصى رافعة: <b>{lev}x</b>\n🔔 الإشارات القوية فقط: <b>{strong}</b>\n"
             "🌙 ساعات الهدوء: <b>{quiet}</b>"),
    "st_on": "🟢 نشط", "st_off": "⏸ متوقف مؤقتًا", "on": "تشغيل", "off": "إيقاف",
    "b_coins": "🪙 العملات / المفضلة", "b_tfs": "⏱ الأطر الزمنية", "b_market": "📈 نوع السوق",
    "b_lev": "⚙️ الرافعة", "b_strong": "🔔 القوية فقط: {v}", "b_quiet": "🌙 ساعات الهدوء",
    "b_data": "📊 السوق المباشر", "b_hist": "🕘 السجل", "b_calc": "🧮 الحاسبة",
    "b_lang": "🌐 اللغة", "b_help": "❓ مساعدة", "b_terms": "⚖️ الشروط", "b_donate": "💝 تبرع",
    "b_delete": "🗑 حذف بياناتي", "b_back": "⬅️ رجوع", "b_pause": "⏸ إيقاف التنبيهات مؤقتًا",
    "b_resume": "▶️ استئناف التنبيهات",
    "coins_head": ("🪙 <b>عملاتي</b> ({n}): {lst}\n\nاضغط على عملة لإضافتها/إزالتها. "
                   "غير موجودة؟ أرسل: <code>/add SOL</code>"),
    "tfs_head": "⏱ <b>الأطر الزمنية</b>\nاختر واحدًا أو أكثر. الأطر القصيرة تعطي إشارات خاطئة أكثر.",
    "market_head": "📈 <b>نوع الإشارات</b>",
    "mkt_futures": "العقود الآجلة (Long/Short)", "mkt_spot": "السوق الفوري", "mkt_both": "آجلة + فوري",
    "lev_head": "⚙️ <b>أقصى رافعة</b>\nلن يقترح البوت رافعة أعلى من حدّك.",
    "quiet_head": ("🌙 <b>ساعات الهدوء</b>\nخلال هذه الساعات تصل الإشارات بدون صوت.\n"
                   "منطقتك الزمنية: <b>UTC{tz}</b> — اضبطها بـ ➖ ➕"),
    "quiet_off": "إيقاف (دائمًا بصوت)",
    "added": "✅ تمت الإضافة: {s}", "removed": "🗑 تمت الإزالة: {s}", "notfound": "❌ الزوج غير موجود: {s}",
    "usage_add": "الاستخدام: /add SOL  أو  /remove SOL", "limit": "حد العملات: {n}",
    "donate": ("💝 <b>ادعم المشروع</b>\nالتبرع اختياري ولا يضمن عوائد أو خدمات إضافية. شكرًا لك!"),
    "b_donate_open": "💝 فتح صفحة التبرع",
    "help": (
        "❓ <b>كيف يعمل</b>\n\n"
        "1) اختر العملات والأطر الزمنية.\n"
        "2) عند إغلاق كل شمعة يحسب البوت Supertrend (ATR 10 × 3) وMavilimW وEMA 200.\n"
        "3) عند انعكاس الاتجاه تصلك إشارة: الدخول، الوقف (خط Supertrend)، الأهداف TP1–TP3 (1R/2R/3R) "
        "ورافعة إرشادية.\n"
        "4) ⭐ القوة = التأكيدات: MavilimW وEMA 200 والحجم.\n\n"
        "⚠️ ليست نصيحة استثمارية. استخدم دائمًا وقف الخسارة ولا تخاطر بأكثر من 1–2% في الصفقة."
    ),
    "delete_ask": "هل تريد حذف جميع بياناتك وإيقاف الإشعارات؟",
    "delete_yes": "✅ نعم، احذف", "delete_no": "↩️ إلغاء",
    "deleted": "🗑 تم حذف بياناتك. للإعداد من جديد استخدم /start",
    "need_terms": "يرجى قبول الشروط أولًا: /start",
    "sig_entry": "الدخول", "sig_stop": "الوقف", "sig_lev": "الرافعة الإرشادية", "sig_strength": "القوة",
    "sig_why": "التأكيدات", "ok_mavw": "MavilimW مع الاتجاه", "ok_ema": "السعر مقابل EMA 200 مع الاتجاه",
    "ok_vol": "حجم أعلى من المتوسط", "none": "لا يوجد",
    "futures": "آجلة", "spot": "فوري", "buy": "شراء (فوري)", "exit": "خروج / بيع",
    "exit_note": "انعكس الاتجاه للأسفل. لا تدخل شراءً؛ راجع مراكزك المفتوحة.",
    "disc": "⚠️ ليست نصيحة استثمارية. مخاطرة عالية. قم ببحثك الخاص.",
    "price_fmt": ("💱 <b>{s}</b>\n💰 السعر: <code>{p}</code>\n📈 24 ساعة: <b>{ch}</b>\n"
                  "⬆️ الأعلى: <code>{hi}</code>\n⬇️ الأدنى: <code>{lo}</code>\n📊 الحجم: {vol} USDT"),
    "price_usage": "الاستخدام: /price BTC",
    "top_head": "🔥 <b>الأكثر تحركًا · 24 ساعة · آجلة</b>", "top_up": "🟢 الصاعدة", "top_down": "🔴 الهابطة",
    "top_hint": "نصيحة: /price SOL يعرض عملة واحدة.",
    "calc_usage": ("🧮 <b>حاسبة المخاطر</b>\nالاستخدام: <code>/calc الرصيد المخاطرة% الدخول الوقف</code>\n"
                   "مثال: <code>/calc 1000 1 65000 64000</code>"),
    "calc_result": ("🧮 <b>حاسبة المركز</b>\n💵 المخاطرة: <code>{risk}</code> USDT ({pct}%)\n"
                    "📏 المسافة إلى الوقف: <b>{dist}%</b>\n📦 حجم المركز: <code>{size}</code> USDT\n"
                    "🔢 الكمية: <code>{qty}</code>\n⚙️ أدنى رافعة مطلوبة: <b>{lev}x</b>\n\n"
                    "⚠️ أداة تعليمية وليست توصية."),
    "calc_bad": "❌ أرقام غير صالحة. مثال: /calc 1000 1 65000 64000",
    "test_sent": "✅ هذه إشارة تجريبية (بيانات نموذجية):",
    "hist_head": "🕘 <b>آخر الإشارات لعملاتك</b>",
    "hist_empty": "لا توجد إشارات بعد. تصل عند انعكاس الاتجاه.",
    "data_head": "📊 <b>السوق المباشر</b>",
    "err": "⚠️ حدث خطأ ما. حاول مرة أخرى.", "wait": "⏳ يرجى الانتظار قليلًا.",
    "cmds": ("📋 القائمة|🪙 عملاتي|⏱ الأطر الزمنية|💱 السعر المباشر|🔥 الأكثر تحركًا|🧮 حاسبة المخاطر|"
             "🕘 سجل الإشارات|🌐 اللغة|💝 تبرع|⚖️ الشروط|❓ مساعدة|🗑 حذف بياناتي"),
    "desc": ("يحوّل Елена Хьюз بيانات السوق الحية إلى إشارات واضحة بدرجة قوة من 0 إلى 10 للعقود الآجلة "
             "والسوق الفوري: دخول ووقف خسارة و3 مستويات لجني الأرباح، مدعومة بتحليل Supertrend وEMA وRSI "
             "وMACD وADX والحجم، مع رسوم بيانية وشروحات مبسطة. مفضلة، إرشادات الرافعة، تنبيهات بـ8 لغات "
             "وإحصاءات أداء حقيقية. لأغراض إعلامية فقط — ليست نصيحة استثمارية."),
    "short_desc": "Елена Хьюз · إشارات تداول احترافية بدرجة 0–10 ورسوم بيانية · 8 لغات",
}

from texts_ext import EXT  # noqa: E402  (v3 metinleri; help/cmds/desc eskilerin üzerine yazılır)
from texts2 import T2  # noqa: E402  (takip/istatistik; EXT ile çakışanlarda T2 kazanır)
from texts3 import T3  # noqa: E402  (yeni sinyal şeması uyarıları; en son kazanır)
from texts4 import T4  # noqa: E402  (anlatım, korelasyon, görünüm, /explain)
from texts5 import T5  # noqa: E402  (kabul sonrası profesyonel hoş geldin ekranı)
from texts6 import T6  # noqa: E402  (glossary, matrix, mtf, ban)

for _lang in list(T):
    T[_lang].update(EXT.get(_lang, {}))
    T[_lang].update(T2.get(_lang, {}))
    T[_lang].update(T3.get(_lang, {}))
    T[_lang].update(T4.get(_lang, {}))
    T[_lang].update(T5.get(_lang, {}))
    T[_lang].update(T6.get(_lang, {}))
    if T[_lang].get("cmds_add"):  # yeni komutların açıklamaları listeye eklenir
        T[_lang]["cmds"] = T[_lang]["cmds"] + "|" + T[_lang]["cmds_add"]
    if T[_lang].get("cmds_add2"):  # v8 komutları
        T[_lang]["cmds"] = T[_lang]["cmds"] + "|" + T[_lang]["cmds_add2"]
    if T[_lang].get("terms_add"):  # takip/veri saklama maddesi şartlara eklenir
        T[_lang]["terms"] = T[_lang]["terms"] + "\n" + T[_lang]["terms_add"]

# Eksik anahtar → İngilizce'ye düş (bot asla KeyError ile çökmez)
_EN = T["en"]
for _lang in list(T):
    T[_lang] = {**_EN, **T[_lang]}


def tx(lang):
    return T.get(lang, _EN)


def fmt_price(p):
    if p >= 1000:
        return f"{p:.2f}"
    if p >= 1:
        return f"{p:.4f}"
    if p >= 0.01:
        return f"{p:.5f}"
    return f"{p:.8f}"


def local_time(ts, tz):
    """Unix saniyesini kullanıcının UTC farkına göre 'gg.aa SS:DD' yapar."""
    return datetime.fromtimestamp(ts, timezone(timedelta(hours=tz))).strftime("%d.%m %H:%M")
