"""v3 ek metinleri (8 dil): istatistik, açık sinyaller, fiyat alarmı, takip bildirimleri, yeni komutlar."""

T2 = {}

T2["en"] = {
    "terms_add": ("• Stored data also includes your price alerts and which signals were sent to you "
                  "(needed for result tracking). Result statistics are simulations, not proof of future performance."),
    "b_stats": "📈 Statistics", "b_open": "⏳ Open signals", "b_alerts": "🔔 Price alerts",
    "b_track": "🎯 Result alerts: {v}",
    "p7": "7d", "p30": "30d", "pall": "All", "sc_all": "🌍 All signals", "sc_mine": "👤 Mine",
    "st_title": "📈 <b>Signal statistics</b> · {period} · {scope}",
    "st_signals": "📨 Signals: <b>{n}</b> · ✅ closed <b>{c}</b> · ⏳ open <b>{o}</b> · ⌛ no result <b>{x}</b>",
    "st_rates": "🎯 TP1 <b>{a}%</b> · TP2 <b>{b}%</b> · TP3 <b>{c}%</b> · ❌ SL <b>{d}%</b>",
    "st_win": "🏆 Win rate (≥TP1): <b>{w}%</b> · n={n}",
    "st_net": "📐 Net result: <b>{net}R</b> · avg <b>{avg}R</b> per signal",
    "st_side": "↕️ By side", "st_tf": "⏱ By timeframe", "st_grade": "⭐ By strength",
    "st_none": "No resolved signals in this period yet. Results appear once a signal reaches a target or its stop.",
    "st_small": "⚠️ Small sample (n<30): don't draw conclusions yet.",
    "st_model": ("ℹ️ Simulation: the position is split in thirds closing at TP1/TP2/TP3; the stop moves to entry "
                 "after TP1; fees and slippage are ignored. Past results do not guarantee future results. "
                 "Not investment advice."),
    "open_head": "⏳ <b>Open signals</b> (yours)", "open_empty": "No open signals right now.", "open_now": "now",
    "al_usage": "🔔 Usage: <code>/alert BTC 70000</code>",
    "al_set": "✅ Alert set: <code>{s}</code> {d} <code>{p}</code>",
    "al_limit": "Maximum {n} alerts. Delete one with /alerts.", "al_bad": "❌ Invalid price.",
    "al_noprice": "⚠️ Couldn't fetch the current price. Try again.", "al_head": "🔔 <b>Your price alerts</b>",
    "al_empty": "No alerts. Set one: /alert BTC 70000",
    "al_hit": "🔔 <b>Price alert</b>\n<code>{s}</code> reached <code>{p}</code>\nNow: <code>{now}</code>",
    "al_same": "❌ The price is already at that level. Choose a different one.",
    "tr_tp": "🎯 <b>TP{n} reached</b> ✅", "tr_tp3": "🏆 <b>TP3 reached — signal complete</b>",
    "tr_sl": "❌ <b>Stop hit</b>", "tr_be": "🛡 <b>Stopped at entry</b> — signal closed",
    "tr_exp": "⌛ <b>Signal expired</b> (time limit)", "tr_move": "🛡 Move your stop to entry: <code>{p}</code>",
    "tr_result": "📊 Result (model): <b>{r}R</b>", "tr_reached": "Highest target: {t}",
    "tr_none": "no target reached",
    "cmds2": "📈 Signal statistics|⏳ Open signals|🔔 Set price alert|🔔 My price alerts",
    "help2": ("📈 <b>Tracking</b>\nEvery signal is followed automatically on 1-minute candles until TP3, its stop "
              "or its time limit. You get a message at each TP and at the stop. /stats shows hit rates and the "
              "net result in R (model: thirds at TP1/TP2/TP3, stop to entry after TP1, no fees).\n"
              "🔔 <b>Alerts</b>: /alert BTC 70000"),
    "desc": ("Crypto signals for Futures & Spot: Supertrend, MavilimW, EMA, RSI, MACD, ADX, volume and key levels. "
             "Automatic TP/SL tracking with statistics, price alerts, favorites and 8 languages. Not investment advice."),
    "short_desc": "Crypto signals · TP/SL tracking · 8 languages",
}

T2["ru"] = {
    "terms_add": ("• Мы также храним ваши ценовые алерты и список отправленных вам сигналов "
                  "(нужен для отслеживания итогов). Статистика — это симуляция, а не доказательство будущих результатов."),
    "b_stats": "📈 Статистика", "b_open": "⏳ Открытые сигналы", "b_alerts": "🔔 Ценовые алерты",
    "b_track": "🎯 Итоги сигналов: {v}",
    "p7": "7д", "p30": "30д", "pall": "Все", "sc_all": "🌍 Все сигналы", "sc_mine": "👤 Мои",
    "st_title": "📈 <b>Статистика сигналов</b> · {period} · {scope}",
    "st_signals": "📨 Сигналов: <b>{n}</b> · ✅ закрыто <b>{c}</b> · ⏳ открыто <b>{o}</b> · ⌛ без итога <b>{x}</b>",
    "st_rates": "🎯 TP1 <b>{a}%</b> · TP2 <b>{b}%</b> · TP3 <b>{c}%</b> · ❌ SL <b>{d}%</b>",
    "st_win": "🏆 Доля успешных (≥TP1): <b>{w}%</b> · n={n}",
    "st_net": "📐 Итог: <b>{net}R</b> · в среднем <b>{avg}R</b> на сигнал",
    "st_side": "↕️ По направлению", "st_tf": "⏱ По таймфреймам", "st_grade": "⭐ По силе",
    "st_none": "За этот период ещё нет завершённых сигналов. Итоги появятся, когда сигнал достигнет цели или стопа.",
    "st_small": "⚠️ Малая выборка (n<30): рано делать выводы.",
    "st_model": ("ℹ️ Симуляция: позиция делится на трети и закрывается на TP1/TP2/TP3; после TP1 стоп переносится "
                 "на вход; комиссии и проскальзывание не учитываются. Прошлые результаты не гарантируют будущих. "
                 "Не инвестсовет."),
    "open_head": "⏳ <b>Открытые сигналы</b> (ваши)", "open_empty": "Сейчас нет открытых сигналов.",
    "open_now": "сейчас",
    "al_usage": "🔔 Использование: <code>/alert BTC 70000</code>",
    "al_set": "✅ Алерт создан: <code>{s}</code> {d} <code>{p}</code>",
    "al_limit": "Максимум {n} алертов. Удалите один через /alerts.", "al_bad": "❌ Неверная цена.",
    "al_noprice": "⚠️ Не удалось получить текущую цену. Попробуйте ещё раз.",
    "al_head": "🔔 <b>Ваши ценовые алерты</b>", "al_empty": "Алертов нет. Создайте: /alert BTC 70000",
    "al_hit": "🔔 <b>Ценовой алерт</b>\n<code>{s}</code> достиг <code>{p}</code>\nСейчас: <code>{now}</code>",
    "al_same": "❌ Цена уже на этом уровне. Выберите другой.",
    "tr_tp": "🎯 <b>TP{n} достигнут</b> ✅", "tr_tp3": "🏆 <b>TP3 достигнут — сигнал завершён</b>",
    "tr_sl": "❌ <b>Сработал стоп</b>", "tr_be": "🛡 <b>Стоп сработал на входе</b> — сигнал закрыт",
    "tr_exp": "⌛ <b>Сигнал устарел</b> (лимит времени)",
    "tr_move": "🛡 Перенесите стоп на вход: <code>{p}</code>",
    "tr_result": "📊 Итог (модель): <b>{r}R</b>", "tr_reached": "Максимальная цель: {t}",
    "tr_none": "цели не достигнуты",
    "cmds2": "📈 Статистика сигналов|⏳ Открытые сигналы|🔔 Ценовой алерт|🔔 Мои алерты",
    "help2": ("📈 <b>Отслеживание</b>\nКаждый сигнал автоматически отслеживается по 1-минутным свечам до TP3, "
              "стопа или истечения времени. Вы получаете сообщение на каждом TP и на стопе. /stats показывает "
              "долю достигнутых целей и итог в R (модель: трети на TP1/TP2/TP3, стоп на вход после TP1, без комиссий).\n"
              "🔔 <b>Алерты</b>: /alert BTC 70000"),
    "desc": ("Крипто-сигналы для фьючерсов и спота: Supertrend, MavilimW, EMA, RSI, MACD, ADX, объём и уровни. "
             "Автоотслеживание TP/SL со статистикой, ценовые алерты, избранное и 8 языков. Не инвестсовет."),
    "short_desc": "Крипто-сигналы · TP/SL-статистика · 8 языков",
}

T2["tr"] = {
    "terms_add": ("• Saklanan veriler ayrıca fiyat alarmlarını ve sana gönderilen sinyallerin listesini içerir "
                  "(sonuç takibi için gerekli). Sonuç istatistikleri simülasyondur, gelecekteki performansın kanıtı değildir."),
    "b_stats": "📈 İstatistik", "b_open": "⏳ Açık sinyaller", "b_alerts": "🔔 Fiyat alarmları",
    "b_track": "🎯 Sonuç bildirimleri: {v}",
    "p7": "7g", "p30": "30g", "pall": "Tümü", "sc_all": "🌍 Tüm sinyaller", "sc_mine": "👤 Benim",
    "st_title": "📈 <b>Sinyal istatistikleri</b> · {period} · {scope}",
    "st_signals": "📨 Sinyal: <b>{n}</b> · ✅ kapanan <b>{c}</b> · ⏳ açık <b>{o}</b> · ⌛ sonuçsuz <b>{x}</b>",
    "st_rates": "🎯 TP1 <b>%{a}</b> · TP2 <b>%{b}</b> · TP3 <b>%{c}</b> · ❌ SL <b>%{d}</b>",
    "st_win": "🏆 Başarı oranı (≥TP1): <b>%{w}</b> · n={n}",
    "st_net": "📐 Net sonuç: <b>{net}R</b> · sinyal başına ort. <b>{avg}R</b>",
    "st_side": "↕️ Yöne göre", "st_tf": "⏱ Zaman dilimine göre", "st_grade": "⭐ Güce göre",
    "st_none": "Bu dönemde henüz sonuçlanan sinyal yok. Sonuçlar, bir sinyal hedefe veya stopa ulaşınca görünür.",
    "st_small": "⚠️ Örneklem küçük (n<30): henüz sonuç çıkarma.",
    "st_model": ("ℹ️ Simülasyon: pozisyon üçe bölünür ve TP1/TP2/TP3'te kapanır; TP1 sonrası stop girişe çekilir; "
                 "komisyon ve kayma hesaba katılmaz. Geçmiş sonuçlar gelecek sonuçları garanti etmez. "
                 "Yatırım tavsiyesi değildir."),
    "open_head": "⏳ <b>Açık sinyaller</b> (senin)", "open_empty": "Şu an açık sinyal yok.", "open_now": "şimdi",
    "al_usage": "🔔 Kullanım: <code>/alert BTC 70000</code>",
    "al_set": "✅ Alarm kuruldu: <code>{s}</code> {d} <code>{p}</code>",
    "al_limit": "En fazla {n} alarm. /alerts ile birini sil.", "al_bad": "❌ Geçersiz fiyat.",
    "al_noprice": "⚠️ Güncel fiyat alınamadı. Tekrar dene.", "al_head": "🔔 <b>Fiyat alarmların</b>",
    "al_empty": "Alarm yok. Kur: /alert BTC 70000",
    "al_hit": "🔔 <b>Fiyat alarmı</b>\n<code>{s}</code> <code>{p}</code> seviyesine ulaştı\nŞimdi: <code>{now}</code>",
    "al_same": "❌ Fiyat zaten bu seviyede. Farklı bir seviye seç.",
    "tr_tp": "🎯 <b>TP{n} ulaşıldı</b> ✅", "tr_tp3": "🏆 <b>TP3 ulaşıldı — sinyal tamamlandı</b>",
    "tr_sl": "❌ <b>Stop çalıştı</b>", "tr_be": "🛡 <b>Stop girişte çalıştı</b> — sinyal kapandı",
    "tr_exp": "⌛ <b>Sinyal süresi doldu</b>", "tr_move": "🛡 Stop'unu girişe çek: <code>{p}</code>",
    "tr_result": "📊 Sonuç (model): <b>{r}R</b>", "tr_reached": "Ulaşılan en yüksek hedef: {t}",
    "tr_none": "hedefe ulaşılmadı",
    "cmds2": "📈 Sinyal istatistikleri|⏳ Açık sinyaller|🔔 Fiyat alarmı kur|🔔 Alarmlarım",
    "help2": ("📈 <b>Takip</b>\nHer sinyal, TP3'e, stopa ya da süre sınırına kadar 1 dakikalık mumlarla otomatik "
              "izlenir. Her TP'de ve stopta mesaj alırsın. /stats hedef isabet oranlarını ve R cinsinden net sonucu "
              "gösterir (model: TP1/TP2/TP3'te üçe bölünmüş kapanış, TP1 sonrası stop girişe, komisyon yok).\n"
              "🔔 <b>Alarm</b>: /alert BTC 70000"),
    "desc": ("Futures ve Spot için kripto sinyalleri: Supertrend, MavilimW, EMA, RSI, MACD, ADX, hacim ve önemli "
             "seviyeler. İstatistikli otomatik TP/SL takibi, fiyat alarmları, favoriler ve 8 dil. Yatırım tavsiyesi değildir."),
    "short_desc": "Kripto sinyalleri · TP/SL takibi · 8 dil",
}

T2["uk"] = {
    "terms_add": ("• Ми також зберігаємо ваші цінові алерти та список надісланих вам сигналів "
                  "(потрібен для відстеження підсумків). Статистика — це симуляція, а не доказ майбутніх результатів."),
    "b_stats": "📈 Статистика", "b_open": "⏳ Відкриті сигнали", "b_alerts": "🔔 Цінові алерти",
    "b_track": "🎯 Підсумки сигналів: {v}",
    "p7": "7д", "p30": "30д", "pall": "Усі", "sc_all": "🌍 Усі сигнали", "sc_mine": "👤 Мої",
    "st_title": "📈 <b>Статистика сигналів</b> · {period} · {scope}",
    "st_signals": "📨 Сигналів: <b>{n}</b> · ✅ закрито <b>{c}</b> · ⏳ відкрито <b>{o}</b> · ⌛ без підсумку <b>{x}</b>",
    "st_rates": "🎯 TP1 <b>{a}%</b> · TP2 <b>{b}%</b> · TP3 <b>{c}%</b> · ❌ SL <b>{d}%</b>",
    "st_win": "🏆 Частка успішних (≥TP1): <b>{w}%</b> · n={n}",
    "st_net": "📐 Підсумок: <b>{net}R</b> · у середньому <b>{avg}R</b> на сигнал",
    "st_side": "↕️ За напрямком", "st_tf": "⏱ За таймфреймами", "st_grade": "⭐ За силою",
    "st_none": "За цей період ще немає завершених сигналів. Підсумки з'являться, коли сигнал досягне цілі або стопу.",
    "st_small": "⚠️ Мала вибірка (n<30): зарано робити висновки.",
    "st_model": ("ℹ️ Симуляція: позиція ділиться на третини й закривається на TP1/TP2/TP3; після TP1 стоп "
                 "переноситься на вхід; комісії та прослизання не враховуються. Минулі результати не гарантують "
                 "майбутніх. Не інвестиційна порада."),
    "open_head": "⏳ <b>Відкриті сигнали</b> (ваші)", "open_empty": "Зараз немає відкритих сигналів.",
    "open_now": "зараз",
    "al_usage": "🔔 Використання: <code>/alert BTC 70000</code>",
    "al_set": "✅ Алерт створено: <code>{s}</code> {d} <code>{p}</code>",
    "al_limit": "Максимум {n} алертів. Видаліть один через /alerts.", "al_bad": "❌ Невірна ціна.",
    "al_noprice": "⚠️ Не вдалося отримати поточну ціну. Спробуйте ще раз.",
    "al_head": "🔔 <b>Ваші цінові алерти</b>", "al_empty": "Алертів немає. Створіть: /alert BTC 70000",
    "al_hit": "🔔 <b>Ціновий алерт</b>\n<code>{s}</code> досяг <code>{p}</code>\nЗараз: <code>{now}</code>",
    "al_same": "❌ Ціна вже на цьому рівні. Оберіть інший.",
    "tr_tp": "🎯 <b>TP{n} досягнуто</b> ✅", "tr_tp3": "🏆 <b>TP3 досягнуто — сигнал завершено</b>",
    "tr_sl": "❌ <b>Спрацював стоп</b>", "tr_be": "🛡 <b>Стоп спрацював на вході</b> — сигнал закрито",
    "tr_exp": "⌛ <b>Сигнал застарів</b> (ліміт часу)",
    "tr_move": "🛡 Перенесіть стоп на вхід: <code>{p}</code>",
    "tr_result": "📊 Підсумок (модель): <b>{r}R</b>", "tr_reached": "Максимальна ціль: {t}",
    "tr_none": "цілей не досягнуто",
    "cmds2": "📈 Статистика сигналів|⏳ Відкриті сигнали|🔔 Ціновий алерт|🔔 Мої алерти",
    "help2": ("📈 <b>Відстеження</b>\nКожен сигнал автоматично відстежується за 1-хвилинними свічками до TP3, "
              "стопу або завершення часу. Ви отримуєте повідомлення на кожному TP і на стопі. /stats показує "
              "частку досягнутих цілей та підсумок у R (модель: третини на TP1/TP2/TP3, стоп на вхід після TP1, без комісій).\n"
              "🔔 <b>Алерти</b>: /alert BTC 70000"),
    "desc": ("Крипто-сигнали для ф'ючерсів і споту: Supertrend, MavilimW, EMA, RSI, MACD, ADX, обсяг і рівні. "
             "Автовідстеження TP/SL зі статистикою, цінові алерти, обране та 8 мов. Не інвестиційна порада."),
    "short_desc": "Крипто-сигнали · TP/SL-статистика · 8 мов",
}

T2["de"] = {
    "terms_add": ("• Gespeichert werden außerdem Ihre Preisalarme und welche Signale an Sie gesendet wurden "
                  "(für die Ergebnisverfolgung). Ergebnisstatistiken sind Simulationen, kein Beleg für künftige Ergebnisse."),
    "b_stats": "📈 Statistik", "b_open": "⏳ Offene Signale", "b_alerts": "🔔 Preisalarme",
    "b_track": "🎯 Ergebnis-Meldungen: {v}",
    "p7": "7T", "p30": "30T", "pall": "Alle", "sc_all": "🌍 Alle Signale", "sc_mine": "👤 Meine",
    "st_title": "📈 <b>Signalstatistik</b> · {period} · {scope}",
    "st_signals": "📨 Signale: <b>{n}</b> · ✅ abgeschlossen <b>{c}</b> · ⏳ offen <b>{o}</b> · ⌛ ohne Ergebnis <b>{x}</b>",
    "st_rates": "🎯 TP1 <b>{a} %</b> · TP2 <b>{b} %</b> · TP3 <b>{c} %</b> · ❌ SL <b>{d} %</b>",
    "st_win": "🏆 Trefferquote (≥TP1): <b>{w} %</b> · n={n}",
    "st_net": "📐 Nettoergebnis: <b>{net}R</b> · Ø <b>{avg}R</b> pro Signal",
    "st_side": "↕️ Nach Richtung", "st_tf": "⏱ Nach Zeitrahmen", "st_grade": "⭐ Nach Stärke",
    "st_none": "In diesem Zeitraum gibt es noch keine abgeschlossenen Signale. Ergebnisse erscheinen, sobald ein Signal ein Ziel oder den Stop erreicht.",
    "st_small": "⚠️ Kleine Stichprobe (n<30): noch keine Schlüsse ziehen.",
    "st_model": ("ℹ️ Simulation: Die Position wird in Drittel geteilt, die bei TP1/TP2/TP3 schließen; nach TP1 wandert "
                 "der Stop auf den Einstieg; Gebühren und Slippage bleiben unberücksichtigt. Vergangene Ergebnisse "
                 "garantieren keine künftigen. Keine Anlageberatung."),
    "open_head": "⏳ <b>Offene Signale</b> (Ihre)", "open_empty": "Derzeit keine offenen Signale.",
    "open_now": "jetzt",
    "al_usage": "🔔 Nutzung: <code>/alert BTC 70000</code>",
    "al_set": "✅ Alarm gesetzt: <code>{s}</code> {d} <code>{p}</code>",
    "al_limit": "Maximal {n} Alarme. Mit /alerts einen löschen.", "al_bad": "❌ Ungültiger Preis.",
    "al_noprice": "⚠️ Aktueller Preis nicht abrufbar. Bitte erneut versuchen.",
    "al_head": "🔔 <b>Ihre Preisalarme</b>", "al_empty": "Keine Alarme. Setzen: /alert BTC 70000",
    "al_hit": "🔔 <b>Preisalarm</b>\n<code>{s}</code> hat <code>{p}</code> erreicht\nJetzt: <code>{now}</code>",
    "al_same": "❌ Der Preis liegt bereits auf diesem Niveau. Wählen Sie ein anderes.",
    "tr_tp": "🎯 <b>TP{n} erreicht</b> ✅", "tr_tp3": "🏆 <b>TP3 erreicht — Signal abgeschlossen</b>",
    "tr_sl": "❌ <b>Stop ausgelöst</b>", "tr_be": "🛡 <b>Am Einstieg gestoppt</b> — Signal geschlossen",
    "tr_exp": "⌛ <b>Signal abgelaufen</b> (Zeitlimit)",
    "tr_move": "🛡 Stop auf den Einstieg setzen: <code>{p}</code>",
    "tr_result": "📊 Ergebnis (Modell): <b>{r}R</b>", "tr_reached": "Höchstes Ziel: {t}",
    "tr_none": "kein Ziel erreicht",
    "cmds2": "📈 Signalstatistik|⏳ Offene Signale|🔔 Preisalarm setzen|🔔 Meine Preisalarme",
    "help2": ("📈 <b>Verfolgung</b>\nJedes Signal wird automatisch auf 1-Minuten-Kerzen verfolgt – bis TP3, Stop "
              "oder Zeitlimit. Bei jedem TP und beim Stop erhalten Sie eine Nachricht. /stats zeigt Trefferquoten "
              "und das Nettoergebnis in R (Modell: Drittel bei TP1/TP2/TP3, Stop nach TP1 auf Einstieg, ohne Gebühren).\n"
              "🔔 <b>Alarme</b>: /alert BTC 70000"),
    "desc": ("Krypto-Signale für Futures & Spot: Supertrend, MavilimW, EMA, RSI, MACD, ADX, Volumen und wichtige "
             "Marken. Automatische TP/SL-Verfolgung mit Statistik, Preisalarme, Favoriten und 8 Sprachen. Keine Anlageberatung."),
    "short_desc": "Krypto-Signale · TP/SL-Tracking · 8 Sprachen",
}

T2["es"] = {
    "terms_add": ("• También se almacenan sus alertas de precio y qué señales se le enviaron (necesario para el "
                  "seguimiento de resultados). Las estadísticas son simulaciones, no prueba de resultados futuros."),
    "b_stats": "📈 Estadísticas", "b_open": "⏳ Señales abiertas", "b_alerts": "🔔 Alertas de precio",
    "b_track": "🎯 Avisos de resultado: {v}",
    "p7": "7d", "p30": "30d", "pall": "Todo", "sc_all": "🌍 Todas las señales", "sc_mine": "👤 Mías",
    "st_title": "📈 <b>Estadísticas de señales</b> · {period} · {scope}",
    "st_signals": "📨 Señales: <b>{n}</b> · ✅ cerradas <b>{c}</b> · ⏳ abiertas <b>{o}</b> · ⌛ sin resultado <b>{x}</b>",
    "st_rates": "🎯 TP1 <b>{a} %</b> · TP2 <b>{b} %</b> · TP3 <b>{c} %</b> · ❌ SL <b>{d} %</b>",
    "st_win": "🏆 Tasa de acierto (≥TP1): <b>{w} %</b> · n={n}",
    "st_net": "📐 Resultado neto: <b>{net}R</b> · media <b>{avg}R</b> por señal",
    "st_side": "↕️ Por dirección", "st_tf": "⏱ Por marco temporal", "st_grade": "⭐ Por fuerza",
    "st_none": "Aún no hay señales resueltas en este periodo. Los resultados aparecen cuando una señal alcanza un objetivo o su stop.",
    "st_small": "⚠️ Muestra pequeña (n<30): aún no saque conclusiones.",
    "st_model": ("ℹ️ Simulación: la posición se divide en tercios que cierran en TP1/TP2/TP3; tras TP1 el stop pasa "
                 "a la entrada; no se consideran comisiones ni deslizamiento. Los resultados pasados no garantizan "
                 "los futuros. No es asesoramiento de inversión."),
    "open_head": "⏳ <b>Señales abiertas</b> (suyas)", "open_empty": "No hay señales abiertas ahora.",
    "open_now": "ahora",
    "al_usage": "🔔 Uso: <code>/alert BTC 70000</code>",
    "al_set": "✅ Alerta creada: <code>{s}</code> {d} <code>{p}</code>",
    "al_limit": "Máximo {n} alertas. Elimine una con /alerts.", "al_bad": "❌ Precio no válido.",
    "al_noprice": "⚠️ No se pudo obtener el precio actual. Inténtelo de nuevo.",
    "al_head": "🔔 <b>Sus alertas de precio</b>", "al_empty": "Sin alertas. Cree una: /alert BTC 70000",
    "al_hit": "🔔 <b>Alerta de precio</b>\n<code>{s}</code> alcanzó <code>{p}</code>\nAhora: <code>{now}</code>",
    "al_same": "❌ El precio ya está en ese nivel. Elija otro.",
    "tr_tp": "🎯 <b>TP{n} alcanzado</b> ✅", "tr_tp3": "🏆 <b>TP3 alcanzado — señal completada</b>",
    "tr_sl": "❌ <b>Stop activado</b>", "tr_be": "🛡 <b>Stop en la entrada</b> — señal cerrada",
    "tr_exp": "⌛ <b>Señal caducada</b> (límite de tiempo)",
    "tr_move": "🛡 Mueva su stop a la entrada: <code>{p}</code>",
    "tr_result": "📊 Resultado (modelo): <b>{r}R</b>", "tr_reached": "Objetivo máximo: {t}",
    "tr_none": "ningún objetivo alcanzado",
    "cmds2": "📈 Estadísticas de señales|⏳ Señales abiertas|🔔 Crear alerta de precio|🔔 Mis alertas",
    "help2": ("📈 <b>Seguimiento</b>\nCada señal se sigue automáticamente con velas de 1 minuto hasta TP3, su stop "
              "o su límite de tiempo. Recibe un mensaje en cada TP y en el stop. /stats muestra las tasas de acierto "
              "y el resultado neto en R (modelo: tercios en TP1/TP2/TP3, stop a la entrada tras TP1, sin comisiones).\n"
              "🔔 <b>Alertas</b>: /alert BTC 70000"),
    "desc": ("Señales cripto para Futuros y Spot: Supertrend, MavilimW, EMA, RSI, MACD, ADX, volumen y niveles "
             "clave. Seguimiento automático de TP/SL con estadísticas, alertas de precio, favoritas y 8 idiomas. No es asesoramiento."),
    "short_desc": "Señales cripto · Seguimiento TP/SL · 8 idiomas",
}

T2["fr"] = {
    "terms_add": ("• Sont aussi conservés vos alertes de prix et la liste des signaux qui vous ont été envoyés "
                  "(nécessaire au suivi des résultats). Les statistiques sont des simulations, pas une preuve de performances futures."),
    "b_stats": "📈 Statistiques", "b_open": "⏳ Signaux ouverts", "b_alerts": "🔔 Alertes de prix",
    "b_track": "🎯 Alertes de résultat : {v}",
    "p7": "7j", "p30": "30j", "pall": "Tout", "sc_all": "🌍 Tous les signaux", "sc_mine": "👤 Les miens",
    "st_title": "📈 <b>Statistiques des signaux</b> · {period} · {scope}",
    "st_signals": "📨 Signaux : <b>{n}</b> · ✅ clos <b>{c}</b> · ⏳ ouverts <b>{o}</b> · ⌛ sans résultat <b>{x}</b>",
    "st_rates": "🎯 TP1 <b>{a} %</b> · TP2 <b>{b} %</b> · TP3 <b>{c} %</b> · ❌ SL <b>{d} %</b>",
    "st_win": "🏆 Taux de réussite (≥TP1) : <b>{w} %</b> · n={n}",
    "st_net": "📐 Résultat net : <b>{net}R</b> · moy. <b>{avg}R</b> par signal",
    "st_side": "↕️ Par direction", "st_tf": "⏱ Par unité de temps", "st_grade": "⭐ Par force",
    "st_none": "Aucun signal résolu sur cette période. Les résultats apparaissent quand un signal atteint un objectif ou son stop.",
    "st_small": "⚠️ Petit échantillon (n<30) : ne tirez pas encore de conclusions.",
    "st_model": ("ℹ️ Simulation : la position est divisée en tiers clôturés à TP1/TP2/TP3 ; après TP1 le stop passe "
                 "à l'entrée ; frais et glissement ignorés. Les résultats passés ne garantissent pas les résultats "
                 "futurs. Pas un conseil en investissement."),
    "open_head": "⏳ <b>Signaux ouverts</b> (les vôtres)", "open_empty": "Aucun signal ouvert pour le moment.",
    "open_now": "actuel",
    "al_usage": "🔔 Usage : <code>/alert BTC 70000</code>",
    "al_set": "✅ Alerte créée : <code>{s}</code> {d} <code>{p}</code>",
    "al_limit": "Maximum {n} alertes. Supprimez-en une avec /alerts.", "al_bad": "❌ Prix invalide.",
    "al_noprice": "⚠️ Impossible d'obtenir le prix actuel. Réessayez.",
    "al_head": "🔔 <b>Vos alertes de prix</b>", "al_empty": "Aucune alerte. Créez-en une : /alert BTC 70000",
    "al_hit": "🔔 <b>Alerte de prix</b>\n<code>{s}</code> a atteint <code>{p}</code>\nActuel : <code>{now}</code>",
    "al_same": "❌ Le prix est déjà à ce niveau. Choisissez-en un autre.",
    "tr_tp": "🎯 <b>TP{n} atteint</b> ✅", "tr_tp3": "🏆 <b>TP3 atteint — signal terminé</b>",
    "tr_sl": "❌ <b>Stop touché</b>", "tr_be": "🛡 <b>Stop touché à l'entrée</b> — signal clos",
    "tr_exp": "⌛ <b>Signal expiré</b> (limite de temps)",
    "tr_move": "🛡 Déplacez votre stop à l'entrée : <code>{p}</code>",
    "tr_result": "📊 Résultat (modèle) : <b>{r}R</b>", "tr_reached": "Objectif maximal : {t}",
    "tr_none": "aucun objectif atteint",
    "cmds2": "📈 Statistiques des signaux|⏳ Signaux ouverts|🔔 Créer une alerte de prix|🔔 Mes alertes",
    "help2": ("📈 <b>Suivi</b>\nChaque signal est suivi automatiquement sur des bougies d'1 minute jusqu'à TP3, "
              "son stop ou sa limite de temps. Vous recevez un message à chaque TP et au stop. /stats affiche les "
              "taux de réussite et le résultat net en R (modèle : tiers à TP1/TP2/TP3, stop à l'entrée après TP1, sans frais).\n"
              "🔔 <b>Alertes</b> : /alert BTC 70000"),
    "desc": ("Signaux crypto pour Futures et Spot : Supertrend, MavilimW, EMA, RSI, MACD, ADX, volume et niveaux "
             "clés. Suivi automatique TP/SL avec statistiques, alertes de prix, favoris et 8 langues. Pas un conseil en investissement."),
    "short_desc": "Signaux crypto · Suivi TP/SL · 8 langues",
}

T2["ar"] = {
    "terms_add": ("• تشمل البيانات المخزّنة أيضًا تنبيهات الأسعار وقائمة الإشارات المرسلة إليك "
                  "(لازمة لتتبع النتائج). إحصاءات النتائج محاكاة وليست دليلًا على الأداء المستقبلي."),
    "b_stats": "📈 الإحصاءات", "b_open": "⏳ الإشارات المفتوحة", "b_alerts": "🔔 تنبيهات الأسعار",
    "b_track": "🎯 إشعارات النتائج: {v}",
    "p7": "7 أيام", "p30": "30 يومًا", "pall": "الكل", "sc_all": "🌍 كل الإشارات", "sc_mine": "👤 إشاراتي",
    "st_title": "📈 <b>إحصاءات الإشارات</b> · {period} · {scope}",
    "st_signals": "📨 الإشارات: <b>{n}</b> · ✅ مغلقة <b>{c}</b> · ⏳ مفتوحة <b>{o}</b> · ⌛ بلا نتيجة <b>{x}</b>",
    "st_rates": "🎯 TP1 <b>{a}%</b> · TP2 <b>{b}%</b> · TP3 <b>{c}%</b> · ❌ SL <b>{d}%</b>",
    "st_win": "🏆 نسبة النجاح (≥TP1): <b>{w}%</b> · n={n}",
    "st_net": "📐 الصافي: <b>{net}R</b> · المتوسط <b>{avg}R</b> لكل إشارة",
    "st_side": "↕️ حسب الاتجاه", "st_tf": "⏱ حسب الإطار الزمني", "st_grade": "⭐ حسب القوة",
    "st_none": "لا توجد إشارات منتهية في هذه الفترة بعد. تظهر النتائج عندما تصل الإشارة إلى هدف أو وقفها.",
    "st_small": "⚠️ عينة صغيرة (n<30): لا تستخلص نتائج بعد.",
    "st_model": ("ℹ️ محاكاة: تُقسَّم الصفقة إلى ثلاثة أجزاء تُغلق عند TP1/TP2/TP3؛ وبعد TP1 يُنقل الوقف إلى الدخول؛ "
                 "ولا تُحتسب الرسوم ولا الانزلاق. النتائج السابقة لا تضمن النتائج المستقبلية. ليست نصيحة استثمارية."),
    "open_head": "⏳ <b>الإشارات المفتوحة</b> (الخاصة بك)", "open_empty": "لا توجد إشارات مفتوحة الآن.",
    "open_now": "الآن",
    "al_usage": "🔔 الاستخدام: <code>/alert BTC 70000</code>",
    "al_set": "✅ تم ضبط التنبيه: <code>{s}</code> {d} <code>{p}</code>",
    "al_limit": "الحد الأقصى {n} تنبيهات. احذف واحدًا عبر /alerts.", "al_bad": "❌ سعر غير صالح.",
    "al_noprice": "⚠️ تعذر جلب السعر الحالي. حاول مرة أخرى.",
    "al_head": "🔔 <b>تنبيهات الأسعار الخاصة بك</b>", "al_empty": "لا توجد تنبيهات. اضبط واحدًا: /alert BTC 70000",
    "al_hit": "🔔 <b>تنبيه سعر</b>\nوصل <code>{s}</code> إلى <code>{p}</code>\nالآن: <code>{now}</code>",
    "al_same": "❌ السعر عند هذا المستوى بالفعل. اختر مستوى آخر.",
    "tr_tp": "🎯 <b>تم الوصول إلى TP{n}</b> ✅", "tr_tp3": "🏆 <b>تم الوصول إلى TP3 — اكتملت الإشارة</b>",
    "tr_sl": "❌ <b>تم تفعيل الوقف</b>", "tr_be": "🛡 <b>تفعّل الوقف عند الدخول</b> — أُغلقت الإشارة",
    "tr_exp": "⌛ <b>انتهت صلاحية الإشارة</b> (حد زمني)",
    "tr_move": "🛡 انقل وقفك إلى الدخول: <code>{p}</code>",
    "tr_result": "📊 النتيجة (نموذج): <b>{r}R</b>", "tr_reached": "أعلى هدف: {t}",
    "tr_none": "لم يتحقق أي هدف",
    "cmds2": "📈 إحصاءات الإشارات|⏳ الإشارات المفتوحة|🔔 ضبط تنبيه سعر|🔔 تنبيهاتي",
    "help2": ("📈 <b>التتبع</b>\nتُتابَع كل إشارة تلقائيًا على شموع الدقيقة حتى TP3 أو الوقف أو انتهاء المدة. "
              "تصلك رسالة عند كل TP وعند الوقف. يعرض /stats نسب تحقق الأهداف والصافي بوحدة R "
              "(النموذج: أثلاث عند TP1/TP2/TP3، والوقف إلى الدخول بعد TP1، بدون رسوم).\n"
              "🔔 <b>التنبيهات</b>: /alert BTC 70000"),
    "desc": ("إشارات العملات الرقمية للعقود الآجلة والفوري: Supertrend وMavilimW وEMA وRSI وMACD وADX والحجم "
             "والمستويات. تتبع تلقائي لـ TP/SL مع إحصاءات وتنبيهات أسعار ومفضلة و8 لغات. ليست نصيحة استثمارية."),
    "short_desc": "إشارات رقمية · تتبع TP/SL · 8 لغات",
}
