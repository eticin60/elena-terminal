"""v4 ek metinleri (8 dil): yeni sinyal şeması için uyarılar, plan ve takip notu.
Birleşme sırası: T ← EXT (texts_ext) ← T2 (texts2) ← T3 (bu dosya). Aynı anahtar → sonraki kazanır."""

T3 = {}

T3["en"] = {
    "fac_room": "Room to TP1",
    "w_adx_weak": "⚠️ Weak trend (ADX < 20) — more false signals are likely.",
    "w_rsi_long": "⚠️ RSI is overbought — the move may already be stretched.",
    "w_rsi_short": "⚠️ RSI is oversold — the move may already be stretched.",
    "w_vol_low": "⚠️ Volume is below average — weak confirmation.",
    "plan": "📋 Plan: close ⅓ at each TP · after TP1 move the stop to entry",
    "track_note": "🎯 Auto-tracking is on: you will be notified at every TP and at the stop.",
}

T3["ru"] = {
    "fac_room": "Запас до TP1",
    "w_adx_weak": "⚠️ Слабый тренд (ADX < 20) — выше вероятность ложных сигналов.",
    "w_rsi_long": "⚠️ RSI в зоне перекупленности — движение может быть исчерпано.",
    "w_rsi_short": "⚠️ RSI в зоне перепроданности — движение может быть исчерпано.",
    "w_vol_low": "⚠️ Объём ниже среднего — слабое подтверждение.",
    "plan": "📋 План: закрывать ⅓ на каждом TP · после TP1 перенести стоп на вход",
    "track_note": "🎯 Автоотслеживание включено: вы получите уведомление на каждом TP и на стопе.",
}

T3["tr"] = {
    "fac_room": "TP1'e mesafe",
    "w_adx_weak": "⚠️ Zayıf trend (ADX < 20) — yanlış sinyal ihtimali daha yüksek.",
    "w_rsi_long": "⚠️ RSI aşırı alımda — hareket yorulmuş olabilir.",
    "w_rsi_short": "⚠️ RSI aşırı satımda — hareket yorulmuş olabilir.",
    "w_vol_low": "⚠️ Hacim ortalamanın altında — teyit zayıf.",
    "plan": "📋 Plan: her TP'de ⅓ kapat · TP1'den sonra stopu girişe çek",
    "track_note": "🎯 Otomatik takip açık: her TP'de ve stopta bildirim alırsın.",
}

T3["uk"] = {
    "fac_room": "Запас до TP1",
    "w_adx_weak": "⚠️ Слабкий тренд (ADX < 20) — вища ймовірність хибних сигналів.",
    "w_rsi_long": "⚠️ RSI у зоні перекупленості — рух може бути вичерпаний.",
    "w_rsi_short": "⚠️ RSI у зоні перепроданості — рух може бути вичерпаний.",
    "w_vol_low": "⚠️ Обсяг нижчий за середній — слабке підтвердження.",
    "plan": "📋 План: закривати ⅓ на кожному TP · після TP1 перенести стоп на вхід",
    "track_note": "🎯 Автовідстеження увімкнено: ви отримаєте сповіщення на кожному TP і на стопі.",
}

T3["de"] = {
    "fac_room": "Platz bis TP1",
    "w_adx_weak": "⚠️ Schwacher Trend (ADX < 20) — mehr Fehlsignale wahrscheinlich.",
    "w_rsi_long": "⚠️ RSI überkauft — die Bewegung könnte ausgereizt sein.",
    "w_rsi_short": "⚠️ RSI überverkauft — die Bewegung könnte ausgereizt sein.",
    "w_vol_low": "⚠️ Volumen unter dem Durchschnitt — schwache Bestätigung.",
    "plan": "📋 Plan: bei jedem TP ⅓ schließen · nach TP1 den Stop auf Einstieg ziehen",
    "track_note": "🎯 Automatische Verfolgung aktiv: Sie werden bei jedem TP und beim Stop benachrichtigt.",
}

T3["es"] = {
    "fac_room": "Espacio hasta TP1",
    "w_adx_weak": "⚠️ Tendencia débil (ADX < 20) — más probabilidad de señales falsas.",
    "w_rsi_long": "⚠️ RSI en sobrecompra — el movimiento puede estar agotado.",
    "w_rsi_short": "⚠️ RSI en sobreventa — el movimiento puede estar agotado.",
    "w_vol_low": "⚠️ Volumen por debajo de la media — confirmación débil.",
    "plan": "📋 Plan: cerrar ⅓ en cada TP · tras TP1 mover el stop a la entrada",
    "track_note": "🎯 Seguimiento automático activo: recibirá aviso en cada TP y en el stop.",
}

T3["fr"] = {
    "fac_room": "Marge jusqu'à TP1",
    "w_adx_weak": "⚠️ Tendance faible (ADX < 20) — davantage de faux signaux probables.",
    "w_rsi_long": "⚠️ RSI en surachat — le mouvement est peut-être essoufflé.",
    "w_rsi_short": "⚠️ RSI en survente — le mouvement est peut-être essoufflé.",
    "w_vol_low": "⚠️ Volume inférieur à la moyenne — confirmation faible.",
    "plan": "📋 Plan : clôturer ⅓ à chaque TP · après TP1, remonter le stop à l'entrée",
    "track_note": "🎯 Suivi automatique actif : vous serez averti à chaque TP et au stop.",
}

T3["ar"] = {
    "fac_room": "المسافة إلى TP1",
    "w_adx_weak": "⚠️ اتجاه ضعيف (ADX < 20) — احتمال أكبر لإشارات خاطئة.",
    "w_rsi_long": "⚠️ مؤشر RSI في منطقة التشبع الشرائي — قد تكون الحركة مستنفدة.",
    "w_rsi_short": "⚠️ مؤشر RSI في منطقة التشبع البيعي — قد تكون الحركة مستنفدة.",
    "w_vol_low": "⚠️ الحجم أقل من المتوسط — تأكيد ضعيف.",
    "plan": "📋 الخطة: أغلق ⅓ عند كل هدف · بعد TP1 انقل الوقف إلى سعر الدخول",
    "track_note": "🎯 التتبع التلقائي مفعّل: ستصلك رسالة عند كل هدف وعند الوقف.",
}
