"""v5 ek metinleri (8 dil): acemi anlatımı, korelasyon, ekran ayarları, piyasa listesi, /explain.
Birleşme sırası: T ← EXT ← T2 ← T3 ← T4. `cmds_add` komut listesine eklenir."""

T4 = {}

T4["en"] = {
    "b_autobot": "🤖 Auto-Bot Panel",
    "nar_head": "📖 <b>What is happening?</b>",
    "nar_down": "Price fell {x}% over the last 10 candles — sellers have been in control.",
    "nar_up": "Price rose {x}% over the last 10 candles — buyers have been in control.",
    "nar_flat": "Price has barely moved ({x}% over the last 10 candles) — the market is moving sideways.",
    "nar_state_up": "Supertrend is up: the short-term trend is bullish.",
    "nar_state_dn": "Supertrend is down: the short-term trend is bearish.",
    "nar_vol_hi": "Volume is {x}× the recent average, so many traders are taking part in this move.",
    "nar_vol_lo": "Volume is only {x}× the average — a move on thin volume is easier to reverse.",
    "nar_sup": "Nearest support: {p} ({d}% below). Buyers stepped in here before, so price may bounce.",
    "nar_res": "Nearest resistance: {p} ({d}% above). Sellers appeared here before, so price may stall.",
    "nar_end": "Remember: a signal is a probability, not a certainty.",
    "corr_line": "🔗 Correlation with BTC: <b>{c}</b> ({l})",
    "corr_hi": "strong", "corr_mid": "moderate", "corr_low": "weak",
    "corr_usage": "Usage: <code>/corr SOL</code> or <code>/corr SOL 4h</code>",
    "corr_res": ("🔗 <b>Correlation · {s} · {tf}</b>\n\nBTC: <code>{btc}</code> · {bl}\nETH: <code>{eth}</code> · {el}\n\n"
                 "Based on the last {n} candle returns. Near +1 = moves together, near 0 = independent, "
                 "negative = moves opposite."),
    "corr_none": "Not enough data to calculate the correlation.",
    "b_disp": "🖥 Display", "b_chart": "📈 Chart image: {v}", "b_compact": "📄 Compact mode: {v}",
    "disp_head": ("🖥 <b>Display settings</b>\nChart image: a candle chart with entry, stop, targets and levels is sent "
                  "with each signal.\nCompact mode: only entry, stop, targets, strength and warnings."),
    "b_mkts": "📊 Volume leaders", "mk_head": "📊 <b>Volume leaders · 24h · Futures</b>",
    "ex_usage": "Usage: <code>/explain BTC</code> or <code>/explain BTC 4h</code>",
    "ex_head": "🔎 <b>Market view · {s} · {tf}</b>",
    "cmds_add": "🔗 Correlation|🔎 Market explanation|📊 Volume leaders",
    "help3": ("🆕 <b>More tools</b>\n/explain BTC — plain-language market view\n/corr SOL — correlation with BTC and ETH\n"
              "/markets — volume leaders\n🖥 Display — chart image and compact mode"),
}

T4["ru"] = {
    "b_autobot": "🤖 Панель авто-бота",
    "nar_head": "📖 <b>Что происходит?</b>",
    "nar_down": "За последние 10 свечей цена упала на {x}% — продавцы контролируют рынок.",
    "nar_up": "За последние 10 свечей цена выросла на {x}% — покупатели контролируют рынок.",
    "nar_flat": "Цена почти не изменилась ({x}% за 10 свечей) — рынок движется в боковике.",
    "nar_state_up": "Supertrend направлен вверх: краткосрочный тренд бычий.",
    "nar_state_dn": "Supertrend направлен вниз: краткосрочный тренд медвежий.",
    "nar_vol_hi": "Объём в {x}× выше недавнего среднего — в движении участвует много трейдеров.",
    "nar_vol_lo": "Объём лишь {x}× от среднего — движение на малом объёме легче развернуть.",
    "nar_sup": "Ближайшая поддержка: {p} ({d}% ниже). Здесь уже заходили покупатели, возможен отскок.",
    "nar_res": "Ближайшее сопротивление: {p} ({d}% выше). Здесь уже появлялись продавцы, возможна остановка.",
    "nar_end": "Помните: сигнал — это вероятность, а не уверенность.",
    "corr_line": "🔗 Корреляция с BTC: <b>{c}</b> ({l})",
    "corr_hi": "сильная", "corr_mid": "умеренная", "corr_low": "слабая",
    "corr_usage": "Использование: <code>/corr SOL</code> или <code>/corr SOL 4h</code>",
    "corr_res": ("🔗 <b>Корреляция · {s} · {tf}</b>\n\nBTC: <code>{btc}</code> · {bl}\nETH: <code>{eth}</code> · {el}\n\n"
                 "По доходностям последних {n} свечей. Около +1 — движутся вместе, около 0 — независимо, "
                 "отрицательная — в противоположные стороны."),
    "corr_none": "Недостаточно данных для расчёта корреляции.",
    "b_disp": "🖥 Отображение", "b_chart": "📈 График: {v}", "b_compact": "📄 Краткий режим: {v}",
    "disp_head": ("🖥 <b>Настройки отображения</b>\nГрафик: к каждому сигналу прикладывается свечной график "
                  "со входом, стопом, целями и уровнями.\nКраткий режим: только вход, стоп, цели, сила и предупреждения."),
    "b_mkts": "📊 Лидеры по объёму", "mk_head": "📊 <b>Лидеры по объёму · 24ч · Фьючерсы</b>",
    "ex_usage": "Использование: <code>/explain BTC</code> или <code>/explain BTC 4h</code>",
    "ex_head": "🔎 <b>Обзор рынка · {s} · {tf}</b>",
    "cmds_add": "🔗 Корреляция|🔎 Разбор рынка|📊 Лидеры по объёму",
    "help3": ("🆕 <b>Дополнительно</b>\n/explain BTC — разбор рынка простыми словами\n/corr SOL — корреляция с BTC и ETH\n"
              "/markets — лидеры по объёму\n🖥 Отображение — график и краткий режим"),
}

T4["tr"] = {
    "b_autobot": "🤖 Oto-Bot Paneli",
    "nar_head": "📖 <b>Ne oluyor?</b>",
    "nar_down": "Son 10 mumda fiyat %{x} düştü — satıcılar kontrolü elinde tutuyor.",
    "nar_up": "Son 10 mumda fiyat %{x} yükseldi — alıcılar kontrolü elinde tutuyor.",
    "nar_flat": "Fiyat neredeyse hiç hareket etmedi (10 mumda %{x}) — piyasa yatay seyrediyor.",
    "nar_state_up": "Supertrend yukarı: kısa vadeli trend yükseliş yönünde.",
    "nar_state_dn": "Supertrend aşağı: kısa vadeli trend düşüş yönünde.",
    "nar_vol_hi": "Hacim son ortalamanın {x} katı — bu harekette çok sayıda işlemci yer alıyor.",
    "nar_vol_lo": "Hacim ortalamanın yalnızca {x} katı — düşük hacimli hareketin tersine dönmesi daha kolaydır.",
    "nar_sup": "En yakın destek: {p} (%{d} aşağıda). Alıcılar daha önce burada devreye girdi, fiyat tepki verebilir.",
    "nar_res": "En yakın direnç: {p} (%{d} yukarıda). Satıcılar daha önce burada çıktı, fiyat yavaşlayabilir.",
    "nar_end": "Unutma: sinyal bir olasılıktır, kesinlik değildir.",
    "corr_line": "🔗 BTC ile korelasyon: <b>{c}</b> ({l})",
    "corr_hi": "güçlü", "corr_mid": "orta", "corr_low": "zayıf",
    "corr_usage": "Kullanım: <code>/corr SOL</code> veya <code>/corr SOL 4h</code>",
    "corr_res": ("🔗 <b>Korelasyon · {s} · {tf}</b>\n\nBTC: <code>{btc}</code> · {bl}\nETH: <code>{eth}</code> · {el}\n\n"
                 "Son {n} mumun getirilerine göre. +1'e yakın = birlikte hareket eder, 0'a yakın = bağımsız, "
                 "negatif = ters yönde hareket eder."),
    "corr_none": "Korelasyonu hesaplamak için yeterli veri yok.",
    "b_disp": "🖥 Görünüm", "b_chart": "📈 Grafik resmi: {v}", "b_compact": "📄 Kısa mod: {v}",
    "disp_head": ("🖥 <b>Görünüm ayarları</b>\nGrafik resmi: her sinyalle birlikte giriş, stop, hedefler ve seviyeleri "
                  "gösteren mum grafiği gönderilir.\nKısa mod: yalnızca giriş, stop, hedefler, güç ve uyarılar."),
    "b_mkts": "📊 Hacim liderleri", "mk_head": "📊 <b>Hacim liderleri · 24s · Futures</b>",
    "ex_usage": "Kullanım: <code>/explain BTC</code> veya <code>/explain BTC 4h</code>",
    "ex_head": "🔎 <b>Piyasa görünümü · {s} · {tf}</b>",
    "cmds_add": "🔗 Korelasyon|🔎 Piyasa açıklaması|📊 Hacim liderleri",
    "help3": ("🆕 <b>Ek araçlar</b>\n/explain BTC — sade dille piyasa görünümü\n/corr SOL — BTC ve ETH ile korelasyon\n"
              "/markets — hacim liderleri\n🖥 Görünüm — grafik resmi ve kısa mod"),
}

T4["uk"] = {
    "b_autobot": "🤖 Панель авто-бота",
    "nar_head": "📖 <b>Що відбувається?</b>",
    "nar_down": "За останні 10 свічок ціна впала на {x}% — продавці контролюють ринок.",
    "nar_up": "За останні 10 свічок ціна зросла на {x}% — покупці контролюють ринок.",
    "nar_flat": "Ціна майже не змінилася ({x}% за 10 свічок) — ринок рухається в боковику.",
    "nar_state_up": "Supertrend спрямований вгору: короткостроковий тренд бичачий.",
    "nar_state_dn": "Supertrend спрямований вниз: короткостроковий тренд ведмежий.",
    "nar_vol_hi": "Обсяг у {x}× вищий за недавнє середнє — у русі бере участь багато трейдерів.",
    "nar_vol_lo": "Обсяг лише {x}× від середнього — рух на малому обсязі легше розвернути.",
    "nar_sup": "Найближча підтримка: {p} ({d}% нижче). Тут уже заходили покупці, можливий відскок.",
    "nar_res": "Найближчий опір: {p} ({d}% вище). Тут уже з'являлися продавці, можлива зупинка.",
    "nar_end": "Пам'ятайте: сигнал — це ймовірність, а не впевненість.",
    "corr_line": "🔗 Кореляція з BTC: <b>{c}</b> ({l})",
    "corr_hi": "сильна", "corr_mid": "помірна", "corr_low": "слабка",
    "corr_usage": "Використання: <code>/corr SOL</code> або <code>/corr SOL 4h</code>",
    "corr_res": ("🔗 <b>Кореляція · {s} · {tf}</b>\n\nBTC: <code>{btc}</code> · {bl}\nETH: <code>{eth}</code> · {el}\n\n"
                 "За прибутковістю останніх {n} свічок. Близько +1 — рухаються разом, близько 0 — незалежно, "
                 "від'ємна — у протилежні боки."),
    "corr_none": "Недостатньо даних для розрахунку кореляції.",
    "b_disp": "🖥 Відображення", "b_chart": "📈 Графік: {v}", "b_compact": "📄 Короткий режим: {v}",
    "disp_head": ("🖥 <b>Налаштування відображення</b>\nГрафік: до кожного сигналу додається свічковий графік "
                  "із входом, стопом, цілями та рівнями.\nКороткий режим: лише вхід, стоп, цілі, сила та попередження."),
    "b_mkts": "📊 Лідери за обсягом", "mk_head": "📊 <b>Лідери за обсягом · 24г · Ф'ючерси</b>",
    "ex_usage": "Використання: <code>/explain BTC</code> або <code>/explain BTC 4h</code>",
    "ex_head": "🔎 <b>Огляд ринку · {s} · {tf}</b>",
    "cmds_add": "🔗 Кореляція|🔎 Розбір ринку|📊 Лідери за обсягом",
    "help3": ("🆕 <b>Додатково</b>\n/explain BTC — розбір ринку простими словами\n/corr SOL — кореляція з BTC та ETH\n"
              "/markets — лідери за обсягом\n🖥 Відображення — графік і короткий режим"),
}

T4["de"] = {
    "b_autobot": "🤖 Auto-Bot-Panel",
    "nar_head": "📖 <b>Was passiert gerade?</b>",
    "nar_down": "Der Preis ist in den letzten 10 Kerzen um {x}% gefallen — die Verkäufer haben die Kontrolle.",
    "nar_up": "Der Preis ist in den letzten 10 Kerzen um {x}% gestiegen — die Käufer haben die Kontrolle.",
    "nar_flat": "Der Preis hat sich kaum bewegt ({x}% in 10 Kerzen) — der Markt läuft seitwärts.",
    "nar_state_up": "Supertrend zeigt nach oben: Der kurzfristige Trend ist bullisch.",
    "nar_state_dn": "Supertrend zeigt nach unten: Der kurzfristige Trend ist bärisch.",
    "nar_vol_hi": "Das Volumen liegt beim {x}-Fachen des Durchschnitts — viele Händler beteiligen sich an der Bewegung.",
    "nar_vol_lo": "Das Volumen liegt nur beim {x}-Fachen des Durchschnitts — Bewegungen bei dünnem Volumen kehren leichter um.",
    "nar_sup": "Nächste Unterstützung: {p} ({d}% darunter). Hier griffen schon früher Käufer ein, ein Rebound ist möglich.",
    "nar_res": "Nächster Widerstand: {p} ({d}% darüber). Hier tauchten schon früher Verkäufer auf, der Preis kann stocken.",
    "nar_end": "Bedenken Sie: Ein Signal ist eine Wahrscheinlichkeit, keine Gewissheit.",
    "corr_line": "🔗 Korrelation mit BTC: <b>{c}</b> ({l})",
    "corr_hi": "stark", "corr_mid": "mittel", "corr_low": "schwach",
    "corr_usage": "Nutzung: <code>/corr SOL</code> oder <code>/corr SOL 4h</code>",
    "corr_res": ("🔗 <b>Korrelation · {s} · {tf}</b>\n\nBTC: <code>{btc}</code> · {bl}\nETH: <code>{eth}</code> · {el}\n\n"
                 "Basierend auf den Renditen der letzten {n} Kerzen. Nahe +1 = bewegen sich gemeinsam, nahe 0 = unabhängig, "
                 "negativ = gegenläufig."),
    "corr_none": "Nicht genug Daten für die Korrelation.",
    "b_disp": "🖥 Anzeige", "b_chart": "📈 Chartbild: {v}", "b_compact": "📄 Kompaktmodus: {v}",
    "disp_head": ("🖥 <b>Anzeigeeinstellungen</b>\nChartbild: Zu jedem Signal wird ein Kerzenchart mit Einstieg, Stop, "
                  "Zielen und Marken gesendet.\nKompaktmodus: nur Einstieg, Stop, Ziele, Stärke und Warnungen."),
    "b_mkts": "📊 Volumenführer", "mk_head": "📊 <b>Volumenführer · 24h · Futures</b>",
    "ex_usage": "Nutzung: <code>/explain BTC</code> oder <code>/explain BTC 4h</code>",
    "ex_head": "🔎 <b>Marktüberblick · {s} · {tf}</b>",
    "cmds_add": "🔗 Korrelation|🔎 Markterklärung|📊 Volumenführer",
    "help3": ("🆕 <b>Weitere Werkzeuge</b>\n/explain BTC — Marktüberblick in einfachen Worten\n/corr SOL — Korrelation mit BTC und ETH\n"
              "/markets — Volumenführer\n🖥 Anzeige — Chartbild und Kompaktmodus"),
}

T4["es"] = {
    "b_autobot": "🤖 Panel de bot automático",
    "nar_head": "📖 <b>¿Qué está pasando?</b>",
    "nar_down": "El precio cayó un {x}% en las últimas 10 velas — los vendedores tienen el control.",
    "nar_up": "El precio subió un {x}% en las últimas 10 velas — los compradores tienen el control.",
    "nar_flat": "El precio apenas se ha movido ({x}% en 10 velas) — el mercado va de lado.",
    "nar_state_up": "Supertrend al alza: la tendencia a corto plazo es alcista.",
    "nar_state_dn": "Supertrend a la baja: la tendencia a corto plazo es bajista.",
    "nar_vol_hi": "El volumen es {x}× el promedio reciente — mucha gente participa en este movimiento.",
    "nar_vol_lo": "El volumen es solo {x}× el promedio — un movimiento con poco volumen se revierte con más facilidad.",
    "nar_sup": "Soporte más cercano: {p} ({d}% por debajo). Aquí ya entraron compradores, el precio puede rebotar.",
    "nar_res": "Resistencia más cercana: {p} ({d}% por encima). Aquí ya aparecieron vendedores, el precio puede frenarse.",
    "nar_end": "Recuerde: una señal es una probabilidad, no una certeza.",
    "corr_line": "🔗 Correlación con BTC: <b>{c}</b> ({l})",
    "corr_hi": "fuerte", "corr_mid": "moderada", "corr_low": "débil",
    "corr_usage": "Uso: <code>/corr SOL</code> o <code>/corr SOL 4h</code>",
    "corr_res": ("🔗 <b>Correlación · {s} · {tf}</b>\n\nBTC: <code>{btc}</code> · {bl}\nETH: <code>{eth}</code> · {el}\n\n"
                 "Basada en los retornos de las últimas {n} velas. Cerca de +1 = se mueven juntos, cerca de 0 = independientes, "
                 "negativa = se mueven en sentido contrario."),
    "corr_none": "No hay datos suficientes para calcular la correlación.",
    "b_disp": "🖥 Pantalla", "b_chart": "📈 Imagen del gráfico: {v}", "b_compact": "📄 Modo compacto: {v}",
    "disp_head": ("🖥 <b>Ajustes de pantalla</b>\nImagen del gráfico: con cada señal se envía un gráfico de velas con "
                  "entrada, stop, objetivos y niveles.\nModo compacto: solo entrada, stop, objetivos, fuerza y avisos."),
    "b_mkts": "📊 Líderes de volumen", "mk_head": "📊 <b>Líderes de volumen · 24h · Futuros</b>",
    "ex_usage": "Uso: <code>/explain BTC</code> o <code>/explain BTC 4h</code>",
    "ex_head": "🔎 <b>Vista del mercado · {s} · {tf}</b>",
    "cmds_add": "🔗 Correlación|🔎 Explicación del mercado|📊 Líderes de volumen",
    "help3": ("🆕 <b>Más herramientas</b>\n/explain BTC — vista del mercado en lenguaje sencillo\n/corr SOL — correlación con BTC y ETH\n"
              "/markets — líderes de volumen\n🖥 Pantalla — imagen del gráfico y modo compacto"),
}

T4["fr"] = {
    "b_autobot": "🤖 Panneau du bot auto",
    "nar_head": "📖 <b>Que se passe-t-il ?</b>",
    "nar_down": "Le prix a reculé de {x} % sur les 10 dernières bougies — les vendeurs dominent.",
    "nar_up": "Le prix a progressé de {x} % sur les 10 dernières bougies — les acheteurs dominent.",
    "nar_flat": "Le prix a à peine bougé ({x} % sur 10 bougies) — le marché évolue latéralement.",
    "nar_state_up": "Supertrend orienté à la hausse : la tendance à court terme est haussière.",
    "nar_state_dn": "Supertrend orienté à la baisse : la tendance à court terme est baissière.",
    "nar_vol_hi": "Le volume est {x}× la moyenne récente — beaucoup d'acteurs participent à ce mouvement.",
    "nar_vol_lo": "Le volume n'est que {x}× la moyenne — un mouvement sur faible volume se retourne plus facilement.",
    "nar_sup": "Support le plus proche : {p} ({d} % en dessous). Des acheteurs sont déjà intervenus ici, un rebond est possible.",
    "nar_res": "Résistance la plus proche : {p} ({d} % au-dessus). Des vendeurs sont déjà apparus ici, le prix peut s'arrêter.",
    "nar_end": "Rappel : un signal est une probabilité, pas une certitude.",
    "corr_line": "🔗 Corrélation avec BTC : <b>{c}</b> ({l})",
    "corr_hi": "forte", "corr_mid": "modérée", "corr_low": "faible",
    "corr_usage": "Usage : <code>/corr SOL</code> ou <code>/corr SOL 4h</code>",
    "corr_res": ("🔗 <b>Corrélation · {s} · {tf}</b>\n\nBTC : <code>{btc}</code> · {bl}\nETH : <code>{eth}</code> · {el}\n\n"
                 "Calculée sur les rendements des {n} dernières bougies. Proche de +1 = évoluent ensemble, proche de 0 = indépendants, "
                 "négative = évoluent en sens inverse."),
    "corr_none": "Pas assez de données pour calculer la corrélation.",
    "b_disp": "🖥 Affichage", "b_chart": "📈 Image du graphique : {v}", "b_compact": "📄 Mode compact : {v}",
    "disp_head": ("🖥 <b>Réglages d'affichage</b>\nImage du graphique : chaque signal est accompagné d'un graphique en bougies "
                  "avec entrée, stop, objectifs et niveaux.\nMode compact : uniquement entrée, stop, objectifs, force et alertes."),
    "b_mkts": "📊 Leaders en volume", "mk_head": "📊 <b>Leaders en volume · 24h · Futures</b>",
    "ex_usage": "Usage : <code>/explain BTC</code> ou <code>/explain BTC 4h</code>",
    "ex_head": "🔎 <b>Vue du marché · {s} · {tf}</b>",
    "cmds_add": "🔗 Corrélation|🔎 Explication du marché|📊 Leaders en volume",
    "help3": ("🆕 <b>Autres outils</b>\n/explain BTC — vue du marché en langage simple\n/corr SOL — corrélation avec BTC et ETH\n"
              "/markets — leaders en volume\n🖥 Affichage — image du graphique et mode compact"),
}

T4["ar"] = {
    "b_autobot": "🤖 لوحة البوت الآلي",
    "nar_head": "📖 <b>ماذا يحدث؟</b>",
    "nar_down": "انخفض السعر {x}% خلال آخر 10 شموع — البائعون يسيطرون على السوق.",
    "nar_up": "ارتفع السعر {x}% خلال آخر 10 شموع — المشترون يسيطرون على السوق.",
    "nar_flat": "السعر بالكاد تحرك ({x}% خلال 10 شموع) — السوق يتحرك عرضيًا.",
    "nar_state_up": "مؤشر Supertrend صاعد: الاتجاه قصير المدى صعودي.",
    "nar_state_dn": "مؤشر Supertrend هابط: الاتجاه قصير المدى هبوطي.",
    "nar_vol_hi": "الحجم يعادل {x} أضعاف المتوسط الأخير — عدد كبير من المتداولين يشارك في هذه الحركة.",
    "nar_vol_lo": "الحجم {x} فقط من المتوسط — الحركة بحجم ضعيف أسهل في الانعكاس.",
    "nar_sup": "أقرب دعم: {p} (أقل بنسبة {d}%). دخل المشترون هنا سابقًا، وقد يرتد السعر.",
    "nar_res": "أقرب مقاومة: {p} (أعلى بنسبة {d}%). ظهر البائعون هنا سابقًا، وقد يتباطأ السعر.",
    "nar_end": "تذكّر: الإشارة احتمال وليست يقينًا.",
    "corr_line": "🔗 الارتباط مع BTC: <b>{c}</b> ({l})",
    "corr_hi": "قوي", "corr_mid": "متوسط", "corr_low": "ضعيف",
    "corr_usage": "الاستخدام: <code>/corr SOL</code> أو <code>/corr SOL 4h</code>",
    "corr_res": ("🔗 <b>الارتباط · {s} · {tf}</b>\n\nBTC: <code>{btc}</code> · {bl}\nETH: <code>{eth}</code> · {el}\n\n"
                 "بناءً على عوائد آخر {n} شمعة. القريب من +1 = يتحركان معًا، القريب من 0 = مستقلان، "
                 "السالب = يتحركان في اتجاهين متعاكسين."),
    "corr_none": "لا توجد بيانات كافية لحساب الارتباط.",
    "b_disp": "🖥 العرض", "b_chart": "📈 صورة الرسم البياني: {v}", "b_compact": "📄 الوضع المختصر: {v}",
    "disp_head": ("🖥 <b>إعدادات العرض</b>\nصورة الرسم البياني: يُرسل مع كل إشارة رسم شموع يعرض الدخول والوقف والأهداف "
                  "والمستويات.\nالوضع المختصر: الدخول والوقف والأهداف والقوة والتحذيرات فقط."),
    "b_mkts": "📊 الأعلى حجمًا", "mk_head": "📊 <b>الأعلى حجمًا · 24 ساعة · آجلة</b>",
    "ex_usage": "الاستخدام: <code>/explain BTC</code> أو <code>/explain BTC 4h</code>",
    "ex_head": "🔎 <b>نظرة على السوق · {s} · {tf}</b>",
    "cmds_add": "🔗 الارتباط|🔎 شرح السوق|📊 الأعلى حجمًا",
    "help3": ("🆕 <b>أدوات إضافية</b>\n/explain BTC — نظرة على السوق بلغة بسيطة\n/corr SOL — الارتباط مع BTC وETH\n"
              "/markets — الأعلى حجمًا\n🖥 العرض — صورة الرسم البياني والوضع المختصر"),
}
