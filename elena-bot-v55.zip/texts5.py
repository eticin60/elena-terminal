"""v6 ek metin: şartları kabul ettikten SONRA, menüden ÖNCE gösterilen profesyonel
"hoş geldin" ekranı (8 dil). Birleşme sırası: T ← EXT ← T2 ← T3 ← T4 ← T5."""

T5 = {}

T5["en"] = {
    "b_continue": "➡️ Continue to dashboard",
    "welcome": (
        "✅ <b>You're all set, welcome aboard!</b>\n\n"
        "<b>Елена Хьюз · Crypto Signals</b> watches the market for you around the clock and turns raw "
        "price action into clear, actionable signals — in your language.\n\n"
        "📡 <b>Automated signals</b> — entry, stop and 3 take-profit levels, generated the moment the "
        "trend flips on live global market data.\n"
        "⭐ <b>0–10 strength score</b> — every signal is graded against up to 10 technical confirmations "
        "(trend, volume, RSI, MACD, ADX and more).\n"
        "📈 <b>Charts & plain-language summaries</b> — see the setup, don't just read it.\n"
        "🧮 <b>Calculator, history & stats</b> — real TP/SL hit-rates and net R, not promises.\n\n"
        "👉 Next: pick your coins and timeframes, and the bot takes it from there."
    ),
}

T5["ru"] = {
    "b_continue": "➡️ Перейти в панель",
    "welcome": (
        "✅ <b>Добро пожаловать, всё готово!</b>\n\n"
        "<b>Елена Хьюз · Crypto Signals</b> круглосуточно следит за рынком и превращает движение цены в "
        "понятные, готовые к действию сигналы — на вашем языке.\n\n"
        "📡 <b>Автоматические сигналы</b> — вход, стоп и 3 уровня тейк-профита, формируются сразу при "
        "развороте тренда по институциональным данным в реальном времени.\n"
        "⭐ <b>Оценка силы 0–10</b> — каждый сигнал проверяется по 10 техническим подтверждениям "
        "(тренд, объём, RSI, MACD, ADX и др.).\n"
        "📈 <b>Графики и простые объяснения</b> — видно, а не только читаемо.\n"
        "🧮 <b>Калькулятор, история и статистика</b> — реальная статистика TP/SL, а не обещания.\n\n"
        "👉 Дальше: выберите монеты и таймфреймы — остальное сделает бот."
    ),
}

T5["tr"] = {
    "b_continue": "➡️ Panele geç",
    "welcome": (
        "✅ <b>Hoş geldin, her şey hazır!</b>\n\n"
        "<b>Елена Хьюз · Crypto Signals</b> piyasayı senin için 7/24 izler ve fiyat hareketini net, "
        "uygulanabilir sinyallere çevirir — kendi dilinde.\n\n"
        "📡 <b>Otomatik sinyaller</b> — giriş, stop ve 3 kademeli kâr alma seviyesi, trend döner dönmez "
        "canlı kurumsal piyasa ve likidite verisiyle anında üretilir.\n"
        "⭐ <b>0–10 güç puanı</b> — her sinyal; trend, hacim, RSI, MACD, ADX ve daha fazlasını kapsayan "
        "10'a kadar teknik teyitle derecelendirilir.\n"
        "📈 <b>Grafik ve sade anlatım</b> — kurulumu sadece okuma, gör.\n"
        "🧮 <b>Hesap makinesi, geçmiş ve istatistik</b> — gerçek TP/SL oranları, boş vaat değil.\n\n"
        "👉 Sırada: coin ve zaman dilimlerini seç, gerisini bot halleder."
    ),
}

T5["uk"] = {
    "b_continue": "➡️ Перейти до панелі",
    "welcome": (
        "✅ <b>Вітаємо, усе готово!</b>\n\n"
        "<b>Елена Хьюз · Crypto Signals</b> цілодобово стежить за ринком і перетворює рух ціни на чіткі, "
        "готові до дії сигнали — вашою мовою.\n\n"
        "📡 <b>Автоматичні сигнали</b> — вхід, стоп і 3 рівні тейк-профіту, формуються одразу після "
        "розвороту тренду за інституційними даними в реальному часі.\n"
        "⭐ <b>Оцінка сили 0–10</b> — кожен сигнал перевіряється до 10 технічними підтвердженнями "
        "(тренд, обсяг, RSI, MACD, ADX тощо).\n"
        "📈 <b>Графіки та прості пояснення</b> — видно, а не лише читається.\n"
        "🧮 <b>Калькулятор, історія та статистика</b> — реальні показники TP/SL, а не обіцянки.\n\n"
        "👉 Далі: оберіть монети й таймфрейми — решту зробить бот."
    ),
}

T5["de"] = {
    "b_continue": "➡️ Weiter zum Dashboard",
    "welcome": (
        "✅ <b>Willkommen, alles ist bereit!</b>\n\n"
        "<b>Елена Хьюз · Crypto Signals</b> beobachtet den Markt rund um die Uhr für dich und verwandelt "
        "Preisbewegungen in klare, umsetzbare Signale — in deiner Sprache.\n\n"
        "📡 <b>Automatische Signale</b> — Einstieg, Stop und 3 Take-Profit-Stufen, sofort generiert, "
        "sobald der Trend auf Live-Marktdaten dreht.\n"
        "⭐ <b>Stärke-Score 0–10</b> — jedes Signal wird anhand von bis zu 10 technischen Bestätigungen "
        "bewertet (Trend, Volumen, RSI, MACD, ADX u. a.).\n"
        "📈 <b>Charts & einfache Erklärungen</b> — sehen statt nur lesen.\n"
        "🧮 <b>Rechner, Verlauf & Statistik</b> — echte TP/SL-Trefferquoten, keine Versprechen.\n\n"
        "👉 Als Nächstes: Coins und Zeitrahmen wählen — den Rest übernimmt der Bot."
    ),
}

T5["es"] = {
    "b_continue": "➡️ Ir al panel",
    "welcome": (
        "✅ <b>¡Bienvenido, todo está listo!</b>\n\n"
        "<b>Елена Хьюз · Crypto Signals</b> vigila el mercado por ti las 24 horas y convierte el "
        "movimiento del precio en señales claras y accionables — en tu idioma.\n\n"
        "📡 <b>Señales automáticas</b> — entrada, stop y 3 niveles de take-profit, generadas en el "
        "momento en que el tendencia gira, con datos de mercado en vivo.\n"
        "⭐ <b>Puntuación de fuerza 0–10</b> — cada señal se evalúa con hasta 10 confirmaciones técnicas "
        "(tendencia, volumen, RSI, MACD, ADX y más).\n"
        "📈 <b>Gráficos y explicaciones sencillas</b> — para verlo, no solo leerlo.\n"
        "🧮 <b>Calculadora, historial y estadísticas</b> — tasas reales de TP/SL, no promesas.\n\n"
        "👉 Lo siguiente: elige tus monedas y temporalidades, el bot se encarga del resto."
    ),
}

T5["fr"] = {
    "b_continue": "➡️ Accéder au tableau de bord",
    "welcome": (
        "✅ <b>Bienvenue, tout est prêt !</b>\n\n"
        "<b>Елена Хьюз · Crypto Signals</b> surveille le marché pour vous 24h/24 et transforme les "
        "mouvements de prix en signaux clairs et exploitables — dans votre langue.\n\n"
        "📡 <b>Signaux automatiques</b> — entrée, stop et 3 niveaux de take-profit, générés dès que la "
        "tendance s'inverse, sur des données de marché en direct.\n"
        "⭐ <b>Score de force 0–10</b> — chaque signal est noté selon jusqu'à 10 confirmations techniques "
        "(tendance, volume, RSI, MACD, ADX et plus).\n"
        "📈 <b>Graphiques et explications simples</b> — à voir, pas seulement à lire.\n"
        "🧮 <b>Calculatrice, historique et statistiques</b> — de vrais taux de réussite TP/SL, pas de promesses.\n\n"
        "👉 Ensuite : choisissez vos cryptos et unités de temps, le bot fait le reste."
    ),
}

T5["ar"] = {
    "b_continue": "➡️ الانتقال إلى اللوحة",
    "welcome": (
        "✅ <b>مرحبًا بك، كل شيء جاهز!</b>\n\n"
        "يراقب <b>Елена Хьюз · Crypto Signals</b> السوق نيابةً عنك على مدار الساعة، ويحوّل حركة السعر إلى "
        "إشارات واضحة وقابلة للتنفيذ — بلغتك.\n\n"
        "📡 <b>إشارات تلقائية</b> — دخول ووقف إيقاف و3 مستويات لجني الأرباح، تُنشأ فور انعكاس الاتجاه "
        "باستخدام بيانات السوق الحية.\n"
        "⭐ <b>درجة قوة من 0 إلى 10</b> — يتم تقييم كل إشارة وفق ما يصل إلى 10 تأكيدات فنية (الاتجاه، "
        "الحجم، RSI، MACD، ADX وغيرها).\n"
        "📈 <b>رسوم بيانية وشروحات مبسطة</b> — لتراها، لا أن تقرأها فقط.\n"
        "🧮 <b>حاسبة وسجل وإحصاءات</b> — نسب نجاح حقيقية لـ TP/SL، لا وعود.\n\n"
        "👉 التالي: اختر عملاتك والأطر الزمنية، والبوت يتولى الباقي."
    ),
}
