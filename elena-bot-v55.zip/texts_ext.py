"""v3 metinleri: detaylı sinyal bölümleri, TP/SL olayları, performans, fiyat alarmı, backtest, yardım.
Her dil aynı anahtarlara ve aynı {yer tutuculara} sahip olmalıdır (testlerle doğrulanır)."""

EXT = {}

EXT["en"] = {
    "grade_word": "Grade",
    "sec_levels": "📐 <b>Key levels</b>",
    "res": "🧱 Resistance", "sup": "🛟 Support",
    "sec_ind": "📊 <b>Indicators</b>",
    "rsi_ob": "overbought", "rsi_os": "oversold", "rsi_n": "neutral",
    "adx_strong": "strong trend", "adx_weak": "weak trend",
    "ind_vol": "Volume: {x}× avg · buyers {b}%",
    "ind_atr": "Volatility (ATR): {x}% of price",
    "sec_mtf": "🌐 <b>Higher timeframes</b>",
    "sec_fut": "💹 <b>Futures data</b>",
    "fut_line": "Funding {f}% · Open interest {oi} · Long/Short {ls}",
    "sec_pat": "🔍 <b>Pattern</b>",
    "pat_dtop": "Double top (M)", "pat_dbot": "Double bottom (W)",
    "pat_bflag": "Bull flag", "pat_sflag": "Bear flag",
    "w_sr": "⚠️ Next opposing level is only {d}% away — little room to TP1.",
    "w_fund": "⚠️ Funding is extreme in this direction (crowded trade).",
    "w_htf": "⚠️ Against the higher-timeframe trend.",
    "w_low": "⚠️ Few confirmations — higher risk.",
    "risk_hint": "💼 For 1% account risk: position ≈ {x}× balance",
    "fac_vol": "Volume",
    "ev_tp1": ("🎯 <b>TP1 reached</b>\n<code>{s}</code> · {tf} · {side}\nPrice: <code>{p}</code>\n"
               "💰 Banked: <b>{r}R</b> (⅓ closed)\n🛡 Stop moved to entry (breakeven)."),
    "ev_tp2": ("🎯🎯 <b>TP2 reached</b>\n<code>{s}</code> · {tf} · {side}\nPrice: <code>{p}</code>\n"
               "💰 Banked: <b>{r}R</b> (⅔ closed)\n🛡 Stop moved to TP1."),
    "ev_tp3": ("🏆 <b>TP3 reached — all targets hit!</b>\n<code>{s}</code> · {tf} · {side}\n"
               "Price: <code>{p}</code>\n✅ Final result: <b>{r}R</b>"),
    "ev_sl": ("🛑 <b>Stop-loss hit</b>\n<code>{s}</code> · {tf} · {side}\nPrice: <code>{p}</code>\n"
              "❌ Final result: <b>{r}R</b>"),
    "ev_be": ("🔶 <b>Stopped at breakeven</b> (after TP1)\n<code>{s}</code> · {tf} · {side}\n"
              "Price: <code>{p}</code>\n✅ Final result: <b>{r}R</b>"),
    "ev_tp2stop": ("🔷 <b>Stopped at TP1 level</b> (after TP2)\n<code>{s}</code> · {tf} · {side}\n"
                   "Price: <code>{p}</code>\n✅ Final result: <b>{r}R</b>"),
    "ev_flip": ("🔄 <b>Trend reversed — signal closed</b>\n<code>{s}</code> · {tf} · {side}\n"
                "Closed at <code>{p}</code>\nFinal result: <b>{r}R</b>"),
    "ev_exp": ("⌛ <b>Signal expired</b> (no TP or stop reached)\n<code>{s}</code> · {tf} · {side}\n"
               "Closed at <code>{p}</code>\nFinal result: <b>{r}R</b>"),
    "b_perf": "📈 Performance", "b_open": "🔓 Open signals", "b_alerts": "🔔 Price alerts",
    "b_track": "🎯 TP/SL alerts: {v}",
    "perf_head": "📈 <b>Signal performance</b> · {period}",
    "perf_p7": "7 days", "perf_p30": "30 days", "perf_pall": "all time",
    "perf_empty": "No closed signals in this period yet.",
    "perf_sum": ("✅ Closed: <b>{n}</b> · ⏳ Open: <b>{o}</b>\n🏆 Win rate: <b>{win}%</b> ({w}W / {l}L)\n"
                 "📐 Average: <b>{avg}R</b> · Total: <b>{tot}R</b>\n⚖️ Profit factor: <b>{pf}</b>"),
    "perf_tf": "⏱ By timeframe", "perf_side": "↕️ By direction", "perf_grade": "⭐ By grade",
    "perf_coins": "🪙 By coin",
    "perf_note": ("ℹ️ Simulation: entry at candle close; ⅓ of the position closes at each TP; the stop moves to "
                  "entry after TP1 and to TP1 after TP2; if a TP and the stop fall in one candle the stop is "
                  "assumed first. 1R = distance to the stop. Real results differ. Not investment advice."),
    "open_head": "🔓 <b>Open signals</b>", "open_empty": "No open signals right now.", "st_wait": "no TP yet",
    "al_usage": "Usage: <code>/alert BTC 70000</code>",
    "al_set": "✅ Alert set: <code>{s}</code> {d} <b>{p}</b>",
    "al_hit": "🔔 <b>Price alert</b>\n<code>{s}</code> reached <b>{p}</b>\n🎯 Target: {t}",
    "al_list": "🔔 <b>Your price alerts</b>\nTap ✕ to delete one.",
    "al_empty": "No active alerts. Add one: <code>/alert BTC 70000</code>",
    "al_limit": "Maximum {n} alerts.", "al_bad": "❌ Invalid symbol or price.",
    "al_now": "❌ The target equals the current price.",
    "bt_usage": "Usage: <code>/backtest BTC 1h</code>",
    "bt_head": "🧪 <b>Backtest</b> · {s} · {tf} · {c} candles",
    "bt_sum": ("🔁 Trades: <b>{n}</b>\n🏆 Win rate: <b>{win}%</b> ({w}W / {l}L)\n"
               "📐 Average: <b>{avg}R</b> · Total: <b>{tot}R</b>\n⚖️ Profit factor: <b>{pf}</b>\n"
               "📉 Max drawdown: <b>{dd}R</b>"),
    "bt_none": "Not enough trades or candles for this pair/timeframe.",
    "bt_note": ("ℹ️ Same rules as live tracking, simulated on candles of this timeframe (the order of price moves "
                "inside a candle is unknown). Past results do not predict future results."),
    "help": (
        "❓ <b>How it works</b>\n\n"
        "1) Pick coins and timeframes.\n"
        "2) On each candle close the bot checks Supertrend (ATR 10 × 3). On a trend flip it analyses "
        "MavilimW, EMA 200, RSI, StochRSI, MACD, ADX, Bollinger, VWAP, volume, support/resistance, "
        "Fibonacci, patterns and higher timeframes.\n"
        "3) The signal shows entry, stop (Supertrend line), TP1–TP3 (1R/2R/3R), indicative leverage and a "
        "score out of 10 (grade A–D).\n"
        "4) 🎯 The bot then tracks every signal and alerts you when TP1/TP2/TP3 or the stop is hit. "
        "Results: /stats\n"
        "5) 🔔 Price alerts: /alert BTC 70000 · 🧪 Backtest: /backtest BTC 1h\n\n"
        "⚠️ Not investment advice. Always use a stop-loss and risk no more than 1–2% per trade."
    ),
    "cmds": ("📋 Menu|🪙 My coins|⏱ Timeframes|💱 Live price|🔥 Top movers|🧮 Risk calculator|🕘 Signal history|"
             "📈 Performance stats|🔓 Open signals|🔔 Price alerts|🧪 Backtest|🌐 Language|💝 Donate|"
             "⚖️ Terms|❓ Help|🗑 Delete my data"),
    "desc": ("Crypto signals for Futures & Spot with TP/SL tracking. Supertrend, MavilimW, RSI, MACD, ADX, "
             "volume and support/resistance analysis on 1m–1M, price alerts, backtests and 8 languages. "
             "Not investment advice."),
    "short_desc": "Crypto signals · TP/SL tracking · 8 languages",
}

EXT["ru"] = {
    "grade_word": "Оценка",
    "sec_levels": "📐 <b>Ключевые уровни</b>",
    "res": "🧱 Сопротивление", "sup": "🛟 Поддержка",
    "sec_ind": "📊 <b>Индикаторы</b>",
    "rsi_ob": "перекупленность", "rsi_os": "перепроданность", "rsi_n": "нейтрально",
    "adx_strong": "сильный тренд", "adx_weak": "слабый тренд",
    "ind_vol": "Объём: {x}× от среднего · покупатели {b}%",
    "ind_atr": "Волатильность (ATR): {x}% от цены",
    "sec_mtf": "🌐 <b>Старшие таймфреймы</b>",
    "sec_fut": "💹 <b>Данные фьючерсов</b>",
    "fut_line": "Фандинг {f}% · Открытый интерес {oi} · Лонг/Шорт {ls}",
    "sec_pat": "🔍 <b>Паттерн</b>",
    "pat_dtop": "Двойная вершина (M)", "pat_dbot": "Двойное дно (W)",
    "pat_bflag": "Бычий флаг", "pat_sflag": "Медвежий флаг",
    "w_sr": "⚠️ Следующий встречный уровень всего в {d}% — мало места до TP1.",
    "w_fund": "⚠️ Фандинг экстремален в этом направлении (перегретая сделка).",
    "w_htf": "⚠️ Против тренда старшего таймфрейма.",
    "w_low": "⚠️ Мало подтверждений — повышенный риск.",
    "risk_hint": "💼 При риске 1% депозита: позиция ≈ {x}× от баланса",
    "fac_vol": "Объём",
    "ev_tp1": ("🎯 <b>TP1 достигнут</b>\n<code>{s}</code> · {tf} · {side}\nЦена: <code>{p}</code>\n"
               "💰 Зафиксировано: <b>{r}R</b> (закрыта ⅓)\n🛡 Стоп перенесён на вход (безубыток)."),
    "ev_tp2": ("🎯🎯 <b>TP2 достигнут</b>\n<code>{s}</code> · {tf} · {side}\nЦена: <code>{p}</code>\n"
               "💰 Зафиксировано: <b>{r}R</b> (закрыто ⅔)\n🛡 Стоп перенесён на TP1."),
    "ev_tp3": ("🏆 <b>TP3 достигнут — все цели взяты!</b>\n<code>{s}</code> · {tf} · {side}\n"
               "Цена: <code>{p}</code>\n✅ Итог: <b>{r}R</b>"),
    "ev_sl": ("🛑 <b>Сработал стоп-лосс</b>\n<code>{s}</code> · {tf} · {side}\nЦена: <code>{p}</code>\n"
              "❌ Итог: <b>{r}R</b>"),
    "ev_be": ("🔶 <b>Выход по безубытку</b> (после TP1)\n<code>{s}</code> · {tf} · {side}\n"
              "Цена: <code>{p}</code>\n✅ Итог: <b>{r}R</b>"),
    "ev_tp2stop": ("🔷 <b>Выход по стопу на уровне TP1</b> (после TP2)\n<code>{s}</code> · {tf} · {side}\n"
                   "Цена: <code>{p}</code>\n✅ Итог: <b>{r}R</b>"),
    "ev_flip": ("🔄 <b>Тренд развернулся — сигнал закрыт</b>\n<code>{s}</code> · {tf} · {side}\n"
                "Закрыт по <code>{p}</code>\nИтог: <b>{r}R</b>"),
    "ev_exp": ("⌛ <b>Сигнал устарел</b> (ни TP, ни стоп не достигнуты)\n<code>{s}</code> · {tf} · {side}\n"
               "Закрыт по <code>{p}</code>\nИтог: <b>{r}R</b>"),
    "b_perf": "📈 Статистика", "b_open": "🔓 Открытые сигналы", "b_alerts": "🔔 Ценовые алерты",
    "b_track": "🎯 Уведомления TP/SL: {v}",
    "perf_head": "📈 <b>Результаты сигналов</b> · {period}",
    "perf_p7": "7 дней", "perf_p30": "30 дней", "perf_pall": "всё время",
    "perf_empty": "За этот период закрытых сигналов пока нет.",
    "perf_sum": ("✅ Закрыто: <b>{n}</b> · ⏳ Открыто: <b>{o}</b>\n🏆 Винрейт: <b>{win}%</b> ({w}W / {l}L)\n"
                 "📐 Средний: <b>{avg}R</b> · Всего: <b>{tot}R</b>\n⚖️ Профит-фактор: <b>{pf}</b>"),
    "perf_tf": "⏱ По таймфреймам", "perf_side": "↕️ По направлению", "perf_grade": "⭐ По оценке",
    "perf_coins": "🪙 По монетам",
    "perf_note": ("ℹ️ Симуляция: вход по закрытию свечи; на каждом TP закрывается ⅓ позиции; после TP1 стоп "
                  "переносится на вход, после TP2 — на TP1; если TP и стоп в одной свече, считается, что стоп "
                  "сработал первым. 1R = расстояние до стопа. Реальные результаты отличаются. Не инвестсовет."),
    "open_head": "🔓 <b>Открытые сигналы</b>", "open_empty": "Сейчас нет открытых сигналов.",
    "st_wait": "TP ещё нет",
    "al_usage": "Использование: <code>/alert BTC 70000</code>",
    "al_set": "✅ Алерт создан: <code>{s}</code> {d} <b>{p}</b>",
    "al_hit": "🔔 <b>Ценовой алерт</b>\n<code>{s}</code> достиг <b>{p}</b>\n🎯 Цель: {t}",
    "al_list": "🔔 <b>Ваши ценовые алерты</b>\nНажмите ✕, чтобы удалить.",
    "al_empty": "Активных алертов нет. Добавьте: <code>/alert BTC 70000</code>",
    "al_limit": "Максимум алертов: {n}.", "al_bad": "❌ Неверная пара или цена.",
    "al_now": "❌ Цель равна текущей цене.",
    "bt_usage": "Использование: <code>/backtest BTC 1h</code>",
    "bt_head": "🧪 <b>Бэктест</b> · {s} · {tf} · {c} свечей",
    "bt_sum": ("🔁 Сделок: <b>{n}</b>\n🏆 Винрейт: <b>{win}%</b> ({w}W / {l}L)\n"
               "📐 Средний: <b>{avg}R</b> · Всего: <b>{tot}R</b>\n⚖️ Профит-фактор: <b>{pf}</b>\n"
               "📉 Макс. просадка: <b>{dd}R</b>"),
    "bt_none": "Недостаточно сделок или свечей для этой пары/таймфрейма.",
    "bt_note": ("ℹ️ Те же правила, что и в живом отслеживании, симуляция на свечах этого таймфрейма (порядок "
                "движения цены внутри свечи неизвестен). Прошлые результаты не гарантируют будущих."),
    "help": (
        "❓ <b>Как это работает</b>\n\n"
        "1) Выберите монеты и таймфреймы.\n"
        "2) На закрытии каждой свечи бот проверяет Supertrend (ATR 10 × 3). При смене тренда анализируются "
        "MavilimW, EMA 200, RSI, StochRSI, MACD, ADX, Bollinger, VWAP, объём, поддержка/сопротивление, "
        "Фибоначчи, паттерны и старшие таймфреймы.\n"
        "3) В сигнале: вход, стоп (линия Supertrend), TP1–TP3 (1R/2R/3R), ориентировочное плечо и оценка "
        "из 10 (класс A–D).\n"
        "4) 🎯 Бот отслеживает каждый сигнал и сообщает, когда достигнут TP1/TP2/TP3 или стоп. "
        "Результаты: /stats\n"
        "5) 🔔 Ценовые алерты: /alert BTC 70000 · 🧪 Бэктест: /backtest BTC 1h\n\n"
        "⚠️ Не инвестсовет. Всегда используйте стоп-лосс и рискуйте не более 1–2% на сделку."
    ),
    "cmds": ("📋 Меню|🪙 Мои монеты|⏱ Таймфреймы|💱 Цена онлайн|🔥 Лидеры рынка|🧮 Калькулятор риска|"
             "🕘 История сигналов|📈 Статистика|🔓 Открытые сигналы|🔔 Ценовые алерты|🧪 Бэктест|🌐 Язык|"
             "💝 Поддержать|⚖️ Условия|❓ Помощь|🗑 Удалить мои данные"),
    "desc": ("Крипто-сигналы для фьючерсов и спота с отслеживанием TP/SL. Анализ Supertrend, MavilimW, RSI, "
             "MACD, ADX, объёма и уровней на 1m–1M, ценовые алерты, бэктест и 8 языков. Не инвестсовет."),
    "short_desc": "Крипто-сигналы · Отслеживание TP/SL · 8 языков",
}

EXT["tr"] = {
    "grade_word": "Derece",
    "sec_levels": "📐 <b>Önemli seviyeler</b>",
    "res": "🧱 Direnç", "sup": "🛟 Destek",
    "sec_ind": "📊 <b>Göstergeler</b>",
    "rsi_ob": "aşırı alım", "rsi_os": "aşırı satım", "rsi_n": "nötr",
    "adx_strong": "güçlü trend", "adx_weak": "zayıf trend",
    "ind_vol": "Hacim: ortalamanın {x}× katı · alıcılar %{b}",
    "ind_atr": "Volatilite (ATR): fiyatın %{x}'i",
    "sec_mtf": "🌐 <b>Üst zaman dilimleri</b>",
    "sec_fut": "💹 <b>Futures verisi</b>",
    "fut_line": "Fonlama %{f} · Açık pozisyon {oi} · Long/Short {ls}",
    "sec_pat": "🔍 <b>Formasyon</b>",
    "pat_dtop": "Çift tepe (M)", "pat_dbot": "Çift dip (W)",
    "pat_bflag": "Boğa bayrağı", "pat_sflag": "Ayı bayrağı",
    "w_sr": "⚠️ Karşı yöndeki sonraki seviye yalnızca %{d} uzakta — TP1'e kadar alan dar.",
    "w_fund": "⚠️ Fonlama bu yönde aşırı (kalabalık işlem).",
    "w_htf": "⚠️ Üst zaman dilimi trendine ters.",
    "w_low": "⚠️ Teyit az — risk yüksek.",
    "risk_hint": "💼 Hesabın %1'ini riske atmak için: pozisyon ≈ bakiyenin {x} katı",
    "fac_vol": "Hacim",
    "ev_tp1": ("🎯 <b>TP1'e ulaşıldı</b>\n<code>{s}</code> · {tf} · {side}\nFiyat: <code>{p}</code>\n"
               "💰 Kasaya yazılan: <b>{r}R</b> (⅓ kapandı)\n🛡 Stop girişe çekildi (başabaş)."),
    "ev_tp2": ("🎯🎯 <b>TP2'ye ulaşıldı</b>\n<code>{s}</code> · {tf} · {side}\nFiyat: <code>{p}</code>\n"
               "💰 Kasaya yazılan: <b>{r}R</b> (⅔ kapandı)\n🛡 Stop TP1'e çekildi."),
    "ev_tp3": ("🏆 <b>TP3'e ulaşıldı — tüm hedefler vuruldu!</b>\n<code>{s}</code> · {tf} · {side}\n"
               "Fiyat: <code>{p}</code>\n✅ Nihai sonuç: <b>{r}R</b>"),
    "ev_sl": ("🛑 <b>Stop-loss çalıştı</b>\n<code>{s}</code> · {tf} · {side}\nFiyat: <code>{p}</code>\n"
              "❌ Nihai sonuç: <b>{r}R</b>"),
    "ev_be": ("🔶 <b>Başabaşta stop oldu</b> (TP1 sonrası)\n<code>{s}</code> · {tf} · {side}\n"
              "Fiyat: <code>{p}</code>\n✅ Nihai sonuç: <b>{r}R</b>"),
    "ev_tp2stop": ("🔷 <b>TP1 seviyesinde stop oldu</b> (TP2 sonrası)\n<code>{s}</code> · {tf} · {side}\n"
                   "Fiyat: <code>{p}</code>\n✅ Nihai sonuç: <b>{r}R</b>"),
    "ev_flip": ("🔄 <b>Trend döndü — sinyal kapatıldı</b>\n<code>{s}</code> · {tf} · {side}\n"
                "<code>{p}</code> fiyatından kapandı\nNihai sonuç: <b>{r}R</b>"),
    "ev_exp": ("⌛ <b>Sinyal süresi doldu</b> (ne TP ne stop görüldü)\n<code>{s}</code> · {tf} · {side}\n"
               "<code>{p}</code> fiyatından kapandı\nNihai sonuç: <b>{r}R</b>"),
    "b_perf": "📈 Performans", "b_open": "🔓 Açık sinyaller", "b_alerts": "🔔 Fiyat alarmları",
    "b_track": "🎯 TP/SL bildirimi: {v}",
    "perf_head": "📈 <b>Sinyal performansı</b> · {period}",
    "perf_p7": "7 gün", "perf_p30": "30 gün", "perf_pall": "tüm zamanlar",
    "perf_empty": "Bu dönemde henüz kapanmış sinyal yok.",
    "perf_sum": ("✅ Kapanan: <b>{n}</b> · ⏳ Açık: <b>{o}</b>\n🏆 Kazanma oranı: <b>%{win}</b> ({w}K / {l}Z)\n"
                 "📐 Ortalama: <b>{avg}R</b> · Toplam: <b>{tot}R</b>\n⚖️ Kâr faktörü: <b>{pf}</b>"),
    "perf_tf": "⏱ Zaman dilimine göre", "perf_side": "↕️ Yöne göre", "perf_grade": "⭐ Dereceye göre",
    "perf_coins": "🪙 Coine göre",
    "perf_note": ("ℹ️ Simülasyon: giriş mum kapanışında; her TP'de pozisyonun ⅓'ü kapanır; TP1 sonrası stop "
                  "girişe, TP2 sonrası TP1'e çekilir; aynı mumda TP ve stop varsa önce stop çalışmış sayılır. "
                  "1R = stop mesafesi. Gerçek sonuçlar farklı olabilir. Yatırım tavsiyesi değildir."),
    "open_head": "🔓 <b>Açık sinyaller</b>", "open_empty": "Şu an açık sinyal yok.", "st_wait": "henüz TP yok",
    "al_usage": "Kullanım: <code>/alert BTC 70000</code>",
    "al_set": "✅ Alarm kuruldu: <code>{s}</code> {d} <b>{p}</b>",
    "al_hit": "🔔 <b>Fiyat alarmı</b>\n<code>{s}</code> <b>{p}</b> seviyesine ulaştı\n🎯 Hedef: {t}",
    "al_list": "🔔 <b>Fiyat alarmların</b>\nSilmek için ✕'e dokun.",
    "al_empty": "Aktif alarm yok. Ekle: <code>/alert BTC 70000</code>",
    "al_limit": "En fazla {n} alarm kurulabilir.", "al_bad": "❌ Geçersiz parite veya fiyat.",
    "al_now": "❌ Hedef, güncel fiyatla aynı.",
    "bt_usage": "Kullanım: <code>/backtest BTC 1h</code>",
    "bt_head": "🧪 <b>Geriye dönük test</b> · {s} · {tf} · {c} mum",
    "bt_sum": ("🔁 İşlem: <b>{n}</b>\n🏆 Kazanma oranı: <b>%{win}</b> ({w}K / {l}Z)\n"
               "📐 Ortalama: <b>{avg}R</b> · Toplam: <b>{tot}R</b>\n⚖️ Kâr faktörü: <b>{pf}</b>\n"
               "📉 Maks. düşüş: <b>{dd}R</b>"),
    "bt_none": "Bu parite/zaman dilimi için yeterli işlem veya mum yok.",
    "bt_note": ("ℹ️ Canlı takipteki kurallarla, bu zaman dilimindeki mumlar üzerinde simülasyon (mum içindeki "
                "fiyat sırası bilinmez). Geçmiş sonuçlar geleceği garanti etmez."),
    "help": (
        "❓ <b>Nasıl çalışır?</b>\n\n"
        "1) Coin ve zaman dilimlerini seç.\n"
        "2) Bot her mum kapanışında Supertrend'i (ATR 10 × 3) kontrol eder. Trend dönünce MavilimW, EMA 200, "
        "RSI, StochRSI, MACD, ADX, Bollinger, VWAP, hacim, destek/direnç, Fibonacci, formasyonlar ve üst "
        "zaman dilimlerini analiz eder.\n"
        "3) Sinyalde giriş, stop (Supertrend çizgisi), TP1–TP3 (1R/2R/3R), yaklaşık kaldıraç ve 10 üzerinden "
        "puan (A–D derece) bulunur.\n"
        "4) 🎯 Bot her sinyali takip eder; TP1/TP2/TP3 veya stop olunca bildirir. Sonuçlar: /stats\n"
        "5) 🔔 Fiyat alarmı: /alert BTC 70000 · 🧪 Geriye dönük test: /backtest BTC 1h\n\n"
        "⚠️ Yatırım tavsiyesi değildir. Daima stop kullan, işlem başına riskin %1–2'yi geçmesin."
    ),
    "cmds": ("📋 Menü|🪙 Coinlerim|⏱ Zaman dilimleri|💱 Canlı fiyat|🔥 En çok hareket edenler|"
             "🧮 Risk hesaplayıcı|🕘 Sinyal geçmişi|📈 Performans|🔓 Açık sinyaller|🔔 Fiyat alarmları|"
             "🧪 Geriye dönük test|🌐 Dil|💝 Bağış|⚖️ Şartlar|❓ Yardım|🗑 Verilerimi sil"),
    "desc": ("Futures ve Spot için TP/SL takipli kripto sinyalleri. 1m–1M zaman dilimlerinde Supertrend, "
             "MavilimW, RSI, MACD, ADX, hacim ve destek/direnç analizi, fiyat alarmları, geriye dönük test ve "
             "8 dil. Yatırım tavsiyesi değildir."),
    "short_desc": "Kripto sinyalleri · TP/SL takibi · 8 dil",
}

EXT["uk"] = {
    "grade_word": "Оцінка",
    "sec_levels": "📐 <b>Ключові рівні</b>",
    "res": "🧱 Опір", "sup": "🛟 Підтримка",
    "sec_ind": "📊 <b>Індикатори</b>",
    "rsi_ob": "перекупленість", "rsi_os": "перепроданість", "rsi_n": "нейтрально",
    "adx_strong": "сильний тренд", "adx_weak": "слабкий тренд",
    "ind_vol": "Обсяг: {x}× від середнього · покупці {b}%",
    "ind_atr": "Волатильність (ATR): {x}% від ціни",
    "sec_mtf": "🌐 <b>Старші таймфрейми</b>",
    "sec_fut": "💹 <b>Дані ф'ючерсів</b>",
    "fut_line": "Фандинг {f}% · Відкритий інтерес {oi} · Лонг/Шорт {ls}",
    "sec_pat": "🔍 <b>Патерн</b>",
    "pat_dtop": "Подвійна вершина (M)", "pat_dbot": "Подвійне дно (W)",
    "pat_bflag": "Бичачий прапор", "pat_sflag": "Ведмежий прапор",
    "w_sr": "⚠️ Наступний зустрічний рівень лише за {d}% — мало місця до TP1.",
    "w_fund": "⚠️ Фандинг екстремальний у цьому напрямку (перегріта угода).",
    "w_htf": "⚠️ Проти тренду старшого таймфрейму.",
    "w_low": "⚠️ Мало підтверджень — підвищений ризик.",
    "risk_hint": "💼 При ризику 1% депозиту: позиція ≈ {x}× від балансу",
    "fac_vol": "Обсяг",
    "ev_tp1": ("🎯 <b>TP1 досягнуто</b>\n<code>{s}</code> · {tf} · {side}\nЦіна: <code>{p}</code>\n"
               "💰 Зафіксовано: <b>{r}R</b> (закрито ⅓)\n🛡 Стоп перенесено на вхід (беззбитковість)."),
    "ev_tp2": ("🎯🎯 <b>TP2 досягнуто</b>\n<code>{s}</code> · {tf} · {side}\nЦіна: <code>{p}</code>\n"
               "💰 Зафіксовано: <b>{r}R</b> (закрито ⅔)\n🛡 Стоп перенесено на TP1."),
    "ev_tp3": ("🏆 <b>TP3 досягнуто — усі цілі взято!</b>\n<code>{s}</code> · {tf} · {side}\n"
               "Ціна: <code>{p}</code>\n✅ Підсумок: <b>{r}R</b>"),
    "ev_sl": ("🛑 <b>Спрацював стоп-лосс</b>\n<code>{s}</code> · {tf} · {side}\nЦіна: <code>{p}</code>\n"
              "❌ Підсумок: <b>{r}R</b>"),
    "ev_be": ("🔶 <b>Вихід у беззбитку</b> (після TP1)\n<code>{s}</code> · {tf} · {side}\n"
              "Ціна: <code>{p}</code>\n✅ Підсумок: <b>{r}R</b>"),
    "ev_tp2stop": ("🔷 <b>Вихід по стопу на рівні TP1</b> (після TP2)\n<code>{s}</code> · {tf} · {side}\n"
                   "Ціна: <code>{p}</code>\n✅ Підсумок: <b>{r}R</b>"),
    "ev_flip": ("🔄 <b>Тренд розвернувся — сигнал закрито</b>\n<code>{s}</code> · {tf} · {side}\n"
                "Закрито за <code>{p}</code>\nПідсумок: <b>{r}R</b>"),
    "ev_exp": ("⌛ <b>Сигнал застарів</b> (ні TP, ні стоп не досягнуто)\n<code>{s}</code> · {tf} · {side}\n"
               "Закрито за <code>{p}</code>\nПідсумок: <b>{r}R</b>"),
    "b_perf": "📈 Статистика", "b_open": "🔓 Відкриті сигнали", "b_alerts": "🔔 Цінові алерти",
    "b_track": "🎯 Сповіщення TP/SL: {v}",
    "perf_head": "📈 <b>Результати сигналів</b> · {period}",
    "perf_p7": "7 днів", "perf_p30": "30 днів", "perf_pall": "весь час",
    "perf_empty": "За цей період закритих сигналів поки немає.",
    "perf_sum": ("✅ Закрито: <b>{n}</b> · ⏳ Відкрито: <b>{o}</b>\n🏆 Винрейт: <b>{win}%</b> ({w}W / {l}L)\n"
                 "📐 Середній: <b>{avg}R</b> · Усього: <b>{tot}R</b>\n⚖️ Профіт-фактор: <b>{pf}</b>"),
    "perf_tf": "⏱ За таймфреймами", "perf_side": "↕️ За напрямком", "perf_grade": "⭐ За оцінкою",
    "perf_coins": "🪙 За монетами",
    "perf_note": ("ℹ️ Симуляція: вхід на закритті свічки; на кожному TP закривається ⅓ позиції; після TP1 стоп "
                  "переноситься на вхід, після TP2 — на TP1; якщо TP і стоп в одній свічці, вважається, що стоп "
                  "спрацював першим. 1R = відстань до стопу. Реальні результати відрізняються. Не інвестпорада."),
    "open_head": "🔓 <b>Відкриті сигнали</b>", "open_empty": "Зараз немає відкритих сигналів.",
    "st_wait": "TP ще немає",
    "al_usage": "Використання: <code>/alert BTC 70000</code>",
    "al_set": "✅ Алерт створено: <code>{s}</code> {d} <b>{p}</b>",
    "al_hit": "🔔 <b>Ціновий алерт</b>\n<code>{s}</code> досяг <b>{p}</b>\n🎯 Ціль: {t}",
    "al_list": "🔔 <b>Ваші цінові алерти</b>\nНатисніть ✕, щоб видалити.",
    "al_empty": "Активних алертів немає. Додайте: <code>/alert BTC 70000</code>",
    "al_limit": "Максимум алертів: {n}.", "al_bad": "❌ Невірна пара або ціна.",
    "al_now": "❌ Ціль дорівнює поточній ціні.",
    "bt_usage": "Використання: <code>/backtest BTC 1h</code>",
    "bt_head": "🧪 <b>Бектест</b> · {s} · {tf} · {c} свічок",
    "bt_sum": ("🔁 Угод: <b>{n}</b>\n🏆 Винрейт: <b>{win}%</b> ({w}W / {l}L)\n"
               "📐 Середній: <b>{avg}R</b> · Усього: <b>{tot}R</b>\n⚖️ Профіт-фактор: <b>{pf}</b>\n"
               "📉 Макс. просадка: <b>{dd}R</b>"),
    "bt_none": "Недостатньо угод або свічок для цієї пари/таймфрейму.",
    "bt_note": ("ℹ️ Ті самі правила, що й у живому відстеженні, симуляція на свічках цього таймфрейму (порядок "
                "руху ціни всередині свічки невідомий). Минулі результати не гарантують майбутніх."),
    "help": (
        "❓ <b>Як це працює</b>\n\n"
        "1) Оберіть монети та таймфрейми.\n"
        "2) На закритті кожної свічки бот перевіряє Supertrend (ATR 10 × 3). При зміні тренду аналізуються "
        "MavilimW, EMA 200, RSI, StochRSI, MACD, ADX, Bollinger, VWAP, обсяг, підтримка/опір, Фібоначчі, "
        "патерни та старші таймфрейми.\n"
        "3) У сигналі: вхід, стоп (лінія Supertrend), TP1–TP3 (1R/2R/3R), орієнтовне плече та оцінка з 10 "
        "(клас A–D).\n"
        "4) 🎯 Бот відстежує кожен сигнал і повідомляє, коли досягнуто TP1/TP2/TP3 або стоп. "
        "Результати: /stats\n"
        "5) 🔔 Цінові алерти: /alert BTC 70000 · 🧪 Бектест: /backtest BTC 1h\n\n"
        "⚠️ Не інвестиційна порада. Завжди використовуйте стоп-лосс і ризикуйте не більше 1–2% на угоду."
    ),
    "cmds": ("📋 Меню|🪙 Мої монети|⏱ Таймфрейми|💱 Ціна онлайн|🔥 Лідери ринку|🧮 Калькулятор ризику|"
             "🕘 Історія сигналів|📈 Статистика|🔓 Відкриті сигнали|🔔 Цінові алерти|🧪 Бектест|🌐 Мова|"
             "💝 Підтримати|⚖️ Умови|❓ Допомога|🗑 Видалити мої дані"),
    "desc": ("Крипто-сигнали для ф'ючерсів і споту з відстеженням TP/SL. Аналіз Supertrend, MavilimW, RSI, "
             "MACD, ADX, обсягу та рівнів на 1m–1M, цінові алерти, бектест і 8 мов. Не інвестиційна порада."),
    "short_desc": "Крипто-сигнали · Відстеження TP/SL · 8 мов",
}

EXT["de"] = {
    "grade_word": "Note",
    "sec_levels": "📐 <b>Wichtige Marken</b>",
    "res": "🧱 Widerstand", "sup": "🛟 Unterstützung",
    "sec_ind": "📊 <b>Indikatoren</b>",
    "rsi_ob": "überkauft", "rsi_os": "überverkauft", "rsi_n": "neutral",
    "adx_strong": "starker Trend", "adx_weak": "schwacher Trend",
    "ind_vol": "Volumen: {x}× Durchschnitt · Käufer {b}%",
    "ind_atr": "Volatilität (ATR): {x}% des Preises",
    "sec_mtf": "🌐 <b>Höhere Zeitrahmen</b>",
    "sec_fut": "💹 <b>Futures-Daten</b>",
    "fut_line": "Funding {f}% · Open Interest {oi} · Long/Short {ls}",
    "sec_pat": "🔍 <b>Muster</b>",
    "pat_dtop": "Doppeltop (M)", "pat_dbot": "Doppelboden (W)",
    "pat_bflag": "Bullische Flagge", "pat_sflag": "Bärische Flagge",
    "w_sr": "⚠️ Die nächste Gegenmarke ist nur {d}% entfernt — wenig Platz bis TP1.",
    "w_fund": "⚠️ Funding ist in dieser Richtung extrem (überfüllter Trade).",
    "w_htf": "⚠️ Gegen den Trend des höheren Zeitrahmens.",
    "w_low": "⚠️ Wenige Bestätigungen — höheres Risiko.",
    "risk_hint": "💼 Bei 1 % Kontorisiko: Position ≈ {x}× Guthaben",
    "fac_vol": "Volumen",
    "ev_tp1": ("🎯 <b>TP1 erreicht</b>\n<code>{s}</code> · {tf} · {side}\nPreis: <code>{p}</code>\n"
               "💰 Gesichert: <b>{r}R</b> (⅓ geschlossen)\n🛡 Stop auf Einstieg gezogen (Breakeven)."),
    "ev_tp2": ("🎯🎯 <b>TP2 erreicht</b>\n<code>{s}</code> · {tf} · {side}\nPreis: <code>{p}</code>\n"
               "💰 Gesichert: <b>{r}R</b> (⅔ geschlossen)\n🛡 Stop auf TP1 gezogen."),
    "ev_tp3": ("🏆 <b>TP3 erreicht — alle Ziele getroffen!</b>\n<code>{s}</code> · {tf} · {side}\n"
               "Preis: <code>{p}</code>\n✅ Endergebnis: <b>{r}R</b>"),
    "ev_sl": ("🛑 <b>Stop-Loss ausgelöst</b>\n<code>{s}</code> · {tf} · {side}\nPreis: <code>{p}</code>\n"
              "❌ Endergebnis: <b>{r}R</b>"),
    "ev_be": ("🔶 <b>Bei Breakeven ausgestoppt</b> (nach TP1)\n<code>{s}</code> · {tf} · {side}\n"
              "Preis: <code>{p}</code>\n✅ Endergebnis: <b>{r}R</b>"),
    "ev_tp2stop": ("🔷 <b>Auf TP1-Niveau ausgestoppt</b> (nach TP2)\n<code>{s}</code> · {tf} · {side}\n"
                   "Preis: <code>{p}</code>\n✅ Endergebnis: <b>{r}R</b>"),
    "ev_flip": ("🔄 <b>Trend gedreht — Signal geschlossen</b>\n<code>{s}</code> · {tf} · {side}\n"
                "Geschlossen bei <code>{p}</code>\nEndergebnis: <b>{r}R</b>"),
    "ev_exp": ("⌛ <b>Signal abgelaufen</b> (weder TP noch Stop erreicht)\n<code>{s}</code> · {tf} · {side}\n"
               "Geschlossen bei <code>{p}</code>\nEndergebnis: <b>{r}R</b>"),
    "b_perf": "📈 Statistik", "b_open": "🔓 Offene Signale", "b_alerts": "🔔 Preisalarme",
    "b_track": "🎯 TP/SL-Meldungen: {v}",
    "perf_head": "📈 <b>Signal-Performance</b> · {period}",
    "perf_p7": "7 Tage", "perf_p30": "30 Tage", "perf_pall": "gesamt",
    "perf_empty": "In diesem Zeitraum gibt es noch keine geschlossenen Signale.",
    "perf_sum": ("✅ Geschlossen: <b>{n}</b> · ⏳ Offen: <b>{o}</b>\n🏆 Trefferquote: <b>{win}%</b> ({w}G / {l}V)\n"
                 "📐 Durchschnitt: <b>{avg}R</b> · Summe: <b>{tot}R</b>\n⚖️ Profitfaktor: <b>{pf}</b>"),
    "perf_tf": "⏱ Nach Zeitrahmen", "perf_side": "↕️ Nach Richtung", "perf_grade": "⭐ Nach Note",
    "perf_coins": "🪙 Nach Coin",
    "perf_note": ("ℹ️ Simulation: Einstieg zum Kerzenschluss; bei jedem TP werden ⅓ der Position geschlossen; "
                  "nach TP1 wandert der Stop auf den Einstieg, nach TP2 auf TP1; liegen TP und Stop in einer "
                  "Kerze, gilt der Stop als zuerst ausgelöst. 1R = Abstand zum Stop. Reale Ergebnisse weichen "
                  "ab. Keine Anlageberatung."),
    "open_head": "🔓 <b>Offene Signale</b>", "open_empty": "Derzeit keine offenen Signale.",
    "st_wait": "noch kein TP",
    "al_usage": "Nutzung: <code>/alert BTC 70000</code>",
    "al_set": "✅ Alarm gesetzt: <code>{s}</code> {d} <b>{p}</b>",
    "al_hit": "🔔 <b>Preisalarm</b>\n<code>{s}</code> hat <b>{p}</b> erreicht\n🎯 Ziel: {t}",
    "al_list": "🔔 <b>Ihre Preisalarme</b>\nMit ✕ löschen.",
    "al_empty": "Keine aktiven Alarme. Hinzufügen: <code>/alert BTC 70000</code>",
    "al_limit": "Maximal {n} Alarme.", "al_bad": "❌ Ungültiges Paar oder ungültiger Preis.",
    "al_now": "❌ Das Ziel entspricht dem aktuellen Preis.",
    "bt_usage": "Nutzung: <code>/backtest BTC 1h</code>",
    "bt_head": "🧪 <b>Backtest</b> · {s} · {tf} · {c} Kerzen",
    "bt_sum": ("🔁 Trades: <b>{n}</b>\n🏆 Trefferquote: <b>{win}%</b> ({w}G / {l}V)\n"
               "📐 Durchschnitt: <b>{avg}R</b> · Summe: <b>{tot}R</b>\n⚖️ Profitfaktor: <b>{pf}</b>\n"
               "📉 Max. Drawdown: <b>{dd}R</b>"),
    "bt_none": "Zu wenige Trades oder Kerzen für dieses Paar/diesen Zeitrahmen.",
    "bt_note": ("ℹ️ Gleiche Regeln wie beim Live-Tracking, simuliert auf Kerzen dieses Zeitrahmens (die "
                "Reihenfolge der Kursbewegung innerhalb einer Kerze ist unbekannt). Vergangene Ergebnisse "
                "sind keine Garantie für die Zukunft."),
    "help": (
        "❓ <b>So funktioniert es</b>\n\n"
        "1) Wählen Sie Coins und Zeitrahmen.\n"
        "2) Bei jedem Kerzenschluss prüft der Bot Supertrend (ATR 10 × 3). Bei einem Trendwechsel analysiert "
        "er MavilimW, EMA 200, RSI, StochRSI, MACD, ADX, Bollinger, VWAP, Volumen, Unterstützung/Widerstand, "
        "Fibonacci, Muster und höhere Zeitrahmen.\n"
        "3) Das Signal zeigt Einstieg, Stop (Supertrend-Linie), TP1–TP3 (1R/2R/3R), Richtwert für den Hebel "
        "und eine Punktzahl von 10 (Note A–D).\n"
        "4) 🎯 Der Bot verfolgt jedes Signal und meldet, wenn TP1/TP2/TP3 oder der Stop erreicht wird. "
        "Ergebnisse: /stats\n"
        "5) 🔔 Preisalarme: /alert BTC 70000 · 🧪 Backtest: /backtest BTC 1h\n\n"
        "⚠️ Keine Anlageberatung. Immer Stop-Loss nutzen und höchstens 1–2 % pro Trade riskieren."
    ),
    "cmds": ("📋 Menü|🪙 Meine Coins|⏱ Zeitrahmen|💱 Live-Preis|🔥 Top-Bewegungen|🧮 Risikorechner|"
             "🕘 Signalverlauf|📈 Statistik|🔓 Offene Signale|🔔 Preisalarme|🧪 Backtest|🌐 Sprache|"
             "💝 Spenden|⚖️ Bedingungen|❓ Hilfe|🗑 Meine Daten löschen"),
    "desc": ("Krypto-Signale für Futures & Spot mit TP/SL-Verfolgung. Analyse mit Supertrend, MavilimW, RSI, "
             "MACD, ADX, Volumen und Marken auf 1m–1M, Preisalarme, Backtests und 8 Sprachen. "
             "Keine Anlageberatung."),
    "short_desc": "Krypto-Signale · TP/SL-Verfolgung · 8 Sprachen",
}

EXT["es"] = {
    "grade_word": "Nota",
    "sec_levels": "📐 <b>Niveles clave</b>",
    "res": "🧱 Resistencia", "sup": "🛟 Soporte",
    "sec_ind": "📊 <b>Indicadores</b>",
    "rsi_ob": "sobrecompra", "rsi_os": "sobreventa", "rsi_n": "neutral",
    "adx_strong": "tendencia fuerte", "adx_weak": "tendencia débil",
    "ind_vol": "Volumen: {x}× la media · compradores {b}%",
    "ind_atr": "Volatilidad (ATR): {x}% del precio",
    "sec_mtf": "🌐 <b>Marcos temporales superiores</b>",
    "sec_fut": "💹 <b>Datos de futuros</b>",
    "fut_line": "Funding {f}% · Interés abierto {oi} · Long/Short {ls}",
    "sec_pat": "🔍 <b>Patrón</b>",
    "pat_dtop": "Doble techo (M)", "pat_dbot": "Doble suelo (W)",
    "pat_bflag": "Bandera alcista", "pat_sflag": "Bandera bajista",
    "w_sr": "⚠️ El siguiente nivel contrario está a solo {d}% — poco margen hasta TP1.",
    "w_fund": "⚠️ El funding es extremo en esta dirección (operación saturada).",
    "w_htf": "⚠️ Contra la tendencia del marco superior.",
    "w_low": "⚠️ Pocas confirmaciones — mayor riesgo.",
    "risk_hint": "💼 Para arriesgar el 1 % de la cuenta: posición ≈ {x}× el saldo",
    "fac_vol": "Volumen",
    "ev_tp1": ("🎯 <b>TP1 alcanzado</b>\n<code>{s}</code> · {tf} · {side}\nPrecio: <code>{p}</code>\n"
               "💰 Asegurado: <b>{r}R</b> (⅓ cerrado)\n🛡 Stop movido a la entrada (breakeven)."),
    "ev_tp2": ("🎯🎯 <b>TP2 alcanzado</b>\n<code>{s}</code> · {tf} · {side}\nPrecio: <code>{p}</code>\n"
               "💰 Asegurado: <b>{r}R</b> (⅔ cerrado)\n🛡 Stop movido a TP1."),
    "ev_tp3": ("🏆 <b>TP3 alcanzado — ¡todos los objetivos!</b>\n<code>{s}</code> · {tf} · {side}\n"
               "Precio: <code>{p}</code>\n✅ Resultado final: <b>{r}R</b>"),
    "ev_sl": ("🛑 <b>Stop-loss activado</b>\n<code>{s}</code> · {tf} · {side}\nPrecio: <code>{p}</code>\n"
              "❌ Resultado final: <b>{r}R</b>"),
    "ev_be": ("🔶 <b>Salida en breakeven</b> (tras TP1)\n<code>{s}</code> · {tf} · {side}\n"
              "Precio: <code>{p}</code>\n✅ Resultado final: <b>{r}R</b>"),
    "ev_tp2stop": ("🔷 <b>Salida en el nivel de TP1</b> (tras TP2)\n<code>{s}</code> · {tf} · {side}\n"
                   "Precio: <code>{p}</code>\n✅ Resultado final: <b>{r}R</b>"),
    "ev_flip": ("🔄 <b>Tendencia invertida — señal cerrada</b>\n<code>{s}</code> · {tf} · {side}\n"
                "Cerrada en <code>{p}</code>\nResultado final: <b>{r}R</b>"),
    "ev_exp": ("⌛ <b>Señal caducada</b> (sin TP ni stop)\n<code>{s}</code> · {tf} · {side}\n"
               "Cerrada en <code>{p}</code>\nResultado final: <b>{r}R</b>"),
    "b_perf": "📈 Estadísticas", "b_open": "🔓 Señales abiertas", "b_alerts": "🔔 Alertas de precio",
    "b_track": "🎯 Avisos TP/SL: {v}",
    "perf_head": "📈 <b>Rendimiento de las señales</b> · {period}",
    "perf_p7": "7 días", "perf_p30": "30 días", "perf_pall": "todo el tiempo",
    "perf_empty": "Aún no hay señales cerradas en este periodo.",
    "perf_sum": ("✅ Cerradas: <b>{n}</b> · ⏳ Abiertas: <b>{o}</b>\n🏆 Acierto: <b>{win}%</b> ({w}G / {l}P)\n"
                 "📐 Media: <b>{avg}R</b> · Total: <b>{tot}R</b>\n⚖️ Factor de beneficio: <b>{pf}</b>"),
    "perf_tf": "⏱ Por marco temporal", "perf_side": "↕️ Por dirección", "perf_grade": "⭐ Por nota",
    "perf_coins": "🪙 Por moneda",
    "perf_note": ("ℹ️ Simulación: entrada al cierre de la vela; en cada TP se cierra ⅓ de la posición; tras TP1 "
                  "el stop pasa a la entrada y tras TP2 a TP1; si TP y stop caen en la misma vela se asume "
                  "que el stop saltó primero. 1R = distancia al stop. Los resultados reales difieren. No es "
                  "asesoramiento de inversión."),
    "open_head": "🔓 <b>Señales abiertas</b>", "open_empty": "Ahora no hay señales abiertas.",
    "st_wait": "aún sin TP",
    "al_usage": "Uso: <code>/alert BTC 70000</code>",
    "al_set": "✅ Alerta creada: <code>{s}</code> {d} <b>{p}</b>",
    "al_hit": "🔔 <b>Alerta de precio</b>\n<code>{s}</code> alcanzó <b>{p}</b>\n🎯 Objetivo: {t}",
    "al_list": "🔔 <b>Sus alertas de precio</b>\nToque ✕ para borrar.",
    "al_empty": "No hay alertas activas. Añada una: <code>/alert BTC 70000</code>",
    "al_limit": "Máximo {n} alertas.", "al_bad": "❌ Par o precio no válido.",
    "al_now": "❌ El objetivo es igual al precio actual.",
    "bt_usage": "Uso: <code>/backtest BTC 1h</code>",
    "bt_head": "🧪 <b>Backtest</b> · {s} · {tf} · {c} velas",
    "bt_sum": ("🔁 Operaciones: <b>{n}</b>\n🏆 Acierto: <b>{win}%</b> ({w}G / {l}P)\n"
               "📐 Media: <b>{avg}R</b> · Total: <b>{tot}R</b>\n⚖️ Factor de beneficio: <b>{pf}</b>\n"
               "📉 Drawdown máx.: <b>{dd}R</b>"),
    "bt_none": "No hay suficientes operaciones o velas para este par/marco temporal.",
    "bt_note": ("ℹ️ Mismas reglas que el seguimiento en vivo, simuladas con velas de este marco temporal (se "
                "desconoce el orden del precio dentro de la vela). Los resultados pasados no garantizan "
                "resultados futuros."),
    "help": (
        "❓ <b>Cómo funciona</b>\n\n"
        "1) Elija monedas y marcos temporales.\n"
        "2) En cada cierre de vela el bot revisa Supertrend (ATR 10 × 3). Si la tendencia cambia, analiza "
        "MavilimW, EMA 200, RSI, StochRSI, MACD, ADX, Bollinger, VWAP, volumen, soportes/resistencias, "
        "Fibonacci, patrones y marcos superiores.\n"
        "3) La señal muestra entrada, stop (línea Supertrend), TP1–TP3 (1R/2R/3R), apalancamiento orientativo "
        "y una puntuación sobre 10 (nota A–D).\n"
        "4) 🎯 El bot sigue cada señal y le avisa cuando se alcanza TP1/TP2/TP3 o el stop. "
        "Resultados: /stats\n"
        "5) 🔔 Alertas de precio: /alert BTC 70000 · 🧪 Backtest: /backtest BTC 1h\n\n"
        "⚠️ No es asesoramiento de inversión. Use siempre stop-loss y arriesgue como máximo 1–2 % por operación."
    ),
    "cmds": ("📋 Menú|🪙 Mis monedas|⏱ Marcos temporales|💱 Precio en vivo|🔥 Mayores movimientos|"
             "🧮 Calculadora de riesgo|🕘 Historial de señales|📈 Estadísticas|🔓 Señales abiertas|"
             "🔔 Alertas de precio|🧪 Backtest|🌐 Idioma|💝 Donar|⚖️ Términos|❓ Ayuda|🗑 Borrar mis datos"),
    "desc": ("Señales cripto para Futuros y Spot con seguimiento de TP/SL. Análisis con Supertrend, MavilimW, "
             "RSI, MACD, ADX, volumen y niveles en 1m–1M, alertas de precio, backtests y 8 idiomas. "
             "No es asesoramiento."),
    "short_desc": "Señales cripto · Seguimiento TP/SL · 8 idiomas",
}

EXT["fr"] = {
    "grade_word": "Note",
    "sec_levels": "📐 <b>Niveaux clés</b>",
    "res": "🧱 Résistance", "sup": "🛟 Support",
    "sec_ind": "📊 <b>Indicateurs</b>",
    "rsi_ob": "surachat", "rsi_os": "survente", "rsi_n": "neutre",
    "adx_strong": "tendance forte", "adx_weak": "tendance faible",
    "ind_vol": "Volume : {x}× la moyenne · acheteurs {b}%",
    "ind_atr": "Volatilité (ATR) : {x}% du prix",
    "sec_mtf": "🌐 <b>Unités de temps supérieures</b>",
    "sec_fut": "💹 <b>Données futures</b>",
    "fut_line": "Funding {f}% · Intérêt ouvert {oi} · Long/Short {ls}",
    "sec_pat": "🔍 <b>Figure</b>",
    "pat_dtop": "Double sommet (M)", "pat_dbot": "Double creux (W)",
    "pat_bflag": "Drapeau haussier", "pat_sflag": "Drapeau baissier",
    "w_sr": "⚠️ Le prochain niveau opposé n'est qu'à {d}% — peu de marge jusqu'au TP1.",
    "w_fund": "⚠️ Le funding est extrême dans ce sens (trade encombré).",
    "w_htf": "⚠️ Contre la tendance de l'unité de temps supérieure.",
    "w_low": "⚠️ Peu de confirmations — risque élevé.",
    "risk_hint": "💼 Pour risquer 1 % du compte : position ≈ {x}× le solde",
    "fac_vol": "Volume",
    "ev_tp1": ("🎯 <b>TP1 atteint</b>\n<code>{s}</code> · {tf} · {side}\nPrix : <code>{p}</code>\n"
               "💰 Sécurisé : <b>{r}R</b> (⅓ clôturé)\n🛡 Stop déplacé à l'entrée (breakeven)."),
    "ev_tp2": ("🎯🎯 <b>TP2 atteint</b>\n<code>{s}</code> · {tf} · {side}\nPrix : <code>{p}</code>\n"
               "💰 Sécurisé : <b>{r}R</b> (⅔ clôturé)\n🛡 Stop déplacé au TP1."),
    "ev_tp3": ("🏆 <b>TP3 atteint — tous les objectifs !</b>\n<code>{s}</code> · {tf} · {side}\n"
               "Prix : <code>{p}</code>\n✅ Résultat final : <b>{r}R</b>"),
    "ev_sl": ("🛑 <b>Stop-loss touché</b>\n<code>{s}</code> · {tf} · {side}\nPrix : <code>{p}</code>\n"
              "❌ Résultat final : <b>{r}R</b>"),
    "ev_be": ("🔶 <b>Sorti au breakeven</b> (après TP1)\n<code>{s}</code> · {tf} · {side}\n"
              "Prix : <code>{p}</code>\n✅ Résultat final : <b>{r}R</b>"),
    "ev_tp2stop": ("🔷 <b>Sorti au niveau du TP1</b> (après TP2)\n<code>{s}</code> · {tf} · {side}\n"
                   "Prix : <code>{p}</code>\n✅ Résultat final : <b>{r}R</b>"),
    "ev_flip": ("🔄 <b>Tendance inversée — signal clôturé</b>\n<code>{s}</code> · {tf} · {side}\n"
                "Clôturé à <code>{p}</code>\nRésultat final : <b>{r}R</b>"),
    "ev_exp": ("⌛ <b>Signal expiré</b> (ni TP ni stop atteint)\n<code>{s}</code> · {tf} · {side}\n"
               "Clôturé à <code>{p}</code>\nRésultat final : <b>{r}R</b>"),
    "b_perf": "📈 Statistiques", "b_open": "🔓 Signaux ouverts", "b_alerts": "🔔 Alertes de prix",
    "b_track": "🎯 Alertes TP/SL : {v}",
    "perf_head": "📈 <b>Performance des signaux</b> · {period}",
    "perf_p7": "7 jours", "perf_p30": "30 jours", "perf_pall": "depuis le début",
    "perf_empty": "Aucun signal clôturé sur cette période pour l'instant.",
    "perf_sum": ("✅ Clôturés : <b>{n}</b> · ⏳ Ouverts : <b>{o}</b>\n🏆 Taux de réussite : <b>{win}%</b> "
                 "({w}G / {l}P)\n📐 Moyenne : <b>{avg}R</b> · Total : <b>{tot}R</b>\n"
                 "⚖️ Facteur de profit : <b>{pf}</b>"),
    "perf_tf": "⏱ Par unité de temps", "perf_side": "↕️ Par direction", "perf_grade": "⭐ Par note",
    "perf_coins": "🪙 Par coin",
    "perf_note": ("ℹ️ Simulation : entrée à la clôture de la bougie ; ⅓ de la position est clôturé à chaque TP ; "
                  "après le TP1 le stop passe à l'entrée, après le TP2 au TP1 ; si un TP et le stop sont dans "
                  "la même bougie, le stop est supposé touché en premier. 1R = distance au stop. Les résultats "
                  "réels diffèrent. Pas un conseil en investissement."),
    "open_head": "🔓 <b>Signaux ouverts</b>", "open_empty": "Aucun signal ouvert pour le moment.",
    "st_wait": "pas encore de TP",
    "al_usage": "Usage : <code>/alert BTC 70000</code>",
    "al_set": "✅ Alerte créée : <code>{s}</code> {d} <b>{p}</b>",
    "al_hit": "🔔 <b>Alerte de prix</b>\n<code>{s}</code> a atteint <b>{p}</b>\n🎯 Cible : {t}",
    "al_list": "🔔 <b>Vos alertes de prix</b>\nAppuyez sur ✕ pour supprimer.",
    "al_empty": "Aucune alerte active. Ajoutez-en une : <code>/alert BTC 70000</code>",
    "al_limit": "Maximum {n} alertes.", "al_bad": "❌ Paire ou prix invalide.",
    "al_now": "❌ La cible est égale au prix actuel.",
    "bt_usage": "Usage : <code>/backtest BTC 1h</code>",
    "bt_head": "🧪 <b>Backtest</b> · {s} · {tf} · {c} bougies",
    "bt_sum": ("🔁 Trades : <b>{n}</b>\n🏆 Taux de réussite : <b>{win}%</b> ({w}G / {l}P)\n"
               "📐 Moyenne : <b>{avg}R</b> · Total : <b>{tot}R</b>\n⚖️ Facteur de profit : <b>{pf}</b>\n"
               "📉 Drawdown max : <b>{dd}R</b>"),
    "bt_none": "Pas assez de trades ou de bougies pour cette paire/unité de temps.",
    "bt_note": ("ℹ️ Mêmes règles que le suivi en direct, simulées sur les bougies de cette unité de temps "
                "(l'ordre des mouvements dans une bougie est inconnu). Les performances passées ne "
                "garantissent pas les résultats futurs."),
    "help": (
        "❓ <b>Comment ça marche</b>\n\n"
        "1) Choisissez vos coins et unités de temps.\n"
        "2) À chaque clôture de bougie, le bot vérifie Supertrend (ATR 10 × 3). Lors d'un retournement, il "
        "analyse MavilimW, EMA 200, RSI, StochRSI, MACD, ADX, Bollinger, VWAP, volume, supports/résistances, "
        "Fibonacci, figures et unités de temps supérieures.\n"
        "3) Le signal indique entrée, stop (ligne Supertrend), TP1–TP3 (1R/2R/3R), levier indicatif et un "
        "score sur 10 (note A–D).\n"
        "4) 🎯 Le bot suit chaque signal et vous alerte quand TP1/TP2/TP3 ou le stop est touché. "
        "Résultats : /stats\n"
        "5) 🔔 Alertes de prix : /alert BTC 70000 · 🧪 Backtest : /backtest BTC 1h\n\n"
        "⚠️ Pas un conseil en investissement. Utilisez toujours un stop-loss et risquez 1–2 % maximum par trade."
    ),
    "cmds": ("📋 Menu|🪙 Mes coins|⏱ Unités de temps|💱 Prix en direct|🔥 Plus gros mouvements|"
             "🧮 Calculateur de risque|🕘 Historique des signaux|📈 Statistiques|🔓 Signaux ouverts|"
             "🔔 Alertes de prix|🧪 Backtest|🌐 Langue|💝 Faire un don|⚖️ Conditions|❓ Aide|"
             "🗑 Supprimer mes données"),
    "desc": ("Signaux crypto Futures et Spot avec suivi TP/SL. Analyse Supertrend, MavilimW, RSI, MACD, ADX, "
             "volume et niveaux en 1m–1M, alertes de prix, backtests et 8 langues. "
             "Pas un conseil en investissement."),
    "short_desc": "Signaux crypto · Suivi TP/SL · 8 langues",
}

EXT["ar"] = {
    "grade_word": "التقييم",
    "sec_levels": "📐 <b>المستويات الرئيسية</b>",
    "res": "🧱 المقاومة", "sup": "🛟 الدعم",
    "sec_ind": "📊 <b>المؤشرات</b>",
    "rsi_ob": "تشبع شرائي", "rsi_os": "تشبع بيعي", "rsi_n": "محايد",
    "adx_strong": "اتجاه قوي", "adx_weak": "اتجاه ضعيف",
    "ind_vol": "الحجم: {x}× المتوسط · المشترون {b}%",
    "ind_atr": "التذبذب (ATR): {x}% من السعر",
    "sec_mtf": "🌐 <b>الأطر الزمنية الأعلى</b>",
    "sec_fut": "💹 <b>بيانات العقود الآجلة</b>",
    "fut_line": "التمويل {f}% · الفائدة المفتوحة {oi} · لونغ/شورت {ls}",
    "sec_pat": "🔍 <b>النموذج</b>",
    "pat_dtop": "قمة مزدوجة (M)", "pat_dbot": "قاع مزدوج (W)",
    "pat_bflag": "علم صاعد", "pat_sflag": "علم هابط",
    "w_sr": "⚠️ المستوى المعاكس التالي يبعد {d}% فقط — مساحة قليلة حتى TP1.",
    "w_fund": "⚠️ التمويل متطرف في هذا الاتجاه (صفقة مزدحمة).",
    "w_htf": "⚠️ عكس اتجاه الإطار الزمني الأعلى.",
    "w_low": "⚠️ تأكيدات قليلة — مخاطرة أعلى.",
    "risk_hint": "💼 لمخاطرة 1% من الحساب: حجم المركز ≈ {x}× الرصيد",
    "fac_vol": "الحجم",
    "ev_tp1": ("🎯 <b>تم الوصول إلى TP1</b>\n<code>{s}</code> · {tf} · {side}\nالسعر: <code>{p}</code>\n"
               "💰 المحقق: <b>{r}R</b> (أُغلق ⅓)\n🛡 نُقل الوقف إلى الدخول (تعادل)."),
    "ev_tp2": ("🎯🎯 <b>تم الوصول إلى TP2</b>\n<code>{s}</code> · {tf} · {side}\nالسعر: <code>{p}</code>\n"
               "💰 المحقق: <b>{r}R</b> (أُغلق ⅔)\n🛡 نُقل الوقف إلى TP1."),
    "ev_tp3": ("🏆 <b>تم الوصول إلى TP3 — كل الأهداف!</b>\n<code>{s}</code> · {tf} · {side}\n"
               "السعر: <code>{p}</code>\n✅ النتيجة النهائية: <b>{r}R</b>"),
    "ev_sl": ("🛑 <b>تم تفعيل وقف الخسارة</b>\n<code>{s}</code> · {tf} · {side}\nالسعر: <code>{p}</code>\n"
              "❌ النتيجة النهائية: <b>{r}R</b>"),
    "ev_be": ("🔶 <b>خروج عند التعادل</b> (بعد TP1)\n<code>{s}</code> · {tf} · {side}\n"
              "السعر: <code>{p}</code>\n✅ النتيجة النهائية: <b>{r}R</b>"),
    "ev_tp2stop": ("🔷 <b>خروج عند مستوى TP1</b> (بعد TP2)\n<code>{s}</code> · {tf} · {side}\n"
                   "السعر: <code>{p}</code>\n✅ النتيجة النهائية: <b>{r}R</b>"),
    "ev_flip": ("🔄 <b>انعكس الاتجاه — أُغلقت الإشارة</b>\n<code>{s}</code> · {tf} · {side}\n"
                "أُغلقت عند <code>{p}</code>\nالنتيجة النهائية: <b>{r}R</b>"),
    "ev_exp": ("⌛ <b>انتهت صلاحية الإشارة</b> (لم يُصَب TP ولا الوقف)\n<code>{s}</code> · {tf} · {side}\n"
               "أُغلقت عند <code>{p}</code>\nالنتيجة النهائية: <b>{r}R</b>"),
    "b_perf": "📈 الإحصائيات", "b_open": "🔓 الإشارات المفتوحة", "b_alerts": "🔔 تنبيهات الأسعار",
    "b_track": "🎯 تنبيهات TP/SL: {v}",
    "perf_head": "📈 <b>أداء الإشارات</b> · {period}",
    "perf_p7": "7 أيام", "perf_p30": "30 يومًا", "perf_pall": "كل الفترات",
    "perf_empty": "لا توجد إشارات مغلقة في هذه الفترة بعد.",
    "perf_sum": ("✅ المغلقة: <b>{n}</b> · ⏳ المفتوحة: <b>{o}</b>\n🏆 نسبة الربح: <b>{win}%</b> "
                 "({w} ربح / {l} خسارة)\n📐 المتوسط: <b>{avg}R</b> · الإجمالي: <b>{tot}R</b>\n"
                 "⚖️ عامل الربح: <b>{pf}</b>"),
    "perf_tf": "⏱ حسب الإطار الزمني", "perf_side": "↕️ حسب الاتجاه", "perf_grade": "⭐ حسب التقييم",
    "perf_coins": "🪙 حسب العملة",
    "perf_note": ("ℹ️ محاكاة: الدخول عند إغلاق الشمعة؛ يُغلق ⅓ المركز عند كل هدف؛ ينتقل الوقف إلى الدخول بعد "
                  "TP1 وإلى TP1 بعد TP2؛ وإذا وقع الهدف والوقف في شمعة واحدة يُفترض أن الوقف تحقق أولًا. "
                  "1R = المسافة إلى الوقف. النتائج الفعلية تختلف. ليست نصيحة استثمارية."),
    "open_head": "🔓 <b>الإشارات المفتوحة</b>", "open_empty": "لا توجد إشارات مفتوحة حاليًا.",
    "st_wait": "لا هدف بعد",
    "al_usage": "الاستخدام: <code>/alert BTC 70000</code>",
    "al_set": "✅ تم ضبط التنبيه: <code>{s}</code> {d} <b>{p}</b>",
    "al_hit": "🔔 <b>تنبيه سعر</b>\nوصل <code>{s}</code> إلى <b>{p}</b>\n🎯 الهدف: {t}",
    "al_list": "🔔 <b>تنبيهات أسعارك</b>\nاضغط ✕ للحذف.",
    "al_empty": "لا توجد تنبيهات نشطة. أضف واحدًا: <code>/alert BTC 70000</code>",
    "al_limit": "الحد الأقصى {n} تنبيهًا.", "al_bad": "❌ زوج أو سعر غير صالح.",
    "al_now": "❌ الهدف يساوي السعر الحالي.",
    "bt_usage": "الاستخدام: <code>/backtest BTC 1h</code>",
    "bt_head": "🧪 <b>اختبار تاريخي</b> · {s} · {tf} · {c} شمعة",
    "bt_sum": ("🔁 الصفقات: <b>{n}</b>\n🏆 نسبة الربح: <b>{win}%</b> ({w} ربح / {l} خسارة)\n"
               "📐 المتوسط: <b>{avg}R</b> · الإجمالي: <b>{tot}R</b>\n⚖️ عامل الربح: <b>{pf}</b>\n"
               "📉 أقصى تراجع: <b>{dd}R</b>"),
    "bt_none": "لا توجد صفقات أو شموع كافية لهذا الزوج/الإطار الزمني.",
    "bt_note": ("ℹ️ نفس قواعد التتبع المباشر، محاكاة على شموع هذا الإطار الزمني (ترتيب حركة السعر داخل "
                "الشمعة غير معروف). النتائج السابقة لا تضمن النتائج المستقبلية."),
    "help": (
        "❓ <b>كيف يعمل</b>\n\n"
        "1) اختر العملات والأطر الزمنية.\n"
        "2) عند إغلاق كل شمعة يفحص البوت Supertrend (ATR 10 × 3). عند انعكاس الاتجاه يحلل MavilimW وEMA 200 "
        "وRSI وStochRSI وMACD وADX وBollinger وVWAP والحجم والدعم/المقاومة وفيبوناتشي والنماذج والأطر "
        "الزمنية الأعلى.\n"
        "3) تعرض الإشارة الدخول والوقف (خط Supertrend) والأهداف TP1–TP3 (1R/2R/3R) ورافعة إرشادية "
        "ودرجة من 10 (تقييم A–D).\n"
        "4) 🎯 يتتبع البوت كل إشارة وينبهك عند بلوغ TP1/TP2/TP3 أو الوقف. النتائج: /stats\n"
        "5) 🔔 تنبيهات الأسعار: /alert BTC 70000 · 🧪 اختبار تاريخي: /backtest BTC 1h\n\n"
        "⚠️ ليست نصيحة استثمارية. استخدم دائمًا وقف الخسارة ولا تخاطر بأكثر من 1–2% في الصفقة."
    ),
    "cmds": ("📋 القائمة|🪙 عملاتي|⏱ الأطر الزمنية|💱 السعر المباشر|🔥 الأكثر تحركًا|🧮 حاسبة المخاطر|"
             "🕘 سجل الإشارات|📈 الإحصائيات|🔓 الإشارات المفتوحة|🔔 تنبيهات الأسعار|🧪 اختبار تاريخي|"
             "🌐 اللغة|💝 تبرع|⚖️ الشروط|❓ مساعدة|🗑 حذف بياناتي"),
    "desc": ("إشارات العملات الرقمية للعقود الآجلة والفوري مع تتبع TP/SL. تحليل Supertrend وMavilimW وRSI "
             "وMACD وADX والحجم والمستويات على أطر 1m–1M، تنبيهات أسعار واختبار تاريخي و8 لغات. "
             "ليست نصيحة استثمارية."),
    "short_desc": "إشارات العملات الرقمية · تتبع TP/SL · 8 لغات",
}
