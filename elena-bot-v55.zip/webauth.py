"""Telegram WebApp initData doğrulaması — bağımsız modül (aiohttp'ye bağlı değil, testi kolay).

GÜVENLİK: Bu dosya, mini app'in kimlik doğrulamasının kalbidir. Tarayıcıdan gelen hiçbir alana
(chat_id, kullanıcı adı, is_admin iddiası) bu imza doğrulanmadan güvenilmez.
"""
import hashlib
import hmac
import json
import time
from urllib.parse import parse_qsl


def verify_init_data(init_data, bot_token, max_age=86400):
    """Telegram WebApp initData'sını doğrular. Geçerliyse {"user": dict, "auth_date": int} döner, değilse None.
    Algoritma Telegram'ın resmi dokümantasyonundaki gibidir:
      data_check_string = sorted("key=value") satırları "\\n" ile birleştirilmiş (hash hariç)
      secret_key = HMAC_SHA256(key=b"WebAppData", msg=bot_token)
      hash = HMAC_SHA256(key=secret_key, msg=data_check_string) hex
    """
    if not init_data or not bot_token:
        return None
    try:
        pairs = dict(parse_qsl(init_data, strict_parsing=True))
    except ValueError:
        return None
    received_hash = pairs.pop("hash", None)
    if not received_hash:
        return None
    check_str = "\n".join(f"{k}={v}" for k, v in sorted(pairs.items()))
    secret = hmac.new(b"WebAppData", bot_token.encode(), hashlib.sha256).digest()
    calc_hash = hmac.new(secret, check_str.encode(), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(calc_hash, received_hash):
        return None
    try:
        auth_date = int(pairs.get("auth_date", 0))
    except ValueError:
        return None
    if max_age and time.time() - auth_date > max_age:
        return None  # çok eski initData (biri linki kaydedip sonra tekrar kullanmaya çalışıyor olabilir)
    try:
        user = json.loads(pairs.get("user", "{}"))
    except ValueError:
        return None
    if not user.get("id"):
        return None
    return {"user": user, "auth_date": auth_date}
