with open(r'webapp\admin.js', encoding='utf-8') as f:
    text = f.read()

idx = text.find('/api/admin/apikeys')
print(text[idx-100:idx+1500])
