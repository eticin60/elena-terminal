with open('miniapp.py', encoding='utf-8') as f:
    text = f.read()

idx = text.find('SELECT password, extra_password FROM wallet_credentials')
print(text[idx-50:idx+1500])
