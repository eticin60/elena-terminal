with open('miniapp.py', encoding='utf-8') as f:
    text = f.read()

idx = text.find('async def api_admin_apikeys')
print(text[idx:idx+1800])
