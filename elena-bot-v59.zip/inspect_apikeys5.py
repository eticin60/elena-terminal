with open('miniapp.py', encoding='utf-8') as f:
    text = f.read()

idx = text.find('if w[0] not in seen_chats:')
print(text[idx-50:idx+800])
