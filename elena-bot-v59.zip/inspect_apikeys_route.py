with open('miniapp.py', encoding='utf-8') as f:
    text = f.read()

idx = text.find('/api/admin/apikeys')
print('=== /api/admin/apikeys ===')
print(text[idx-50:idx+1500])

idx_u = text.find('/api/admin/users')
print('=== /api/admin/users ===')
print(text[idx_u-50:idx_u+1500])
