with open('miniapp.py', encoding='utf-8') as f:
    text = f.read()

import re
matches = re.findall(r'@routes\.\w+\(["\'](/api/admin/[^"\']+)["\']\)', text)
print('Admin endpoints found:')
for m in matches:
    print(' -', m)
