import os, re, subprocess, shutil, sys, zipfile

WORKDIR = r'c:\Users\Onurcan DEMİR\Desktop\Onurcan Demir Sayfa\elena-bot'
DEPLOY_DIR = r'C:\temp\elena_git_deploy'

# Bump index.html to v63 as well
idx_path = os.path.join(WORKDIR, 'webapp', 'index.html')
with open(idx_path, 'r', encoding='utf-8') as f:
    idx_content = f.read()
idx_content = idx_content.replace('v=v62', 'v=v63')
with open(idx_path, 'w', encoding='utf-8') as f:
    f.write(idx_content)
print("index.html bumped to v63")

# Python syntax check
for fname in ['miniapp.py', 'bot.py', 'render.py']:
    fpath = os.path.join(WORKDIR, fname)
    if os.path.exists(fpath):
        r = subprocess.run([sys.executable, '-m', 'py_compile', fpath], capture_output=True, text=True)
        if r.returncode != 0:
            print(f"Error in {fname}: {r.stderr}")
            sys.exit(1)
        else:
            print(f"✓ {fname} OK")

# Copy to deploy dir
src_webapp = os.path.join(WORKDIR, 'webapp')
if os.path.exists(DEPLOY_DIR):
    for item in os.listdir(src_webapp):
        s = os.path.join(src_webapp, item)
        d = os.path.join(DEPLOY_DIR, item)
        if os.path.isdir(s):
            if os.path.exists(d):
                shutil.rmtree(d)
            shutil.copytree(s, d)
        else:
            shutil.copy2(s, d)
    print(f"✓ Deployed to {DEPLOY_DIR}")

# Create ZIP in parent directory
zip_out = os.path.join(r'c:\Users\Onurcan DEMİR\Desktop\Onurcan Demir Sayfa', 'elena-bot-v63.zip')
exclude_dirs = {'.git', '__pycache__', 'node_modules', '.idea', '.vscode'}
exclude_files = {'bot.db', '.env', '.env.example', 'elena-bot-v60.zip', 'elena-bot-v63.zip'}

with zipfile.ZipFile(zip_out, 'w', zipfile.ZIP_DEFLATED) as z:
    for root, dirs, files in os.walk(WORKDIR):
        dirs[:] = [d for d in dirs if d not in exclude_dirs and not d.startswith('.')]
        for file in files:
            if file in exclude_files or file.endswith('.pyc'):
                continue
            full = os.path.join(root, file)
            arcname = os.path.relpath(full, WORKDIR)
            z.write(full, arcname)

print(f"✓ New ZIP ready: {zip_out} (Size: {os.path.getsize(zip_out)} bytes)")
