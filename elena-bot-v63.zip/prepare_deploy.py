"""
1. Update cache busters in index.html and admin.html to v60
2. Run syntax checks on all JS/Python files
3. Copy webapp to deploy dir
4. Build zip
"""
import os, re, subprocess, shutil, sys

WORKDIR = r'c:\Users\Onurcan DEMİR\Desktop\Onurcan Demir Sayfa\elena-bot'
DEPLOY_DIR = r'C:\temp\elena_git_deploy'

errors = []

# ===== 1. Update cache busters to v60 =====
def update_ver(fpath, old_ver, new_ver):
    with open(fpath, 'r', encoding='utf-8') as f:
        c = f.read()
    count = c.count(old_ver)
    c = c.replace(old_ver, new_ver)
    with open(fpath, 'w', encoding='utf-8') as f:
        f.write(c)
    print(f"✓ Updated {os.path.basename(fpath)}: {old_ver} → {new_ver} ({count} occurrences)")

for fname in ['webapp/index.html', 'webapp/admin.html']:
    fpath = os.path.join(WORKDIR, fname)
    with open(fpath, 'r', encoding='utf-8') as f:
        content = f.read()
    # Find current version
    m = re.search(r'[?&]v=v(\d+)', content)
    if m:
        cur_v = int(m.group(1))
        new_v = cur_v + 1
        update_ver(fpath, f'v=v{cur_v}', f'v=v{new_v}')
    else:
        print(f"⚠️  No ?v=vXX found in {fname}")

# ===== 2. Syntax check Python =====
print("\n--- Python syntax check ---")
for fname in ['miniapp.py', 'bot.py', 'render.py']:
    fpath = os.path.join(WORKDIR, fname)
    if os.path.exists(fpath):
        r = subprocess.run([sys.executable, '-m', 'py_compile', fpath], capture_output=True, text=True)
        if r.returncode == 0:
            print(f"✓ {fname} OK")
        else:
            print(f"✗ {fname} ERROR: {r.stderr}")
            errors.append(fname)

# ===== 3. Syntax check JS =====
print("\n--- JS syntax check ---")
node = shutil.which('node')
if node:
    for fname in ['webapp/app.js', 'webapp/admin.js']:
        fpath = os.path.join(WORKDIR, fname)
        r = subprocess.run([node, '--check', fpath], capture_output=True, text=True)
        if r.returncode == 0:
            print(f"✓ {fname} OK")
        else:
            print(f"✗ {fname} ERROR: {r.stderr[:200]}")
            errors.append(fname)
else:
    print("⚠️  node not found, skipping JS syntax check")

# ===== 4. Copy webapp to deploy dir =====
print("\n--- Copying webapp to deploy dir ---")
src_webapp = os.path.join(WORKDIR, 'webapp')
dst_webapp = DEPLOY_DIR
if os.path.exists(dst_webapp):
    for item in os.listdir(src_webapp):
        s = os.path.join(src_webapp, item)
        d = os.path.join(dst_webapp, item)
        if os.path.isdir(s):
            if os.path.exists(d):
                shutil.rmtree(d)
            shutil.copytree(s, d)
        else:
            shutil.copy2(s, d)
    print(f"✓ Webapp copied to {dst_webapp}")
else:
    print(f"✗ Deploy dir not found: {dst_webapp}")
    errors.append('deploy_dir_missing')

# ===== 5. Build ZIP =====
print("\n--- Building ZIP ---")
zip_exclude = {'.git', '__pycache__', 'bot.db', '.env', '.env.example', '*.pyc', 'node_modules', 'elena_git_deploy'}
zip_path = os.path.join(WORKDIR, '..', 'elena-bot-v60.zip')
try:
    import zipfile
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as z:
        for root, dirs, files in os.walk(WORKDIR):
            dirs[:] = [d for d in dirs if d not in zip_exclude and not d.startswith('.')]
            for file in files:
                if file in ('bot.db', '.env', 'elena-bot-v60.zip') or file.endswith('.pyc'):
                    continue
                full = os.path.join(root, file)
                arcname = os.path.relpath(full, WORKDIR)
                z.write(full, arcname)
    print(f"✓ ZIP created: {os.path.abspath(zip_path)}")
except Exception as e:
    print(f"✗ ZIP error: {e}")

if errors:
    print(f"\n⚠️  Errors in: {errors}")
    sys.exit(1)
else:
    print("\n✅ All checks passed! Ready to deploy.")
