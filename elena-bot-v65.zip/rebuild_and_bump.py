import os, re, subprocess, shutil, sys

WORKDIR = r'c:\Users\Onurcan DEMİR\Desktop\Onurcan Demir Sayfa\elena-bot'
DEPLOY_DIR = r'C:\temp\elena_git_deploy'

# Update cache buster to v62 in webapp/index.html and webapp/admin.html
def bump_version(path):
    with open(path, 'r', encoding='utf-8') as f:
        c = f.read()
    m = re.search(r'[?&]v=v(\d+)', c)
    if m:
        cur_v = int(m.group(1))
        new_v = cur_v + 1
        c = c.replace(f'v=v{cur_v}', f'v=v{new_v}')
        with open(path, 'w', encoding='utf-8') as f:
            f.write(c)
        print(f"Bumped {os.path.basename(path)}: v{cur_v} -> v{new_v}")

bump_version(os.path.join(WORKDIR, 'webapp', 'index.html'))
bump_version(os.path.join(WORKDIR, 'webapp', 'admin.html'))

# Copy webapp to deploy dir
src = os.path.join(WORKDIR, 'webapp')
for item in os.listdir(src):
    s = os.path.join(src, item)
    d = os.path.join(DEPLOY_DIR, item)
    if os.path.isdir(s):
        if os.path.exists(d):
            shutil.rmtree(d)
        shutil.copytree(s, d)
    else:
        shutil.copy2(s, d)

print("Webapp copied to DEPLOY_DIR!")

# Re-create ZIP for Termux
zip_exclude = {'.git', '__pycache__', 'bot.db', '.env', '.env.example', 'node_modules', 'elena_git_deploy'}
zip_path = os.path.join(WORKDIR, '..', 'elena-bot-v60.zip')
import zipfile
with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as z:
    for root, dirs, files in os.walk(WORKDIR):
        dirs[:] = [d for d in dirs if d not in zip_exclude and not d.startswith('.')]
        for file in files:
            if file in ('bot.db', '.env', 'elena-bot-v60.zip') or file.endswith('.pyc'):
                continue
            full = os.path.join(root, file)
            arcname = os.path.relpath(full, WORKDIR)
            z.write(full, arcname)

print("ZIP re-packaged at:", os.path.abspath(zip_path))
