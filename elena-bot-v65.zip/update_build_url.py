path = r'c:\Users\Onurcan DEMİR\Desktop\Onurcan Demir Sayfa\elena-bot\bot.py'
with open(path, 'r', encoding='utf-8') as f:
    text = f.read()

OLD_FN = '''def build_miniapp_web_url(page="index.html"):
    """
    Her zaman 7/24 kesintisiz çalışan GitHub Pages adresini temel alır (net::ERR_NAME_NOT_RESOLVED VERMEZ).
    Varsa canlı Termux API tünelini ?api= parametresi olarak ekler.
    Böylece Telegram Menü Butonundan veya sohbetteki butonlardan açıldığında:
    1. Arayüz GitHub CDN'den anında, hatasız ve hızlı açılır.
    2. Mini App ?api= ile güncel Termux veritabanına bağlanır.
    """
    page_name = page.lstrip("/")
    tunnel = get_live_api_tunnel()
    if tunnel and str(tunnel).startswith("https://"):
        return f"{tunnel.rstrip('/')}/{page_name}"
    base = DEFAULT_MINIAPP_URL.rstrip("/")
    return f"{base}/{page_name}"'''

NEW_FN = '''def build_miniapp_web_url(page="index.html"):
    """
    Her zaman 7/24 kesintisiz çalışan GitHub Pages adresini temel alır (net::ERR_NAME_NOT_RESOLVED VERMEZ).
    Varsa canlı Termux API tünelini ?api= parametresi olarak ekler.
    Böylece Telegram Menü Butonundan veya sohbetteki butonlardan açıldığında:
    1. Arayüz GitHub CDN'den anında, hatasız ve hızlı açılır.
    2. Mini App ?api= ile güncel Termux veritabanına bağlanır.
    """
    page_name = page.lstrip("/")
    base = DEFAULT_MINIAPP_URL.rstrip("/")
    tunnel = get_live_api_tunnel()
    if tunnel and str(tunnel).startswith("https://"):
        return f"{base}/{page_name}?api={tunnel.rstrip('/')}"
    return f"{base}/{page_name}"'''

assert OLD_FN in text, "OLD_FN not found in bot.py!"
text = text.replace(OLD_FN, NEW_FN)

with open(path, 'w', encoding='utf-8') as f:
    f.write(text)

print("Updated build_miniapp_web_url in bot.py successfully!")
